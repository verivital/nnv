classdef GraphTranslation < handle      % A handle so we can put a pointer to it inside NodeTranslation
    properties
        GraphName
        
        % The GraphProto being translated
        GraphProto
        
        % We define "External" input and output tensors to be those that
        % serve as the "I/O" of the graph as a whole. This differs from
        % what ONNX calls the graph "inputs", which also includes purely
        % graph-internal tensors that appear as inputs to operators, for
        % example, weight tensors. Operationally, we define external input
        % tensors to be ONNX inputs that do not have corresponding
        % initializers.
        ExternalInputNames
        ExternalInputShapes
        ExternalInputTypes
        ExternalInputRanks
        
        % ONNX graph "outputs" are already external.
        ExternalOutputNames
        ExternalOutputShapes
        ExternalOutputTypes
        
        % An array of translations of nodes in this graph
        NodeTranslations = [];
        
        % A struct of initial values for graph inputs, including internal
        % inputs, to be used when an input is not passed.
        AllInputDefaults = struct;
        
        % A struct of new state properties with their initial values that
        % are introduced in this graph and its subgraphs. (Currently, this
        % is only batchnorm running means and variances).
        InitialState = struct;
        
        % A struct of learnable parameters with their initial values that
        % are introduced in this graph and its subgraphs.
        Learnables = struct;
        
        % A struct of nonlearnable parameters with their values that are
        % introduced in this graph and its subgraphs.
        Nonlearnables = struct;
        
        % Names of onnx<OP> functions required for this graph and
        % subgraphs. A string array.
        IncludedFunctionNames = string([]);
        
        % MATLAB code for functions implementing this graph and all
        % subgraphs. A string array.
        GraphFunctionCode = string([]);
        
        % The opset version of the model that contains this graph
        OpsetVersion = 1;
        
        % The names of all integer tensors. A string array.
        IntegerTensorNames = string([]);
        
        % A list of NodeTranslationIssues in this graph and all subgraphs.
        TranslationIssues = nnet.internal.cnn.onnx.NodeTranslationIssue.empty;
    end
    
    methods
        function this = GraphTranslation(graphProto, OpsetVersion, initialIntegerTensorNames, optionalGraphName)
            if nargin < 4
                optionalGraphName = nnet.internal.cnn.onnx.fcn.uniqueName([graphProto.name 'Graph']);
            end
            this.GraphProto = graphProto;
            this.OpsetVersion = OpsetVersion;
            this.IntegerTensorNames = initialIntegerTensorNames;        % Integer tensor names form an enclosing scope (if exists).
            this.GraphName = optionalGraphName;
            this = findGraphIOTensors(this, graphProto);
            this.IntegerTensorNames	= [this.IntegerTensorNames, integerInitializerNames(this, graphProto)];
            % Translate the ONNX nodes
            this.NodeTranslations = nnet.internal.cnn.onnx.fcn.NodeTranslation.empty;
            for i = 1:numel(graphProto.node)
                this.NodeTranslations(i) = nnet.internal.cnn.onnx.fcn.NodeTranslation.create(graphProto.node(i), this.OpsetVersion, this.IntegerTensorNames, this);
                % Update list of integer tensors after each node is
                % translated, for use by subsequent nodes
                this.IntegerTensorNames = [this.IntegerTensorNames, this.NodeTranslations(i).IntegerOutputTensorNames(:)'];
            end
            % Collect subgraph learnables, nonlearnables and included function names from nodes
            this.Learnables = nnet.internal.cnn.onnx.fcn.appendStructs(this.Learnables, this.NodeTranslations.SubgraphLearnables);
            this.Nonlearnables = nnet.internal.cnn.onnx.fcn.appendStructs(this.Nonlearnables, this.NodeTranslations.Nonlearnables);
            if ~isempty([this.NodeTranslations.IncludedFunctionNames])
                this.IncludedFunctionNames = unique([this.NodeTranslations.IncludedFunctionNames]);
            end
            % Distribute remaining initializers into the InputDefaults, Learnables and InitialState properties
            this = distributeInitializers(this, graphProto);
            % Generate code to implement the graph.
            this.GraphFunctionCode = genGraphDefinition(this);
            % Append any subgraph function code from the nodes.
            SubgraphTranslations = [this.NodeTranslations.SubgraphTranslations];
            if ~isempty(SubgraphTranslations)
                this.GraphFunctionCode = [this.GraphFunctionCode, SubgraphTranslations.GraphFunctionCode];
            end
            % Collect all NodeTranslationIssues
            issues = arrayfun(@(nodeTranslation) nodeTranslation.Issues, this.NodeTranslations, 'UniformOutput', false);
            this.TranslationIssues = [issues{:}];
        end
        
        function tf = isInitializer(this, name)
            tf = ~isempty(this.GraphProto.sparse_initializer) && ismember(name, {this.GraphProto.sparse_initializer.name}) ...
                || ~isempty(this.GraphProto.initializer) && ismember(name, {this.GraphProto.initializer.name});
        end  
        
        function [data, rankedArray] = getInitializerValue(this, name)
            isSparse = false;
            if ~isempty(this.GraphProto.sparse_initializer)
                [isSparse,idx] = ismember(name, {this.GraphProto.sparse_initializer.name});
            end
            if isSparse
                initializer = this.GraphProto.sparse_initializer(idx);
                data = nnet.internal.cnn.onnx.getDataFromSparseTensorProto(initializer);
            else
                [~,idx] = ismember(name, {this.GraphProto.initializer.name});
                initializer = this.GraphProto.initializer(idx);
                data = nnet.internal.cnn.onnx.getDataFromTensorProto(initializer);
            end
            % Make numeric data double so that input doubles can remain
            % doubles all the way through
            if isnumeric(data) && ~isa(data, 'double')
                data = double(data);
            end
            % Get dims
            dimVec = flip(initializer.dims);                                    % flip initializer dims to MATLAB dimension ordering.
            if numel(dimVec) > 1
                dimVec = dimVec(:)';                                            % Make sure dimVec is a row vector.
                data = reshape(data, dimVec);                                   % Apply MATLAB shape
            end
            rankedArray = nnet.internal.cnn.onnx.fcn.RankedArray(data, numel(dimVec));  % Add rank info
        end
    end
    
    methods(Access=protected)
        function code = genGraphDefinition(this)
            % Write the function header line
            InputRankStrings = cellfun(@(v)nnet.internal.cnn.onnx.fcn.uniqueName(sprintf('%sNumDims', v)), this.ExternalInputNames, 'UniformOutput', false);
            AllInputStrings = [this.ExternalInputNames, InputRankStrings {'Vars', 'NumDims', 'Training', 'state'}];
            OutputRankStrings = cellfun(@(v)nnet.internal.cnn.onnx.fcn.uniqueName(sprintf('%sNumDims', v)), this.ExternalOutputNames, 'UniformOutput', false);
            AllOutputStrings = [this.ExternalOutputNames, OutputRankStrings, {'state'}];
            code = sprintf('function [%s] = %s(%s)\n', strjoin(AllOutputStrings, ', '), this.GraphName, strjoin(AllInputStrings, ', '));
            code = [code sprintf('%% Function implementing the graph ''%s''\n', this.GraphName)];
            % Set Vars fields from formal input parameters.
            code = [code sprintf('%% Update Vars and NumDims from the graph''s formal input parameters. Note that state variables are already in Vars.\n')];
            for i = 1:numel(this.ExternalInputNames)
                name = this.ExternalInputNames{i};
                code = [code sprintf('Vars.%s = %s;\n', name, name)];
                code = [code sprintf('NumDims.%s = %s;\n', name, InputRankStrings{i})];
            end
            % Insert calls to operators
            code = [code newline sprintf('%% Execute the operators:\n')];
            MCode = [this.NodeTranslations.MCode];
            for i = 1:numel(MCode)
                code = [code sprintf('%s', MCode{i}) newline];
            end
            % Set output arguments from Vars and NumDims
            code = [code sprintf('%% Set graph output arguments from Vars and NumDims:\n')];
            for i = 1:numel(this.ExternalOutputNames)
                name = this.ExternalOutputNames{i};
                code = [code sprintf('%s = Vars.%s;\n', name, name)];
                code = [code sprintf('%s = NumDims.%s;\n', OutputRankStrings{i}, name)];
            end
            % Set output state from Vars
            code = [code sprintf('%% Set output state from Vars:\n')];
            code = [code sprintf('state = updateStruct(state, Vars);\n')];
            % End function definition
            code = [code 'end' newline];
            code = string(code);
        end
        
        function nameStrings = integerInitializerNames(~, graphProto)
            if isempty(graphProto.initializer)
                nameStrings = string([]);
            else
                initializerNames = {graphProto.initializer.name};
                initializerTypes = {graphProto.initializer.data_type};
                isInt = cellfun(@nnet.internal.cnn.onnx.isONNXTypeInteger, initializerTypes);
                nameStrings = string(initializerNames(isInt));
            end
        end
                
        function this = distributeInitializers(this, graphProto)
            % Distribute the initializers and sparse_initializers into the
            % AllInputDefaults, Learnables, Nonlearnables and InitialState
            % properties.
            initializerNames        = {};
            if ~isempty(graphProto.initializer)
                initializerNames    = {graphProto.initializer.name};
            end
            if ~isempty(graphProto.sparse_initializer)
                sparseInitializerNames   = arrayfun(@(sparseTensorProto)sparseTensorProto.values.name, graphProto.sparse_initializer, 'UniformOutput', false);
                initializerNames         = [initializerNames, sparseInitializerNames];
            end
            % Assign the initializers into AllInputDefaults, Learnables, Nonlearnables and InitialState:
            this.AllInputDefaults = struct;
            this.InitialState  	  = nnet.internal.cnn.onnx.fcn.appendStructs(this.NodeTranslations.InitialState);
            for i = 1:numel(initializerNames)
                name = initializerNames{i};
                [data, rankedArray] = getInitializerValue(this, initializerNames{i});
                % Put this initializer into the correct category
                if ismember(name, fieldnames(this.InitialState))
                    % It's an initial state
                    this.InitialState.(name) = rankedArray;
                elseif ismember(name, this.ExternalInputNames)
                    % It's a graph input default value
                    this.AllInputDefaults.(name) = rankedArray;
                elseif isnumeric(data) && ~isfield(this.Nonlearnables, name)
                    % Numeric initializers that aren't already in
                    % Nonlearnables go into Learnables
                    this.Learnables.(name) = rankedArray;
                else
                    % Non-numeric initializers go into Nonlearnables
                    this.Nonlearnables.(name) = rankedArray;
                end
            end
        end
        
        function this = findGraphIOTensors(this, graphProto)
            % Find the input and output tensors of the graph as a whole and
            % record their properties
            GraphInputs = allGraphInputNames(graphProto);
            inputsWithoutInitializers = GraphInputs;
            if ~isempty(graphProto.initializer)
                inputsWithoutInitializers = setdiff(inputsWithoutInitializers, {graphProto.initializer.name}, 'stable');     % Stable keeps the inputs in the correct order.
            end
            this.ExternalInputNames   = inputsWithoutInitializers;
            this.ExternalOutputNames  = graphOutputNames(graphProto);
            [this.ExternalInputShapes, this.ExternalInputTypes]   = findGraphInputShapesAndTypes(graphProto, this.ExternalInputNames);
            [this.ExternalOutputShapes, this.ExternalOutputTypes]	= findGraphOutputShapesAndTypes(graphProto, this.ExternalOutputNames);
            % Create ExternalInputRanks struct. Add input tensors.
            this.ExternalInputRanks = struct;
            for i = 1:numel(this.ExternalInputNames)
                if isempty(this.ExternalInputShapes{i})
                    this.ExternalInputRanks.(this.ExternalInputNames{i}) = [];                                  % Empty shapes get empty rank
                else
                    this.ExternalInputRanks.(this.ExternalInputNames{i}) = numel(this.ExternalInputShapes{i});
                end
            end
            % Add integer input tensors
            for i = 1:numel(this.ExternalInputNames)
                if nnet.internal.cnn.onnx.isONNXTypeInteger(this.ExternalInputTypes{i})
                    this.IntegerTensorNames(end+1) = this.ExternalInputNames{i};
                end
            end
        end
    end
end

function data = getInitializerData(graphProto)
% Return a cell array of the data for each initializer.
data = {};
for i = numel(graphProto.initializer):-1:1
    data{i} = nnet.internal.cnn.onnx.getDataFromTensorProto(graphProto.initializer(i));
    % Make all numeric data double so that input doubles can remain doubles
    % all the way through
    if isnumeric(data{i}) && ~isa(data{i}, 'double')
        data{i} = double(data{i});
    end
end
end

function data = getSparseInitializerData(graphProto)
% Return a cell array of the data for each initializer.
data = {};
for i = numel(graphProto.sparse_initializer):-1:1
    data{i} = nnet.internal.cnn.onnx.getDataFromSparseTensorProto(graphProto.initializer(i));
    if isempty(data{i})
        error(message('nnet_cnn_onnx:onnx:InitializerDataTypeUnsupported', graphProto.sparse_initializer(i).values.name,...
            char(graphProto.sparse_initializer(i).values.data_type)));
    end
end
end

function [graphInputShapes, graphInputTypes] = findGraphInputShapesAndTypes(graphProto, inputTensorNames)
graphInputShapes = {};
graphInputTypes = string;
% Find the input tensors
[~,positions] = ismember(inputTensorNames, allGraphInputNames(graphProto));
assert(all(positions>0));   % Meaning the input tensors were found
for i = 1:numel(positions)
    pos = positions(i);
    % Get the shape cell array for this input. Fill in empty cells with the sizes specified.
    shape = graphProto.input(pos).type.tensor_type.shape;
    if isempty(shape) || isempty(shape.dim)
        ONNXInputShape      = {};
        ONNXInputSymbols    = {};
    else
        ONNXInputShape      = cellfun(@double, {graphProto.input(pos).type.tensor_type.shape.dim.dim_value}, 'UniformOutput', false);
        ONNXInputSymbols	= {graphProto.input(pos).type.tensor_type.shape.dim.dim_param};          % Non-empty elements indicate undetermined sizes.
        [ONNXInputShape, ONNXInputSymbols] = addMissingShapeSymbols(ONNXInputShape, ONNXInputSymbols);
    end
    ONNXShapeCell       = ONNXInputSymbols;
    isEmptyShape        = cellfun(@isempty, ONNXShapeCell);
    ONNXShapeCell(isEmptyShape) = ONNXInputShape(isEmptyShape);
    graphInputShapes{i} = ONNXShapeCell;
    % Get the type for this input.
    graphInputTypes(i) = graphProto.input(pos).type.tensor_type.elem_type;
end
end

function C = allGraphInputNames(graphProto)
% All "input" names to the graph, including both "true" external inputs as
% well as internal tensors that have initializers.
C = arrayfun(@(valInfoProto)valInfoProto.name, graphProto.input, 'UniformOutput', false);
end

function C = graphOutputNames(graphProto)
C = arrayfun(@(valInfoProto)valInfoProto.name, graphProto.output, 'UniformOutput', false);
end

function [ONNXShape, ONNXSymbols] = addMissingShapeSymbols(ONNXShape, ONNXSymbols)
% Add symbols for entries that have neither a shape nor a symbol
persistent newSymbolNum
for j = 1:numel(ONNXSymbols)
    if isempty(ONNXSymbols{j}) && isempty(ONNXShape{j})
        if isempty(newSymbolNum)
            newSymbolNum = 1;
        else
            newSymbolNum = newSymbolNum + 1;
        end
        ONNXSymbols{j} = sprintf('Unknown%d', newSymbolNum);
    end
end
end

function [graphOutputShapes, graphOutputTypes] = findGraphOutputShapesAndTypes(graphProto, outputTensorNames)
graphOutputShapes = {};
graphOutputTypes = string;
% Find the output tensors
[~,positions] = ismember(outputTensorNames, graphOutputNames(graphProto));
assert(all(positions>0));   % Meaning the output tensors were found
for i = 1:numel(positions)
    pos = positions(i);
    % Get its shape cell array. Fill in empty cells with the sizes
    % specified. From the ONNX IR Doc: "The empty list of dimension sizes,
    % [], is a valid tensor shape, denoting a zero-dimension (scalar)
    % value."
    if isempty(graphProto.output(pos).type)
        % This condition occurs in ONNX networks we've created when we add
        % all intermediate tensors to the output for debugging purposes.
        graphOutputShapes{i} = {};
        graphOutputTypes(i) = nnet.internal.cnn.onnx.TensorProto_DataType.FLOAT;
    else
        shape = graphProto.output(pos).type.tensor_type.shape;
        if isempty(shape) || isempty(shape.dim)
            % This condition occurs in ONNX models in the wild
            graphOutputShapes{i} = {};
        else
            dim = shape.dim;
            ONNXOutputShape  	= cellfun(@double, {dim.dim_value}, 'UniformOutput', false);
            ONNXOutputSymbols	= {dim.dim_param};                                  % Non-empty elements indicate undetermined sizes.
            [ONNXOutputShape, ONNXOutputSymbols] = addMissingShapeSymbols(ONNXOutputShape, ONNXOutputSymbols);
            ONNXShapeCell       = ONNXOutputSymbols;
            isEmptyShape        = cellfun(@isempty, ONNXShapeCell);
            ONNXShapeCell(isEmptyShape) = ONNXOutputShape(isEmptyShape);
            graphOutputShapes{i} = ONNXShapeCell;
        end
        % Get the type for this output.
        graphOutputTypes(i) = graphProto.output(pos).type.tensor_type.elem_type;
    end
end
end
