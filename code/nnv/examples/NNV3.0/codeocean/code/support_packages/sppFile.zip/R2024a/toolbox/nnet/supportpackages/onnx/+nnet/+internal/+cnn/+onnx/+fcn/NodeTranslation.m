classdef NodeTranslation
    % A class to translate a NodeProto into functional code.
    
    %   Copyright 2020-2023 The MathWorks, Inc.    
    properties
        % A struct of state properties with their initial values introduced
        % in this node and its subgraphs. (Currently, this is only
        % batchnorm running means and variances). States introduced in this
        % node will have empty initial values until assigned while parsing
        % the enclosing graph.
        InitialState = struct;
        
        % A struct of nonlearnable parameters with their values that are
        % introduced in this node and its subgraphs.
        Nonlearnables = struct;
        
        % MATLAB code that implements this invocation of the operator in
        % its graph. A string array.
        MCode = string([]);
        
        % Names of operator functions required for this node and subgraphs.
        % A string array.
        IncludedFunctionNames = string([]);
        
        % A struct of learnable parameters with their initial values
        % introduced in this node's subgraphs. (It is not known which
        % inputs to the current node are Learnable until its enclosing
        % graph is parsed.)
        SubgraphLearnables = struct;
        
        % MATLAB code for functions implementing all subgraphs below this
        % node. A string array.
        SubgraphFunctionCode = string([]);
        
        % For inspectability
        SubgraphTranslations = [];
        
        % Problems encountered during translation
        Issues = nnet.internal.cnn.onnx.NodeTranslationIssue.empty;
        
        % The opset version of the model that contains this node
        OpsetVersion = 1
        
        % The translation strategy class for this opset
        OpsetTranslationStrategy
        
        % The names of integer output tensors introduced by this node. A
        % string array.
        IntegerOutputTensorNames = string([]);
        
        % The GraphTranslation for this node's parent graph
        GraphTranslation
    end
    
    methods(Static)
        function nodeTranslation = create(nodeProto, opsetVersion, IntegerTensorNames, graphTranslation)
            % Static method to create a NodeTranslation
            nodeTranslation = nnet.internal.cnn.onnx.fcn.NodeTranslation(opsetVersion, graphTranslation);
            nodeTranslation = translateNode(nodeTranslation, nodeProto, IntegerTensorNames);
        end
    end
    
    methods
        function this = NodeTranslation(opsetVersion, graphTranslation)
            if nargin > 0
                this.OpsetVersion = opsetVersion;
                this.GraphTranslation = graphTranslation;
                switch this.OpsetVersion
                    case {1,2,3,4,5}
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset6TranslationStrategy;
                    case 6
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset6TranslationStrategy;   
                    case 7
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset7TranslationStrategy;
                    case 8
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset8TranslationStrategy;
                    case 9
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset9TranslationStrategy;
                    case 10
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset10TranslationStrategy;
                    case 11
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset11TranslationStrategy;
                    case 12
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset12TranslationStrategy;
                    case 13
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset13TranslationStrategy;
                    case 14
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset14TranslationStrategy;
                    otherwise
                        % if the customer uses a higher Opset version, use
                        % the highest fully-supported Opset version to translate. 
                        this.OpsetTranslationStrategy = nnet.internal.cnn.onnx.fcn.Opset14TranslationStrategy;
                end
            end
        end
        
        function this = translateNode(this, nodeProto, IntegerTensorNames)
            % Make a NodeTranslationWarning if the node requires a function 
            % from a missing toolbox
            unlicensedIssue = warnIfOpNeedsMissingToolbox(this, nodeProto);
            % Select the translator function
            switch nodeProto.op_type
                case 'Abs'
                    translatorFcn = @translateAbs;
                case 'Add'
                    translatorFcn = @translateAdd;
                case 'And'
                    translatorFcn = @translateAnd;
                case 'ArgMax'
                    translatorFcn = @translateArgMax;
                case 'AveragePool'
                    translatorFcn = @translateAveragePool;
                case 'BatchNormalization'
                    translatorFcn = @translateBatchNormalization;
                case 'Cast'
                    translatorFcn = @translateCast;
                case 'CategoryMapper'
                    translatorFcn = @translateCategoryMapper;
                case 'Ceil'
                    translatorFcn = @translateCeil;
                case 'Clip'
                    translatorFcn = @translateClip;
                case 'Compress'
                    translatorFcn = @translateCompress;
                case 'Concat'
                    translatorFcn = @translateConcat;
                case 'Constant'
                    translatorFcn = @translateConstant;
                case 'ConstantOfShape'
                    translatorFcn = @translateConstantOfShape;
                case 'Conv'
                    translatorFcn = @translateConv;
                case 'ConvTranspose'
                    translatorFcn = @translateConvTranspose;
                case 'Cos'
                    translatorFcn = @translateCos;
                case 'CumSum'
                    translatorFcn = @translateCumSum;
                case 'DepthToSpace'
                    translatorFcn = @translateDepthToSpace;
                case 'Div'
                    translatorFcn = @translateDiv;
                case 'Dropout'
                    translatorFcn = @translateDropout;
                case 'Elu'
                    translatorFcn = @translateElu;
                case 'Equal'
                    translatorFcn = @translateEqual;
                case 'Erf'
                    translatorFcn = @translateErf;
                case 'Exp'
                    translatorFcn = @translateExp;
                case 'Expand'
                    translatorFcn = @translateExpand;
                case 'Flatten'
                    translatorFcn = @translateFlatten;
                case 'Floor'
                    translatorFcn = @translateFloor;
                case 'Gather'
                    translatorFcn = @translateGather;
                case 'GatherElements'
                    translatorFcn = @translateGatherElements;
                case 'Gemm'
                    translatorFcn = @translateGemm;
                case 'GlobalAveragePool'
                    translatorFcn = @translateGlobalAveragePool;
                case 'GlobalMaxPool'
                    translatorFcn = @translateGlobalMaxPool;
                case 'Greater'
                    translatorFcn = @translateGreater;
                case 'GRU'
                    translatorFcn = @translateGRU;
                case 'Hardmax'
                    translatorFcn = @translateHardmax;
                case 'Identity'
                    translatorFcn = @translateIdentity;
                case 'If'
                    translatorFcn = @translateIf;
                case 'ImageScaler'
                    translatorFcn = @translateImageScaler;
                case 'InstanceNormalization'
                    translatorFcn = @translateInstanceNormalization;
                case 'LeakyRelu'
                    translatorFcn = @translateLeakyRelu;
                case 'Less'
                    translatorFcn = @translateLess;
                case 'LessOrEqual'
                    translatorFcn = @translateLessOrEqual;
                case 'Log'
                    translatorFcn = @translateLog;
                case 'Loop'
                    translatorFcn = @translateLoop;
                case 'LRN'
                    translatorFcn = @translateLRN;
                case 'LSTM'
                    translatorFcn = @translateLSTM;
                case 'MatMul'
                    translatorFcn = @translateMatMul;
                case 'Max'
                    translatorFcn = @translateMax;
                case 'MaxPool'
                    translatorFcn = @translateMaxPool;
                case 'Min'
                    translatorFcn = @translateMin;
                case 'Mul'
                    translatorFcn = @translateMul;
                case 'Neg'
                    translatorFcn = @translateNeg;
                case 'NonMaxSuppression'
                    translatorFcn = @translateNonMaxSuppression;
                case 'NonZero'
                    translatorFcn = @translateNonZero;
                case 'Not'
                    translatorFcn = @translateNot;
                case 'OneHot'
                    translatorFcn = @translateOneHot;
                case 'Or'
                    translatorFcn = @translateOr;
                case 'Pad'
                    translatorFcn = @translatePad;
                case 'PRelu'
                    translatorFcn = @translatePRelu;
                case 'Pow'
                    translatorFcn = @translatePow;
                case 'RandomUniform'
                    translatorFcn = @translateRandomUniform;
                case 'Range'
                    translatorFcn = @translateRange;
                case 'Reciprocal'
                    translatorFcn = @translateReciprocal;
                case 'ReduceL2'
                    translatorFcn = @translateReduceL2;
                case 'ReduceMax'
                    translatorFcn = @translateReduceMax;
                case 'ReduceMean'
                    translatorFcn = @translateReduceMean;
                case 'ReduceMin'
                    translatorFcn = @translateReduceMin;
                case 'ReduceProd'
                    translatorFcn = @translateReduceProd;
                case 'ReduceSum'
                    translatorFcn = @translateReduceSum;
                case 'Relu'
                    translatorFcn = @translateRelu;
                case 'Reshape'
                    translatorFcn = @translateReshape;
                case 'Resize'
                    translatorFcn = @translateResize;
                case 'RoiAlign'
                    translatorFcn = @translateRoiAlign;
                case 'Round'
                    translatorFcn = @translateRound;
                case 'Scan'
                    if this.OpsetVersion >= 9
                        translatorFcn = @translateScan;
                    else
                        translatorFcn = @translateUnsupportedONNXLayers;
                        this.Issues = nnet.internal.cnn.onnx.NodeTranslationError(nodeProto, ...
                            message("nnet_cnn_onnx:onnx:UnsupportedOperator", nodeProto.op_type));
                    end
                case 'Scatter'
                    translatorFcn = @translateScatter;
                case 'ScatterElements'
                    translatorFcn = @translateScatterElements;
                case 'ScatterND'
                    translatorFcn = @translateScatterND;
                case 'SequenceAt'
                    translatorFcn = @translateSequenceAt;
                case 'Shape'
                    translatorFcn = @translateShape;
                case 'Sigmoid'
                    translatorFcn = @translateSigmoid;
                case 'Sign'
                    translatorFcn = @translateSign;
                case 'Sin'
                    translatorFcn = @translateSin;
                case 'Slice'
                    translatorFcn = @translateSlice;
                case 'Softmax'
                    translatorFcn = @translateSoftmax;
                case 'SpaceToDepth'
                    translatorFcn = @translateSpaceToDepth;
                case 'Split'
                    translatorFcn = @translateSplit;
                case 'SplitToSequence'
                    translatorFcn = @translateSplitToSequence;
                case 'Sqrt'
                    translatorFcn = @translateSqrt;
                case 'Squeeze'
                    translatorFcn = @translateSqueeze;
                case 'Sub'
                    translatorFcn = @translateSub;
                case 'Sum'
                    translatorFcn = @translateSum;
                case 'Tan'
                    translatorFcn = @translateTan;
                case 'Tanh'
                    translatorFcn = @translateTanh;
                case 'Tile'
                    translatorFcn = @translateTile;
                case 'TopK'
                    translatorFcn = @translateTopK;
                case 'Transpose'
                    translatorFcn = @translateTranspose;
                case 'Unsqueeze'
                    translatorFcn = @translateUnsqueeze;
                case 'Upsample'
                    translatorFcn = @translateUpsample;
                case 'Where'
                    translatorFcn = @translateWhere;
                otherwise
                    translatorFcn = @translateUnsupportedONNXLayers;
                    this.Issues = nnet.internal.cnn.onnx.NodeTranslationError(nodeProto, ...
                        message("nnet_cnn_onnx:onnx:UnsupportedOperator", nodeProto.op_type));
            end
            % Run the translator
            try
                this = translatorFcn(this.OpsetTranslationStrategy, this, nodeProto, IntegerTensorNames);
            catch
                this = translateUnsupportedONNXLayers(this.OpsetTranslationStrategy, this, nodeProto);
                this.Issues = nnet.internal.cnn.onnx.NodeTranslationError(nodeProto, ...
                    message("nnet_cnn_onnx:onnx:UnsupportedOperator", nodeProto.op_type));                
            end
            this.Issues = [this.Issues unlicensedIssue];
            % If the translator failed, run the placeholder translator if
            % we haven't already
            if ~isequal(translatorFcn, @translateUnsupportedONNXLayers)
                issuesWithPlaceholdersIdx = arrayfun(@(x) isa(x, 'nnet.internal.cnn.onnx.NodeTranslationError'), this.Issues);
                issuesWithPlaceholders = this.Issues(issuesWithPlaceholdersIdx);
                if ~isempty(issuesWithPlaceholders)
                    this = translateUnsupportedONNXLayers(this.OpsetTranslationStrategy, this, nodeProto);
                end
            end
        end
        
        function issue = warnIfOpNeedsMissingToolbox(~, nodeProto)
            issue = nnet.internal.cnn.onnx.NodeTranslationIssue.empty;
            switch nodeProto.op_type
                case {'DepthToSpace','Resize','SpaceToDepth', 'Upsample'}
                    % Image processing toolbox
                    if ~nnet.internal.cnn.onnx.isInstalledIPT
                        iptMsg = message('nnet_cnn_onnx:onnx:noIPTForOperator', nodeProto.op_type);
                        issue = nnet.internal.cnn.onnx.NodeTranslationWarning(nodeProto, iptMsg);
                    end
                case {'NonMaxSuppression', 'RoiAlign'}
                    % Computer vision toolbox
                    if ~nnet.internal.cnn.onnx.isInstalledCVST
                        cvtMsg = message('nnet_cnn_onnx:onnx:noCVTForOperator', nodeProto.op_type);
                        issue = nnet.internal.cnn.onnx.NodeTranslationWarning(nodeProto, cvtMsg);
                    end
            end
        end
    end
end
