classdef Opset10TranslationStrategy < nnet.internal.cnn.onnx.fcn.Opset9TranslationStrategy
    methods
        function nodeTranslation = translateAveragePool(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "auto_pad"          "STRING"    true    "NOTSET"
                "ceil_mode"         "INT"       true    0           % New in opset 10
                "count_include_pad"	"INT"       true    0
                "kernel_shape"      "INTS"      false   []
                "pads"              "INTS"      true    []
                "strides"           "INTS"      true    []
                });
            % Parse the attributes
            [auto_pad, ceil_mode, count_include_pad, kernel_shape, pads, strides] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % auto_pad, pads
            numSpatialDims = numel(kernel_shape);
            padding = zeros(2*numSpatialDims,1);
            if auto_pad ~= "NOTSET"
                switch auto_pad
                    case "SAME_UPPER"
                        padding = "same";
                    case "SAME_LOWER"
                        padding = "same";
                        nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                            message("nnet_cnn_onnx:onnx:AutoPadSameLower"))];
                    case "VALID"
                        % Leave default
                    otherwise
                        % Leave default
                end
            elseif isempty(pads)
                padding = zeros(2*numSpatialDims,1);
            else
                padding = double(pads);
            end
            % strides
            if isempty(strides)
                strides = ones(numSpatialDims,1);
            end
            % ceil_mode=1 not supported
            if ceil_mode==1
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:AttributeMustHaveValue', node.name, 'AveragePool', 'ceil_mode', '0'));
                return;
            end
            % Y = avgpool(X,POOLSIZE,...)
            Y        = node.output{1};
            X        = node.input{1};
            PoolsizeName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'PoolSize']);
            StrideName   = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Stride']);
            PaddingName  = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Padding']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[poolSize, stride, padding, paddingValue, dataFormat, NumDims.%s] = prepareAveragePoolArgs(Vars.%s, Vars.%s, Vars.%s, %d, NumDims.%s);\n',...
                Y, PoolsizeName, StrideName, PaddingName, count_include_pad, X),...
                sprintf('Vars.%s = avgpool(Vars.%s, poolSize, ''Stride'', stride, ''Padding'', padding, ''PaddingValue'', paddingValue, ''DataFormat'', dataFormat);\n', Y, X),...
                ];
            nodeTranslation.Nonlearnables           = struct(...
                PoolsizeName, nnet.internal.cnn.onnx.fcn.RankedArray(kernel_shape,1), ...
                StrideName, nnet.internal.cnn.onnx.fcn.RankedArray(strides,1), ...
                PaddingName, nnet.internal.cnn.onnx.fcn.RankedArray(padding,1));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareAveragePoolArgs";
        end
        
        function nodeTranslation = translateMaxPool(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "auto_pad"          "STRING"    true    "NOTSET"
                "ceil_mode"         "INT"       true   	0           % new in opset 10
                "dilations"         "INTS"      true   	[]          % new in opset 10
                "kernel_shape"      "INTS"      false   []
                "pads"              "INTS"      true    []
                "storage_order"     "INT"       true    []
                "strides"           "INTS"      true    []
                });
            % Parse the attributes
            [auto_pad,  ceil_mode, dilations, kernel_shape, pads, storage_order, strides] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % auto_pad, pads
            numSpatialDims = numel(kernel_shape);
            padding = zeros(2*numSpatialDims,1);
            if auto_pad ~= "NOTSET"
                switch auto_pad
                    case "SAME_UPPER"
                        padding = "same";
                    case "SAME_LOWER"
                        padding = "same";
                        nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                            message("nnet_cnn_onnx:onnx:AutoPadSameLower"))];
                    case "VALID"
                        % Leave default
                    otherwise
                        % Leave default
                end
            elseif isempty(pads)
                padding = zeros(2*numSpatialDims,1);
            else
                padding = double(pads);
            end
            % strides
            if isempty(strides)
                strides = ones(numSpatialDims,1);
            end
            % ceil_mode=1 not supported
            if ceil_mode==1
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:AttributeMustHaveValue', node.name, 'MaxPool', 'ceil_mode', '0'));
                return;
            end
            % dilations~=1 not supported
            if any(dilations ~= 1) 
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:AttributeMustHaveValue', node.name, 'MaxPool', 'dilations', '1'));
                return;
            end
            % column-major not supported
            if storage_order==1
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:AttributeMustHaveValue', node.name, 'MaxPool', 'storage_order', '0'));
                return;
            end
            switch numel(node.output)
                case 1
                    % Single-output: Y = maxpool(X,POOLSIZE,...)
                    Y        = node.output{1};
                    X        = node.input{1};
                    PoolsizeName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'PoolSize']);
                    StrideName   = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Stride']);
                    PaddingName  = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Padding']);
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[poolsize, stride, padding, dataFormat, NumDims.%s] = prepareMaxPool8Args(Vars.%s, Vars.%s, Vars.%s, NumDims.%s);\n', Y, PoolsizeName, StrideName, PaddingName, X),...
                        sprintf('Vars.%s = maxpool(Vars.%s, poolsize, ''Stride'', stride, ''Padding'', padding, ''DataFormat'', dataFormat);\n', Y, X),...
                        ];
                case 2
                    % Two-output: [Y, Indices] = maxpool(X,POOLSIZE,...)
                    Y        = node.output{1};
                    Indices  = node.output{2};
                    X        = node.input{1};
                    PoolsizeName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'PoolSize']);
                    StrideName   = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Stride']);
                    PaddingName  = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Padding']);
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[poolsize, stride, padding, dataFormat, NumDims.%s, NumDims.%s] = prepareMaxPool8Args(Vars.%s, Vars.%s, Vars.%s, NumDims.%s);\n',...
                        Y, Indices, PoolsizeName, StrideName, PaddingName, X),...
                        sprintf('[Vars.%s, Vars.%s] = maxpool(Vars.%s, poolsize, ''Stride'', stride, ''Padding'', padding, ''DataFormat'', dataFormat);\n', Y, Indices, X),...
                        ];
                    nodeTranslation.IntegerOutputTensorNames = string(Indices);
            end
            nodeTranslation.Nonlearnables           = struct(...
                PoolsizeName, nnet.internal.cnn.onnx.fcn.RankedArray(kernel_shape,1), ...
                StrideName, nnet.internal.cnn.onnx.fcn.RankedArray(strides,1), ...
                PaddingName, nnet.internal.cnn.onnx.fcn.RankedArray(padding,1));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareMaxPool8Args";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames(end+1) = string(Y);
            end
        end
        
        function nodeTranslation = translateNonMaxSuppression(~, nodeTranslation, node, IntegerTensorNames)         % Introduced in opset 10
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "center_point_box"         "INT"       true    0
                });
            % Parse the attributes
            [center_point_box] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = NonMaxSuppression(boxes, scores, max_output_boxes_per_class, iou_threshold, score_threshold)
            Y                           = node.output{1};
            boxes                       = ['Vars.' node.input{1}];
            scores                      = ['Vars.' node.input{2}];
            if numel(node.input) > 2 && ~isempty(node.input{3})
                max_output_boxes_per_class = ['Vars.' node.input{3}];
            else
                max_output_boxes_per_class = 'Inf';
            end
            if numel(node.input) > 3 && ~isempty(node.input{4})
                iou_threshold = ['Vars.' node.input{4}];
            else
                iou_threshold = '0.5';
            end
            if numel(node.input) > 4 && ~isempty(node.input{5})
                score_threshold = ['Vars.' node.input{5}];
            else
                score_threshold = '0';
            end
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxNonMaxSuppression(%s, %s, %s, %s, %s, %d);\n',...
                Y, Y, boxes, scores, max_output_boxes_per_class, iou_threshold, score_threshold, center_point_box),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxNonMaxSuppression";
            nodeTranslation.IntegerOutputTensorNames = string(Y);
            % Add all initializer inputs beyond 1 to Nonlearnables
            for i=2:numel(node.input)
                tensorName = node.input{i};
                if isInitializer(nodeTranslation.GraphTranslation, tensorName)
                    [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, tensorName);
                    nodeTranslation.Nonlearnables.(tensorName) = rankedArray;
                end
            end
        end
        
        function nodeTranslation = translateResize(~, nodeTranslation, node, IntegerTensorNames)                    % Introduced in opset 10
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "mode"  "STRING"    true    "nearest"
                });
            % Parse the attributes
            [mode] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            if ~ismember(mode, ["nearest", "linear"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node, message("nnet_cnn_onnx:onnx:UnsupportedAttributeValue", mode, 'mode'));
                return;
            end
            % Gen code
            Y = node.output{1};
            X = node.input{1};
            scales  = node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[DLTScales, dataFormat, Method, NumDims.%s] = prepareResize10Args(Vars.%s, "%s", NumDims.%s);\n', Y, scales, mode, X),...
                sprintf('Vars.%s = dlresize(Vars.%s, ''Scale'', DLTScales, ''DataFormat'', dataFormat, ''Method'', Method, ''GeometricTransformMode'', ''asymmetric'', ''NearestRoundingMode'', ''onnx-10'');\n', ...
                Y, X),...
                ];
            nodeTranslation.IncludedFunctionNames = "prepareResize10Args";
            nodeTranslation.MCode = string(command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateRoiAlign(~, nodeTranslation, node, IntegerTensorNames)                  % Introduced in opset 10
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "mode"              "STRING"	true    "avg"
                "output_height"     "INT"     	true    1
                "output_width"      "INT"       true    1
                "sampling_ratio" 	"INT"       true    0
                "spatial_scale"  	"FLOAT"     true    1.0
                });
            % Parse the attributes
            [mode, output_height, output_width, sampling_ratio, spatial_scale] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            if ~isequal(mode, "avg")
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node, message("nnet_cnn_onnx:onnx:ModeAvg"));
                return;
            end
            % Gen code
            Y               = node.output{1};
            X               = node.input{1};
            rois            = node.input{2};
            batch_indices   = node.input{3};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxRoiAlign(Vars.%s, Vars.%s, Vars.%s, %d, %d, %d, %f);\n', ...
                Y, Y, X, rois, batch_indices, output_height, output_width, sampling_ratio, spatial_scale),...
                ];
            nodeTranslation.IncludedFunctionNames = "onnxRoiAlign";
            nodeTranslation.MCode = string(command);
        end
        
        function nodeTranslation = translateSlice(~, nodeTranslation, node, IntegerTensorNames)
            % Slice-10 loses its 3 attributes, which are now inputs.
            % The 'steps' input has also been added.
            Y       = node.output{1};
            X       = node.input{1};
            Starts	= node.input{2};
            Ends  	= node.input{3};
            % Axes and steps are optional
            if numel(node.input) > 3 && ~isempty(node.input{4})
                Axes = ['Vars.' node.input{4}];
            else
                Axes = "''";
            end
            if numel(node.input) > 4 && ~isempty(node.input{5})
                Steps = ['Vars.' node.input{5}];
            else
                Steps = "''";
            end
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Indices, NumDims.%s] = prepareSliceArgs(Vars.%s, Vars.%s, Vars.%s, %s, %s, NumDims.%s);\n',...
                Y, X, Starts, Ends, Axes, Steps, X),...
                sprintf('Vars.%s = subsref(Vars.%s, Indices);\n', Y, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareSliceArgs";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
            % Add inputs 2,3, (and 4,5 if present) to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, node.input{2})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{2});
                nodeTranslation.Nonlearnables.(node.input{2}) = rankedArray;
            end
            if isInitializer(nodeTranslation.GraphTranslation, node.input{3})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{3});
                nodeTranslation.Nonlearnables.(node.input{3}) = rankedArray;
            end
            if numel(node.input)>3 && isInitializer(nodeTranslation.GraphTranslation, node.input{4})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{4});
                nodeTranslation.Nonlearnables.(node.input{4}) = rankedArray;
            end
            if numel(node.input)>4 && isInitializer(nodeTranslation.GraphTranslation, node.input{5})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{5});
                nodeTranslation.Nonlearnables.(node.input{5}) = rankedArray;
            end
        end
        
        function nodeTranslation = translateTopK(~, nodeTranslation, node, IntegerTensorNames)
            % Opset 10: K is an input.
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"      "INT"       true    -1
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % [T, I] = TopK(X, K)
            T	= node.output{1};
            I 	= node.output{2};
            X	= node.input{1};
            K	= node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, Vars.%s, NumDims.%s, NumDims.%s] = onnxTopK(Vars.%s, Vars.%s, %d, NumDims.%s);\n', T, I, T, I, X, K, axis, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxTopK";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(T);
            end
            nodeTranslation.IntegerOutputTensorNames = string(I);
        end
    end
end
