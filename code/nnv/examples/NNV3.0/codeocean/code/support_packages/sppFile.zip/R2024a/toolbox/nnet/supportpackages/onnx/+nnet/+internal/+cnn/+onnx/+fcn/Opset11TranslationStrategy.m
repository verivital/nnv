classdef Opset11TranslationStrategy < nnet.internal.cnn.onnx.fcn.Opset10TranslationStrategy
%

%   Copyright 2020-2022 The MathWorks, Inc.
methods
        function nodeTranslation = translateClip(~, nodeTranslation, node, IntegerTensorNames)
            Y       = node.output{1};
            X       = node.input{1};
            if numel(node.input) > 1 && ~isempty(node.input{2})
                MinString = ['Vars.' node.input{2}];
            else
                MinString = '-Inf';
            end
            if numel(node.input) > 2 && ~isempty(node.input{3})
                MaxString = ['Vars.' node.input{3}];
            else
                MaxString = 'Inf';
            end
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = min(%s, max(%s, Vars.%s));\n', Y, MaxString, MinString, X),...
                sprintf('NumDims.%s = NumDims.%s;\n', Y, X),...
                ];
            nodeTranslation.MCode = string(command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
            % Add inputs 2 and 3 if present to Nonlearnables if it's an initializer
            if numel(node.input)>1 && isInitializer(nodeTranslation.GraphTranslation, node.input{2})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{2});
                nodeTranslation.Nonlearnables.(node.input{2}) = rankedArray;
            end
            if numel(node.input)>2 && isInitializer(nodeTranslation.GraphTranslation, node.input{3})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{3});
                nodeTranslation.Nonlearnables.(node.input{3}) = rankedArray;
            end
        end
        
        function nodeTranslation = translateCompress(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       true    []
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y       = node.output{1};
            X       = node.input{1};
            condition = node.input{2};
            if isempty(axis)
                % X is implicitly flattened first.
                command = [
                    sprintf('%% %s:\n', node.op_type),...
                    sprintf('[Indices, NumDims.%s] = prepareCompressArgs11(Vars.%s, Vars.%s, [], NumDims.%s);\n', Y, X, condition, X),...
                    sprintf('Vars.%s = Vars.%s(Indices);\n', Y, X),...
                    ];
            else
                % X is not flattened first.
                command = [
                    sprintf('%% %s:\n', node.op_type),...
                    sprintf('[Indices, NumDims.%s] = prepareCompressArgs11(Vars.%s, Vars.%s, %d, NumDims.%s);\n', Y, X, condition, axis, X),...
                    sprintf('Vars.%s = subsref(Vars.%s, Indices);\n', Y, X),...
                    ];
            end
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareCompressArgs11";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateConstant(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "sparse_value"	"TENSOR"    true    []
                "value"         "TENSOR"    true    []
                });
            % Parse the attributes
            [sparse_value, value] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % According to ONNX Doc, exactly one of the attributes will be present.
            if ~isempty(sparse_value)
                % Get the data from a SparseTensorProto
                [tensorValue, shape] = nnet.internal.cnn.onnx.getDataFromSparseTensorProto(sparse_value);
            else
                % Get the data from a TensorProto
                [tensorValue, shape] = nnet.internal.cnn.onnx.getDataFromTensorProto(value);
            end
            % Make the value a dlarray so it could be made learnable if
            % desired. Make it single because it's an activation tensor.
            tensorValue = dlarray(double(tensorValue));
            % Construct the constant tensor at translation-time and add it to Nonlearnables
            if numel(shape)>1
                DLTShape = fliplr(shape(:)');
                tensorValue = reshape(tensorValue, DLTShape);   % Can just reshape the ONNX data because the memory ordering is the same in ONNX and DLT.
            end
            Y = node.output{1};
            nodeTranslation.Nonlearnables = struct(Y, nnet.internal.cnn.onnx.fcn.RankedArray(tensorValue, numel(shape)));
            if ~isempty(value) && nnet.internal.cnn.onnx.isONNXTypeInteger(value.data_type) ||...
                    ~isempty(sparse_value) && nnet.internal.cnn.onnx.isONNXTypeInteger(sparse_value.data_type)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end

        function nodeTranslation = translateCumSum(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "exclusive" "INT"   true    0
                "reverse"   "INT"   true    0
                });
            % Parse the attributes
            [exclusive, reverse] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y       = node.output{1};
            X       = node.input{1};
            axis    = node.input{2};
            Command = sprintf('%% %s:\n', node.op_type);
            Command = [Command,...
                sprintf('[Vars.%s, NumDims.%s] = onnxCumSum(Vars.%s, Vars.%s, %d, %d, NumDims.%s);\n', Y, Y, X, axis, exclusive, reverse, X)];
            nodeTranslation.MCode = string(Command);
            nodeTranslation.IncludedFunctionNames = "onnxCumSum";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end 
        
        function nodeTranslation = translateDepthToSpace(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "blocksize"     "INT"       false   []
                "mode"          "STRING"    true    "DCR"
                });
            % Parse the attributes
            [blocksize, mode] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = onnxDepthToSpace(X, blocksize);
            Y        = node.output{1};
            X        = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = permute(depthToSpace(permute(Vars.%s,[2 1 3 4]),%d,''DataFormat'', [repmat(''S'',[1 NumDims.%s-2]),''CB''],''Mode'',''%s'' ), [2 1 3 4]);\n',...
                Y, X, blocksize, X, mode),...
                sprintf('NumDims.%s = 4;\n', Y), ...
                ];
            nodeTranslation.MCode                   = string(command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateGatherElements(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       true    0
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y      = node.output{1};
            X      = node.input{1};
            indices = node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxGatherElements(Vars.%s, Vars.%s, %d, NumDims.%s, NumDims.%s);\n', Y, Y, X, indices, axis, X, indices),...
                ];
            nodeTranslation.MCode = string(command);
            nodeTranslation.IncludedFunctionNames = "onnxGatherElements";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
            % Add input 2 to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, node.input{2})
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{2});
                nodeTranslation.Nonlearnables.(node.input{2}) = rankedArray;
            end
        end
        
        function nodeTranslation = translateGemm(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "alpha"        "FLOAT"       true    1
                "beta"         "FLOAT"       true    1
                "transA"         "INT"       true    0
                "transB"         "INT"       true    0
                });
            % Parse the attributes
            [alpha, beta, transA, transB] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Translate into: Y = alpha * A' * B' + beta * C, where the transposes are
            % optional and indicated by transA and transB.
            Y = node.output{1};
            A = node.input{1};
            B = node.input{2};
            if numel(node.input) > 2 && ~isempty(node.input{3})
                % C is now optional in opset 11
                Cstr = ['Vars.' node.input{3}];
                Cnd =  ['NumDims.' node.input{3}];
            else
                Cstr = '0';
                Cnd = '0';
            end
            AlphaName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'alpha']);
            BetaName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'beta']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[A, B, C, alpha, beta, NumDims.%s] = prepareGemmArgs(Vars.%s, Vars.%s, %s, Vars.%s, Vars.%s, %s, %s, %s);\n', ...
                Y, A, B, Cstr, AlphaName, BetaName, string(transA), string(transB), Cnd),...
                sprintf('Vars.%s = alpha*B*A + beta*C;\n', Y), ...
                ];
            nodeTranslation.Nonlearnables           = struct(AlphaName, nnet.internal.cnn.onnx.fcn.RankedArray(alpha,0), BetaName, nnet.internal.cnn.onnx.fcn.RankedArray(beta,0));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareGemmArgs";
            if ismember(A, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translatePad(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "mode"      "STRING"    true    "constant"
                });
            % Parse the attributes
            [mode] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = onnxPad(X, padding, value)
            Y     	= node.output{1};
            X    	= node.input{1};
            pads	= node.input{2};
            if numel(node.input) > 2 && ~isempty(node.input{3})
                constant_valueStr = sprintf('Vars.%s', node.input{3});
            else
                constant_valueStr = '0';
            end
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxPad(Vars.%s, Vars.%s, %s, ''%s'', NumDims.%s);\n', Y, Y, X, pads, constant_valueStr, mode, X)];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxPad";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
            % Add inputs 2, and 3 if present to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, node.input{2})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{2});
                nodeTranslation.Nonlearnables.(node.input{2}) = rankedArray;
            end
            if numel(node.input)>2 && isInitializer(nodeTranslation.GraphTranslation, node.input{3})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{3});
                nodeTranslation.Nonlearnables.(node.input{3}) = rankedArray;
            end
        end
        
        function nodeTranslation = translateRange(~, nodeTranslation, node, IntegerTensorNames)                 % Introduced in opset 11
            % Range is a function, not a primitive operator
            output	= node.output{1};
            start	= node.input{1};
            limit	= node.input{2};
            delta  	= node.input{3};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = dlarray(Vars.%s:Vars.%s:Vars.%s-sign(Vars.%s))'';\n', output, start, delta, limit, delta),...
                sprintf('NumDims.%s = 1;\n', output),...
                ];
            nodeTranslation.MCode = string(command);
            if ismember(start, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(output);
            end
        end
        
        function nodeTranslation = translateResize(~, nodeTranslation, node, IntegerTensorNames)
            % Resize-11 adds 5 attributes and 2 inputs.
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "coordinate_transformation_mode"    "STRING"    true    "half_pixel"
                "cubic_coeff_a"                     "FLOAT"     true    -0.75
                "exclude_outside"                   "INT"       true    0
                "extrapolation_value"               "FLOAT"     true    0.0
                "mode"                              "STRING"    true    "nearest"
                "nearest_mode"                      "STRING"    true    "round_prefer_floor"
                });
            % Parse the attributes
            [coordinate_transformation_mode,cubic_coeff_a, exclude_outside, extrapolation_value, mode, nearest_mode] ...
                = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            
            if isequal(coordinate_transformation_mode, "pytorch_half_pixel")
                coordinate_transformation_mode = "half_pixel";
            end
            
            if ~ismember(coordinate_transformation_mode, ["half_pixel", "asymmetric"]) || ...
                    ~isequal(cubic_coeff_a, -0.75) || ...
                    ~isequal(exclude_outside, 0) || ...
                    ~isequal(extrapolation_value, 0.0) || ...
                    ~ismember(mode, ["nearest", "linear"]) || ...
                    ~ismember(nearest_mode, ["floor", "round_prefer_floor"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:UnsupportedAttributeValue", mode, 'mode'));
                return;
            end
            % Gen code
            Y = node.output{1};
            X = node.input{1};
            roi = node.input{2};
            % scales can be the empty string
            if isempty(node.input{3})
                scalesStr = "dlarray([])";
            else
                scalesStr  = ['Vars.' node.input{3}];
            end
            % sizes can be the empty string or missing
            if numel(node.input)<4 || isempty(node.input{4})
                sizesStr = "dlarray([])";
            else
                sizesStr  = ['Vars.' node.input{4}];
            end
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[DLTScales, DLTSizes, dataFormat, Method, GeometricTransformMode, NearestRoundingMode, NumDims.%s] = prepareResize11Args(Vars.%s, %s, %s, "%s", "%s", "%s", NumDims.%s);\n', ...
                Y, roi, scalesStr, sizesStr, coordinate_transformation_mode, mode, nearest_mode, X),...
                sprintf('if isempty(DLTScales)\n'),...
                sprintf('Vars.%s = dlresize(Vars.%s, ''OutputSize'', DLTSizes, ''DataFormat'', dataFormat, ''Method'', Method, ''GeometricTransformMode'', GeometricTransformMode, ''NearestRoundingMode'', NearestRoundingMode);\n', ...
                Y, X),...
                sprintf('else\n'),...
                sprintf('Vars.%s = dlresize(Vars.%s, ''Scale'', DLTScales, ''DataFormat'', dataFormat, ''Method'', Method, ''GeometricTransformMode'', GeometricTransformMode, ''NearestRoundingMode'', NearestRoundingMode);\n', ...
                Y, X),...
                sprintf('end\n'),...
                ];
            nodeTranslation.IncludedFunctionNames = "prepareResize11Args";
            nodeTranslation.MCode = string(command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
            % Add inputs 2,3, and 4 if present to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, node.input{2})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{2});
                nodeTranslation.Nonlearnables.(node.input{2}) = rankedArray;
            end
            if isInitializer(nodeTranslation.GraphTranslation, node.input{3})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{3});
                nodeTranslation.Nonlearnables.(node.input{3}) = rankedArray;
            end
            if numel(node.input)>3 && isInitializer(nodeTranslation.GraphTranslation, node.input{4})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{4});
                nodeTranslation.Nonlearnables.(node.input{4}) = rankedArray;
            end
        end
        
        function nodeTranslation = translateRound(~, nodeTranslation, node, IntegerTensorNames)                	% Introduced in opset 11
            Y       = node.output{1};
            X       = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxRound(Vars.%s, NumDims.%s);\n', Y, Y, X, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxRound";
        end
        
        function nodeTranslation = translateScatterElements(~, nodeTranslation, node, IntegerTensorNames)       % Introduced in opset 11
            % Scatter was deprecated as of opset 11. ScatterElements-11 is
            % the same as Scatter-9 except the Indices input can now have
            % negative elements.
            
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"      "INT"       true    0
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y       = node.output{1};
            X       = node.input{1};
            Indices	= node.input{2};
            Updates	= node.input{3};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxScatterElements(Vars.%s, Vars.%s, Vars.%s, %d, NumDims.%s);\n', ...
                Y, Y, X, Indices, Updates, axis, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxScatterElements";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateScatterND(~, nodeTranslation, node, IntegerTensorNames)       % Introduced in opset 11
            Y       = node.output{1};
            X       = node.input{1};
            Indices	= node.input{2};
            Updates	= node.input{3};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxScatterND(Vars.%s, Vars.%s, Vars.%s, NumDims.%s, NumDims.%s, NumDims.%s);\n', ...
                Y, Y, X, Indices, Updates, X, Indices, Updates),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxScatterND";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateSequenceAt(~, nodeTranslation, node, IntegerTensorNames)            % Introduced in opset 11
            input_sequence  = node.input{1};
            position        = node.input{2};
            output          = node.output{1};
            code = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[idx1, idx2] = prepareSequenceAtArgs(Vars.%s, Vars.%s);\n', input_sequence, position),...
                sprintf('[Vars.%s, NumDims.%s] = Vars.%s{[idx1, idx2]};\n', output, output, input_sequence),...
                ];
            nodeTranslation.MCode                   = string(code);
            nodeTranslation.IncludedFunctionNames   = "prepareSequenceAtArgs";
            if ismember(input_sequence, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(output);
            end
        end
        
        function nodeTranslation = translateSplitToSequence(~, nodeTranslation, node, IntegerTensorNames)       % Introduced in opset 11
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"      "INT"       true    0
                "keepdims"  "INT"       true    1
                });
            % Parse the attributes
            [axis, keepdims] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            input = node.input{1};
            output_sequence = node.output{1};
            if numel(node.input)>1 && ~isempty(node.input{2})
                split = node.input{2};
            end
            if isempty(split)
                splitStr = '[]';
                splitNumDimsStr = '0';
            else
                splitStr        = ['Vars.', split];
                splitNumDimsStr = ['NumDims.', split];
            end
            code = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxSplitToSequence(Vars.%s, %d, %s, %d, NumDims.%s, %s);\n',...
                output_sequence, output_sequence, input, axis, splitStr, keepdims, input, splitNumDimsStr),...
                ];
            nodeTranslation.MCode                   = string(code);
            nodeTranslation.IncludedFunctionNames   = ["onnxSplitToSequence", "onnxSqueeze"];
            if ismember(input, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(output_sequence);
            end
        end
        
        function nodeTranslation = translateTopK(~, nodeTranslation, node, IntegerTensorNames)
            % Opset 11: New attribues largest and sorted.
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"      "INT"       true    -1
                "largest"   "INT"       true    1
                "sorted"    "INT"       true    1
                });
            % Parse the attributes
            [axis, largest, sorted] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % [T, I] = TopK(X, K)
            T	= node.output{1};
            I 	= node.output{2};
            X	= node.input{1};
            K	= node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, Vars.%s, NumDims.%s, NumDims.%s] = onnxTopK11(Vars.%s, Vars.%s, %d, %d, %d, NumDims.%s);\n', ...
                T, I, T, I, ...
                X, K, axis, largest, sorted, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxTopK11";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(T);
            end
            nodeTranslation.IntegerOutputTensorNames = string(I);
        end
    end
end
