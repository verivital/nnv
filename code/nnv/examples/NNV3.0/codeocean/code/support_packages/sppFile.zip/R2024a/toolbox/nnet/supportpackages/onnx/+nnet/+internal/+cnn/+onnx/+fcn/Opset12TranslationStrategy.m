classdef Opset12TranslationStrategy < nnet.internal.cnn.onnx.fcn.Opset11TranslationStrategy
    methods
        function nodeTranslation = translateArgMax(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"              "INT"  	true    0
                "keepdims"          "INT"  	true    1
                "select_last_index" "INT"   true    0
                });
            % Parse the attributes
            [axis, keepdims, select_last_index] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y       = node.output{1};
            X       = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxArgMax12(Vars.%s, %d, %d, %d, NumDims.%s);\n', Y, Y, X, axis, keepdims, select_last_index, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            if keepdims
                nodeTranslation.IncludedFunctionNames   = "onnxArgMax12";
            else
                nodeTranslation.IncludedFunctionNames   = ["onnxArgMax12", "onnxSqueeze"];
            end
            nodeTranslation.IntegerOutputTensorNames = string(Y);
        end

        function nodeTranslation = translateConstant(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "sparse_value"	"SPARSE_TENSOR"    true    []
                "value"         "TENSOR"    true    []
                "value_float"   "FLOAT"     true    []
                "value_floats"  "FLOATS"    true    []
                "value_int"     "INT"       true    []
                "value_ints"    "INTS"      true    []
                "value_string"  "STRING"    true    []
                "value_strings" "STRINGS"   true    []
                });
            % Parse the attributes
            [sparse_value, value, ...
                value_float, value_floats, ...
                value_int, value_ints, ...
                value_string, value_strings] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            
            % Get the output name
            Y = node.output{1};
            
            % According to ONNX Doc, exactly one of the attributes will be present.
            tensorValue = [];
            shape = [];
            if ~isempty(sparse_value)
                % Get the data from a SparseTensorProto
                [tensorValue, shape] = nnet.internal.cnn.onnx.getDataFromSparseTensorProto(sparse_value);
                if nnet.internal.cnn.onnx.isONNXTypeInteger(sparse_value.values.data_type)
                    nodeTranslation.IntegerOutputTensorNames = string(Y);
                end
            elseif ~isempty(value)
                % Get the data from a TensorProto
                [tensorValue, shape] = nnet.internal.cnn.onnx.getDataFromTensorProto(value);
                if nnet.internal.cnn.onnx.isONNXTypeInteger(value.data_type)
                    nodeTranslation.IntegerOutputTensorNames = string(Y);
                end
            elseif ~isempty(value_float)
                % Get the data from the value_float attribute
                tensorValue = value_float;
                shape = [];
            elseif ~isempty(value_floats)
                % Get the data from the value_floats attribute
                tensorValue = value_floats;
                shape = numel(tensorValue);
            elseif ~isempty(value_int)
                % Get the data from the value_int attribute
                tensorValue = value_int;
                shape = [];
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            elseif ~isempty(value_ints)
                % Get the data from the value_ints attribute
                tensorValue = value_ints;
                shape = numel(tensorValue);
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            elseif ~isempty(value_string)
                % Get the data from the value_string attribute
                tensorValue = value_string;
                shape = [];
            elseif ~isempty(value_strings)
                % Get the data from the value_strings attribute
                tensorValue = value_strings;
                shape = numel(tensorValue);
            else
                % NodeTranslationError - Exactly one of the attributes must
                % be set.
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                        message('nnet_cnn_onnx:onnx:MissingConstantValue'));
            end
            
            % Make the value a dlarray so it could be made learnable if
            % desired. Make it double because it's an activation tensor.
            if isnumeric(tensorValue)
                tensorValue = dlarray(double(tensorValue));  
            end
               
            % Construct the constant tensor at translation-time and add it to Nonlearnables
            if numel(shape)>1
                DLTShape = fliplr(shape(:)');
                tensorValue = reshape(tensorValue, DLTShape);   % Can just reshape the ONNX data because the memory ordering is the same in ONNX and DLT.
            end
            nodeTranslation.Nonlearnables = struct(Y, nnet.internal.cnn.onnx.fcn.RankedArray(tensorValue, numel(shape)));
           
        end        

        function nodeTranslation = translateDropout(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "seed"  "INT"   true    []
                });
            % Parse the attributes
            seed = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);            
            seedStr = "[]";
            if ~isempty(seed)
                seedStr = num2str(seed);
            end

            % Parse the inputs
            X = node.input{1};
            % The second and third inputs are both optional
            ratioName = '';
            if numel(node.input) > 1
                ratioName = node.input{2};
            end
            if numel(node.input) > 2
                training_mode = node.input{3};
                if ~isempty(training_mode)
                    % Throw a translation warning, telling the user that
                    % training_mode will be ignored.
                    nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                        message('nnet_cnn_onnx:onnx:TrainingModeAttrIgnored'));                    
                end
            end
            if isempty(ratioName)
                ratioName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Ratio']);
                defaultRatio = 0.5;
                nodeTranslation.Nonlearnables = struct(ratioName, nnet.internal.cnn.onnx.fcn.RankedArray(defaultRatio, 0));
            end

            Y = node.output{1};
            switch numel(node.output)
                case 1
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[Vars.%s, NumDims.%s] = onnxDropout12(Vars.%s, %s, Vars.%s, Training, NumDims.%s);\n', Y, Y, X, seedStr, ratioName, X),...
                        ];
                case 2
                    Mask = node.output{2};
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[Vars.%s, NumDims.%s, Vars.%s, NumDims.%s] = onnxDropout12(Vars.%s, %s, Vars.%s, Training, NumDims.%s);\n', Y, Y, Mask, Mask, X, seedStr, ratioName, X),...
                        ];
            end
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxDropout12";
        end   
        
        function nodeTranslation = translateLessOrEqual(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateInfixBinaryOperator(this, nodeTranslation, node, '<=', IntegerTensorNames);
        end        
    end
end
