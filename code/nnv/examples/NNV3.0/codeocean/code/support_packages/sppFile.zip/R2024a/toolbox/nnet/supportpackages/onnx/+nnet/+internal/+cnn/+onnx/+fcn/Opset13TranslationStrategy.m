classdef Opset13TranslationStrategy < nnet.internal.cnn.onnx.fcn.Opset12TranslationStrategy
    methods
        
        function nodeTranslation = translateHardmax(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       true    -1
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = hardmax(X)
            Y     = node.output{1};
            X     = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[axis, NumDims.%s] = prepareHardmax13Args(%d, NumDims.%s);\n', Y, axis, X),...
                sprintf('[~,I] = max(Vars.%s, [], axis, ''linear'');\n', X),...
                sprintf('Vars.%s = Vars.%s;\n', Y, X),...
                sprintf('Vars.%s(:) = 0;\n', Y),...
                sprintf('Vars.%s(I) = 1;\n', Y),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareHardmax13Args";
        end        
        
        function nodeTranslation = translateReduceSum(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "keepdims"              "INT"       true    1
                "noop_with_empty_axes"  "INT"       true    0
                });
            % Parse the attributes
            [keepdims, noop_with_empty_axes] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y	= node.output{1};
            X	= node.input{1};
            if numel(node.input) > 1 && ~isempty(node.input{2})
                % Axes is specified
                AxesName = node.input{2};
                command = [
                    sprintf('%% %s:\n', node.op_type),...
                    sprintf('dims = prepareReduceArgs(Vars.%s, NumDims.%s);\n', AxesName, X),...
                    sprintf('Vars.%s = sum(Vars.%s, dims);\n', Y, X),...
                    ];       
                if keepdims
                    nodeTranslation.IncludedFunctionNames   = "prepareReduceArgs";                                            
                    command = [command, sprintf('NumDims.%s = NumDims.%s;\n', Y, X)];
                else
                    nodeTranslation.IncludedFunctionNames   = ["prepareReduceArgs", "onnxSqueeze"];                                            
                    command = [command, sprintf('[Vars.%s, NumDims.%s] = onnxSqueeze(Vars.%s, Vars.%s, NumDims.%s);\n', Y, Y, Y, AxesName, X)];
                end
            else
                % Axes is empty
                if noop_with_empty_axes
                    % Do nothing
                    command = [
                        sprintf('%% %s:\n', node.op_type),...                        
                        sprintf('Vars.%s = Vars.%s;\n', Y, X),...
                        sprintf('NumDims.%s = NumDims.%s;\n', Y, X)
                    ];
                else
                    % Reduce all axes
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('dims = prepareReduceArgs([], NumDims.%s);\n', X),...
                        sprintf('Vars.%s = sum(Vars.%s, dims);\n', Y, X),...
                        ];                          
                    if keepdims
                        nodeTranslation.IncludedFunctionNames   = "prepareReduceArgs";                        
                        command = [command, sprintf('NumDims.%s = NumDims.%s;\n', Y, X)];
                    else
                        nodeTranslation.IncludedFunctionNames   = ["prepareReduceArgs", "onnxSqueeze"];                        
                        command = [command, sprintf('[Vars.%s, NumDims.%s] = onnxSqueeze(Vars.%s, [], NumDims.%s);\n', Y, Y, Y, X)];
                    end                                      
                end
            end

            nodeTranslation.MCode                   = string(command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end        

        function nodeTranslation = translateResize(~, nodeTranslation, node, IntegerTensorNames)
            % Resize-13 adds 5 attributes and 2 inputs.
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "coordinate_transformation_mode"    "STRING"    true    "half_pixel"
                "cubic_coeff_a"                     "FLOAT"     true    -0.75
                "exclude_outside"                   "INT"       true    0
                "extrapolation_value"               "FLOAT"     true    0.0
                "mode"                              "STRING"    true    "nearest"
                "nearest_mode"                      "STRING"    true    "round_prefer_floor"
                });
            % Parse the attributes
            [coordinate_transformation_mode,cubic_coeff_a, exclude_outside, extrapolation_value, mode, nearest_mode] ...
                = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            
            if isequal(coordinate_transformation_mode, "pytorch_half_pixel")
                coordinate_transformation_mode = "half_pixel";
            end
            
            if ~ismember(coordinate_transformation_mode, ["half_pixel", "asymmetric"]) || ...
                    ~isequal(cubic_coeff_a, -0.75) || ...
                    ~isequal(exclude_outside, 0) || ...
                    ~isequal(extrapolation_value, 0.0) || ...
                    ~ismember(mode, ["nearest", "linear"]) || ...
                    ~ismember(nearest_mode, ["floor", "round_prefer_floor"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:UnsupportedAttributeValue", mode, 'mode'));
                return;
            end
            % Gen code
            Y = node.output{1};
            X = node.input{1};

            % roi, scales, and sizes can be missing
            roiStr = iGetOptionalInputStr(2);
            scalesStr = iGetOptionalInputStr(3);
            sizesStr = iGetOptionalInputStr(4);

            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[DLTScales, DLTSizes, dataFormat, Method, GeometricTransformMode, NearestRoundingMode, NumDims.%s] = prepareResize11Args(%s, %s, %s, "%s", "%s", "%s", NumDims.%s);\n', ...
                Y, roiStr, scalesStr, sizesStr, coordinate_transformation_mode, mode, nearest_mode, X),...
                sprintf('if isempty(DLTScales)\n'),...
                sprintf('Vars.%s = dlresize(Vars.%s, ''OutputSize'', DLTSizes, ''DataFormat'', dataFormat, ''Method'', Method, ''GeometricTransformMode'', GeometricTransformMode, ''NearestRoundingMode'', NearestRoundingMode);\n', ...
                Y, X),...
                sprintf('else\n'),...
                sprintf('Vars.%s = dlresize(Vars.%s, ''Scale'', DLTScales, ''DataFormat'', dataFormat, ''Method'', Method, ''GeometricTransformMode'', GeometricTransformMode, ''NearestRoundingMode'', NearestRoundingMode);\n', ...
                Y, X),...
                sprintf('end\n'),...
                ];
            nodeTranslation.IncludedFunctionNames = "prepareResize11Args";
            nodeTranslation.MCode = string(command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
            % Add inputs 2,3, and 4 if present to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, node.input{2})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{2});
                nodeTranslation.Nonlearnables.(node.input{2}) = rankedArray;
            end
            if isInitializer(nodeTranslation.GraphTranslation, node.input{3})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{3});
                nodeTranslation.Nonlearnables.(node.input{3}) = rankedArray;
            end
            if numel(node.input)>3 && isInitializer(nodeTranslation.GraphTranslation, node.input{4})
                [data, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{4});
                nodeTranslation.Nonlearnables.(node.input{4}) = rankedArray;
            end

            function inputStr = iGetOptionalInputStr(inputIdx)
                if numel(node.input)<inputIdx || isempty(node.input{inputIdx})            
                    inputStr = "dlarray([])";
                else
                    inputStr = ['Vars.' node.input{inputIdx}];
                end
            end
        end

        function nodeTranslation = translateSoftmax(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       true    -1
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = softmax(X)
            Y     = node.output{1};
            X     = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxSoftmax13(Vars.%s, %d, NumDims.%s);\n', Y, Y, X, axis, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = ["onnxSoftmax13", "prepareReduceArgs"];
            
        end  
        
        function nodeTranslation = translateSplit(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"      "INT"       true    0
                });
            % Parse the attributes
            axis = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            OutputList  = strjoin(cellfun(@(s)strcat("Vars.", s), node.output), ', ');
            OutputRankList  = strjoin(cellfun(@(s)strcat("NumDims.", s), node.output), ', ');
            X         	= node.input{1};
            if numel(node.input)>1
                SplitName = node.input{2};
            else
                SplitName                       = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Split']);
                nodeTranslation.Nonlearnables   = struct(SplitName, nnet.internal.cnn.onnx.fcn.RankedArray(split,1));
            end
            numOutputs = numel(node.output);
            code = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[%s, %s] = onnxSplit13(Vars.%s, %d, Vars.%s, %d, NumDims.%s);\n', OutputList, OutputRankList, X, axis, SplitName, numOutputs, X),...
                ];
            
            nodeTranslation.MCode                   = string(code);
            nodeTranslation.IncludedFunctionNames   = "onnxSplit13";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(node.output);
            end
        end
        
        function nodeTranslation = translateSqueeze(~, nodeTranslation, node, IntegerTensorNames)
            % Y = squeeze(X, axes)
            Y       = node.output{1};
            X       = node.input{1};
            axes    = node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxSqueeze(Vars.%s, Vars.%s, NumDims.%s);\n', Y, Y, X, axes, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxSqueeze";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateUnsqueeze(~, nodeTranslation, node, IntegerTensorNames)
            % Y = unsqueeze(X, axes)
            Y       = node.output{1};
            X       = node.input{1};
            axes    = node.input{2};
            
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[shape, NumDims.%s] = prepareUnsqueezeArgs(Vars.%s, Vars.%s, NumDims.%s);\n', Y, X, axes, X),...
                sprintf('Vars.%s = reshape(Vars.%s, shape);\n', Y, X),...
                ];
            nodeTranslation.MCode = string(command);
            nodeTranslation.IncludedFunctionNames = "prepareUnsqueezeArgs";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end        
        
    end
end
