classdef Opset14TranslationStrategy < nnet.internal.cnn.onnx.fcn.Opset13TranslationStrategy
    methods

        function nodeTranslation = translateGRU(this, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "activation_alpha"	  "FLOATS"    true    0
                "activation_beta" 	  "FLOATS"    true    0
                "activations"         "STRINGS"   true    []
                "clip"                "FLOAT"     true    []
                "direction"           "STRING"    true    "forward"
                "hidden_size"    	  "INT"       false   []
                "linear_before_reset" "INT"       true    0
                "output_sequence"     "INT"       true    0
                "layout"              "INT"       true    0
                });
            % Parse the attributes
            [~, ~, activations, clip, direction, ~, linear_before_reset, ~, layout] = ...
                nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);

           if isempty(activations)
                zrAct  = 'sigmoid';
                hidAct = 'tanh';
            else
                zrAct  = iTranslateActivationFunction(activations{1});
                hidAct = iTranslateActivationFunction(activations{2});
            end
            
            % Check that attributes are valid
            if ~ismember(zrAct, ["sigmoid", "hard-sigmoid"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedDlarrayLSTMGateActivation'));
                return;
            end
            if ~ismember(hidAct, ["tanh", "softsign"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedDlarrayLSTMHiddenActivation'));
                return;
            end                            
            if linear_before_reset ~= 1
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedAttributeValue', linear_before_reset, 'linear_before_reset'));
                return;
            end
            if ~isempty(clip)
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedAttribute', 'clip'));
                return;
            end                
            if direction ~= "forward"
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:UnsupportedGRUDirection"));
                return;
            end

            inputDataFormat = 'CBT';
            if layout==1
                % layout 1 is not currently supported in any third party libraries.                
                % inputDataFormat = 'CTB'; % reverse-ONNX
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedAttributeValue', layout, 'layout'));
                return;                
            end

            % [Y, HIDDENSTATE, rankY, rankH] = GRU(X, W, R, B, sequence_lens, initial_h)
            Y           = '~';
            HIDDENSTATE = '~';
            rankY       = '~';
            rankH       = '~';
            X           = ['Vars.' node.input{1}];
            W           = ['Vars.' node.input{2}];
            R           = ['Vars.' node.input{3}];
            B           = "''";
            sequence_lens = "''";
            initial_h   = "''";
            % Process the 2 optional output arguments
            if numel(node.output) > 0 && ~isempty(node.output{1})
                Y     = ['Vars.' node.output{1}];
                rankY = ['NumDims.' node.output{1}];
            end
            if numel(node.output) > 1 && ~isempty(node.output{2})
                HIDDENSTATE = ['Vars.' node.output{2}];
                rankH       = ['NumDims.' node.output{2}];
            end
            % Process the 3 optional input arguments
            if numel(node.input) > 3 && ~isempty(node.input{4})
                B = ['Vars.' node.input{4}];
            end
            if numel(node.input) > 4 && ~isempty(node.input{5})
                sequence_lens = ['Vars.' node.input{5}];
            end
            if numel(node.input) > 5 && ~isempty(node.input{6})
                initial_h = ['Vars.' node.input{6}];
            end

            InputArgs = iStringifyEmpties({W, R, B, sequence_lens, initial_h}); % See ONNX GRU Doc for the meaning of these arguments.

            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[H0, WEIGHTS, RECURRENTWEIGHTS, BIAS, %s, %s] = prepareGRUArgs(%s, %s, %s, %s, %s);\n', rankY, rankH, InputArgs{:}),...
                sprintf('[%s, %s] = gru(%s, H0, WEIGHTS, RECURRENTWEIGHTS, BIAS, ''DataFormat'', ''%s'', ''StateActivationFunction'', ''%s'', ''GateActivationFunction'', ''%s'');\n', Y, HIDDENSTATE, X, inputDataFormat, hidAct, zrAct),...
                ];
            if Y~='~'
                % Sequence output is requested. Add code to reshape it:

% The layout 1 is not yet supported.                
%                 if layout==0
                    command = [command,...
                        sprintf('[C, B, T] = size(%s, 1:3);\n', Y),...
                        sprintf('%s = reshape(%s, [C B 1 T]);\n', Y, Y),...
                        ];
%                 else
%                     command = [command,...
%                         sprintf('[C, T, B] = size(%s, 1:3);\n', Y),...
%                         sprintf('%s = reshape(%s, [C 1 T B]);\n', Y, Y),...
%                     ];                                           
%                 end
            end
            nodeTranslation.IncludedFunctionNames   = "prepareGRUArgs";
            nodeTranslation.MCode                   = string(command);
            
            function C = iStringifyEmpties(C)
                for i = 1:numel(C)
                    if isempty(C{i})
                        C{i} = "''";
                    end
                end
            end
            
            function s = iTranslateActivationFunction(s)
                switch s
                    case 'Sigmoid'
                        s = 'sigmoid';
                    case 'Softsign'
                        s = 'softsign';
                    case 'Tanh'
                        s = 'tanh';
                    case 'HardSigmoid'
                        s = 'hard-sigmoid';
                    otherwise
                        % Maintain name for error message
                end
            end
        end        

        function nodeTranslation = translateLSTM(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "activation_alpha"	"FLOATS"    true    0
                "activation_beta" 	"FLOATS"    true    0
                "activations"       "STRINGS"   true    ["sigmoid","tanh","tanh"]
                "clip"              "FLOAT"     true    []
                "direction"         "STRING"    true    "forward"
                "hidden_size"    	"INT"       false   []
                "input_forget"    	"INT"       true    0
                "output_sequence"   "INT"       true    0
                "layout"            "INT"       true    0
                });
            % Parse the attributes
            [~, ~, activations, ~, direction, ~, ~, ~, layout] = ...
                nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            if isequal(direction, "reverse")
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:NoReverseLSTM"));
                return;
            end
            iofAct = itranslateActivationFunction(activations(1));
            cellAct = itranslateActivationFunction(activations(2));
            hidAct = itranslateActivationFunction(activations(3));
            % Check that activation functions are valid
            if ~ismember(iofAct, ["sigmoid", "hard-sigmoid"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:UnsupportedDlarrayLSTMGateActivation"));
                return;
            end
            if ~ismember(cellAct, ["tanh", "softsign", "relu"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:UnsupportedDlarrayLSTMCellActivation"));
                return;
            end
            if ~ismember(hidAct, ["tanh", "softsign", "relu"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:UnsupportedDlarrayLSTMHiddenActivation"));
                return;
            end
            if hidAct~=cellAct
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:CellAndHiddenActsUnequal"));
                return;
            end
            inputDataFormat = 'CBT';
            if layout==1
                % layout 1 is not currently supported in any third party libraries.                
                % inputDataFormat = 'CTB'; % reverse-ONNX
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedAttributeValue', layout, 'layout'));
                return;                
            end            
            % [Y, HIDDENSTATE, CELLSTATE, rankY, rankH, rankC] = LSTM(X, W, R, B, sequence_lens, initial_h, initial_c, P)
            Y           = '~';
            HIDDENSTATE = '~';
            CELLSTATE   = '~';
            rankY       = '~';
            rankH       = '~';
            rankC       = '~';
            X           = ['Vars.' node.input{1}];
            W           = ['Vars.' node.input{2}];
            R           = ['Vars.' node.input{3}];
            B           = "''";
            sequence_lens = "''";
            initial_h   = "''";
            initial_c   = "''";
            P           = "''";
            % Process the 3 optional output arguments
            if numel(node.output) > 0 && ~isempty(node.output{1})
                Y     = ['Vars.' node.output{1}];
                rankY = ['NumDims.' node.output{1}];
            end
            if numel(node.output) > 1 && ~isempty(node.output{2})
                HIDDENSTATE = ['Vars.' node.output{2}];
                rankH       = ['NumDims.' node.output{2}];
            end
            if numel(node.output) > 2 && ~isempty(node.output{3})
                CELLSTATE = ['Vars.' node.output{3}];
                rankC     = ['NumDims.' node.output{3}];
            end
            % Process the 5 optional input arguments
            if numel(node.input) > 3 && ~isempty(node.input{4})
                B = ['Vars.' node.input{4}];
            end
            if numel(node.input) > 4 && ~isempty(node.input{5})
                sequence_lens = ['Vars.' node.input{5}];
            end
            if numel(node.input) > 5 && ~isempty(node.input{6})
                initial_h = ['Vars.' node.input{6}];
            end
            if numel(node.input) > 6 && ~isempty(node.input{7})
                initial_c = ['Vars.' node.input{7}];
            end
            if numel(node.input) > 7 && ~isempty(node.input{8})
                P = ['Vars.' node.input{8}];
            end
            InputArgs = iStringifyEmpties({W, R, B, sequence_lens, initial_h, initial_c, P}); % See ONNX LSTM Doc for the meaning of these arguments.

            switch direction
                case 'forward'
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[H0, C0, WEIGHTS, RECURRENTWEIGHTS, BIAS, %s, %s, %s] = prepareLSTMArgs(%s, %s, %s, %s, %s, %s, %s);\n', rankY, rankH, rankC, InputArgs{:}),...
                        sprintf('[%s, %s, %s] = lstm(%s, H0, C0, WEIGHTS, RECURRENTWEIGHTS, BIAS, ''DataFormat'', ''%s'', ''StateActivationFunction'', ''%s'', ''GateActivationFunction'', ''%s'');\n', Y, HIDDENSTATE, CELLSTATE, X, inputDataFormat, hidAct, iofAct),...
                        ];
                    if Y~='~'
                        % Sequence output is requested. Add code to reshape it:                        
                        if layout==0
                            command = [command,...
                                sprintf('[C, B, T] = size(%s, 1:3);\n', Y),...
                                sprintf('%s = reshape(%s, [C B 1 T]);\n', Y, Y),...
                                ];
                        else
                            command = [command,...
                                sprintf('[C, T, B] = size(%s, 1:3);\n', Y),...
                                sprintf('%s = reshape(%s, [C 1 T B]);\n', Y, Y),...
                            ];                                           
                        end
                    end
                    nodeTranslation.IncludedFunctionNames   = "prepareLSTMArgs";
                case 'bidirectional'
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[%s, %s, %s, %s, %s, %s] = onnxBidirectionalLSTM(%s, %s, %s, %s, %s, %s, %s, %s);\n', Y, HIDDENSTATE, CELLSTATE, rankY, rankH, rankC, X, InputArgs{:}, hidAct, iofAct),...
                        ];
                    nodeTranslation.IncludedFunctionNames = "onnxBidirectionalLSTM";
                otherwise
                    assert(false);
            end
            nodeTranslation.MCode                   = string(command);
            
            function C = iStringifyEmpties(C)
                for i = 1:numel(C)
                    if isempty(C{i})
                        C{i} = "''";
                    end
                end
            end
            
            function s = itranslateActivationFunction(s)
                switch s
                    case 'Sigmoid'
                        s = 'sigmoid';
                    case 'Softsign'
                        s = 'softsign';
                    case 'Tanh'
                        s = 'tanh';
                    case 'HardSigmoid'
                        s = 'hard-sigmoid';
                    otherwise
                        % Maintain name for error message
                end
            end
        end

        function nodeTranslation = translateReshape(this, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "allowzero"	"INT"    true    0
                });
            % Parse the attributes
            allowzero = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);   
            B     = node.output{1};
            A     = node.input{1};
            SHAPE = node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[shape, NumDims.%s] = prepareReshapeArgs(Vars.%s, Vars.%s, NumDims.%s, %d);\n', B, A, SHAPE, A, allowzero),...
                sprintf('Vars.%s = reshape(Vars.%s, shape{:});\n', B, A),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareReshapeArgs";
            if ismember(A, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(B);
            end
            % Add SHAPE to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, SHAPE)
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, SHAPE);
                nodeTranslation.Nonlearnables.(SHAPE) = rankedArray;
            end
        end
    end
end