classdef Opset6TranslationStrategy
    % A strategy class implementing operator translators for opset version
    % 6.

    %   Copyright 2020-2021 The MathWorks, Inc.    
    methods
        function nodeTranslation = translateAbs(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'abs', IntegerTensorNames);
        end

        function nodeTranslation = translateAdd(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUniBroadcastInfixBinaryOp(this, nodeTranslation, node, '+', IntegerTensorNames);
        end

        function nodeTranslation = translateAnd(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUniBroadcastInfixBinaryOp(this, nodeTranslation, node, '&', IntegerTensorNames);
        end

        function nodeTranslation = translateArgMax(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"     	"INT"  	true    0
                "keepdims"	"INT"  	true    1
                });
            % Parse the attributes
            [axis, keepdims] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y       = node.output{1};
            X       = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxArgMax(Vars.%s, %d, %d, NumDims.%s);\n', Y, Y, X, axis, keepdims, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            if keepdims
                nodeTranslation.IncludedFunctionNames   = "onnxArgMax";
            else
                nodeTranslation.IncludedFunctionNames   = ["onnxArgMax", "onnxSqueeze"];
            end
            nodeTranslation.IntegerOutputTensorNames = string(Y);
        end
        
        function nodeTranslation = translateAveragePool(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "auto_pad"          "STRING"    true    "NOTSET"
                "count_include_pad"	"INT"       true    0
                "kernel_shape"      "INTS"      false   []
                "pads"              "INTS"      true    []
                "strides"           "INTS"      true    []
                });
            % Parse the attributes
            [auto_pad, count_include_pad, kernel_shape, pads, strides] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % auto_pad, pads
            numSpatialDims = numel(kernel_shape);
            padding = zeros(2*numSpatialDims,1);
            if auto_pad ~= "NOTSET"
                switch auto_pad
                    case "SAME_UPPER"
                        padding = "same";
                    case "SAME_LOWER"
                        padding = "same";
                        nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                            message("nnet_cnn_onnx:onnx:AutoPadSameLower"))];
                    case "VALID"
                        % Leave default
                    otherwise
                        % Leave default
                end
            elseif isempty(pads)
                padding = zeros(2*numSpatialDims,1);
            else
                padding = double(pads);
            end
            % strides
            if isempty(strides)
                strides = ones(numSpatialDims,1);
            end
            % Y = avgpool(X,POOLSIZE,...)
            Y        = node.output{1};
            X        = node.input{1};
            PoolsizeName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'PoolSize']);
            StrideName   = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Stride']);
            PaddingName  = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Padding']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[poolSize, stride, padding, paddingValue, dataFormat, NumDims.%s] = prepareAveragePoolArgs(Vars.%s, Vars.%s, Vars.%s, %d, NumDims.%s);\n',...
                Y, PoolsizeName, StrideName, PaddingName, count_include_pad, X),...
                sprintf('Vars.%s = avgpool(Vars.%s, poolSize, ''Stride'', stride, ''Padding'', padding, ''PaddingValue'', paddingValue, ''DataFormat'', dataFormat);\n', Y, X),...
                ];
            nodeTranslation.Nonlearnables           = struct(...
                PoolsizeName, nnet.internal.cnn.onnx.fcn.RankedArray(kernel_shape,1), ...
                StrideName, nnet.internal.cnn.onnx.fcn.RankedArray(strides,1), ...
                PaddingName, nnet.internal.cnn.onnx.fcn.RankedArray(padding,1));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareAveragePoolArgs";
        end

        function nodeTranslation = translateBatchNormalization(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "epsilon"      "FLOAT"      true    1e-5
                "momentum"     "FLOAT"  	true    0.9
                "spatial"      "INT"        true    1
                "is_test"      "INT"        true    0
                });
            % Parse the attributes
            [Epsilon, ~, spatial, ~] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            if Epsilon < single(1e-5)
                nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node, ...
                    message('nnet_cnn_onnx:onnx:BadEpsilon'))];
            end
            if spatial == 0
                nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                    message('nnet_cnn_onnx:onnx:PerChannelMean'))];
            end
            Epsilon         = double(max(Epsilon, 1e-5));
            ScaleName       = node.input{2};
            OffsetName      = node.input{3};
            meanName        = node.input{4};
            varName         = node.input{5};
            % The call to Batchnorm is followed by code that updates state variables:
            % [Y,DATASETMEAN,DATASETVARIANCE] = batchnorm(X,OFFSET,SCALE,DATASETMEAN,DATASETVARIANCE,'DataFormat',FMT)
            % state.DATASETMEAN               = DATASETMEAN;
            % state.DATASETVARIANCE           = DATASETVARIANCE;
            Y               = node.output{1};
            DATASETMEAN     = meanName;
            DATASETVARIANCE = varName;
            X               = node.input{1};
            OFFSET          = OffsetName;
            SCALE           = ScaleName;
            code = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[offset, scale, datasetMean, datasetVariance, dataFormat, NumDims.%s, NumDims.%s, NumDims.%s] = prepareBatchNormalizationArgs(Vars.%s, Vars.%s, Vars.%s, Vars.%s, NumDims.%s, NumDims.%s, NumDims.%s);\n',...
                Y, DATASETMEAN, DATASETVARIANCE, OFFSET, SCALE, DATASETMEAN, DATASETVARIANCE, X, DATASETMEAN, DATASETVARIANCE),...
                sprintf('if Training\n'),...
                sprintf('[Vars.%s, dsmean, dsvar] = batchnorm(Vars.%s, offset, scale, datasetMean, datasetVariance, ''Epsilon'', %f, ''DataFormat'', dataFormat);\n', Y, X, Epsilon),...
                sprintf('Vars.%s = dlarray(dsmean);\n', DATASETMEAN),...
                sprintf('Vars.%s = dlarray(dsvar);\n', DATASETVARIANCE),...
                sprintf('else\n'),...
                sprintf('Vars.%s = batchnorm(Vars.%s, offset, scale, datasetMean, datasetVariance, ''Epsilon'', %f, ''DataFormat'', dataFormat);\n', Y, X, Epsilon),...
                sprintf('end\n'),...
                sprintf('state.%s = Vars.%s;\n', DATASETMEAN, DATASETMEAN),...
                sprintf('state.%s = Vars.%s;\n', DATASETVARIANCE, DATASETVARIANCE)];
            nodeTranslation.InitialState            = struct(DATASETMEAN, [], DATASETVARIANCE, []);
            nodeTranslation.MCode                   = string(code);
            nodeTranslation.IncludedFunctionNames   = "prepareBatchNormalizationArgs";
        end
                        
        function nodeTranslation = translateCast(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "to"         "INT"       false    []
                });
            % Parse the attributes
            [to] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y = node.output{1};
            X = node.input{1};
            command = sprintf('%% %s:\n', node.op_type);
            % From TensorProto, 'to' can be:
            %     UNDEFINED = 0;
            %     // Basic types.
            %     FLOAT = 1;   // float
            %     UINT8 = 2;   // uint8_t
            %     INT8 = 3;    // int8_t
            %     UINT16 = 4;  // uint16_t
            %     INT16 = 5;   // int16_t
            %     INT32 = 6;   // int32_t
            %     INT64 = 7;   // int64_t
            %     STRING = 8;  // string
            %     BOOL = 9;    // bool
            % 
            %     // IEEE754 half-precision floating-point format (16 bits wide).
            %     // This format has 1 sign bit, 5 exponent bits, and 10 mantissa bits.
            %     FLOAT16 = 10;
            % 
            %     DOUBLE = 11;
            %     UINT32 = 12;
            %     UINT64 = 13;
            %     COMPLEX64 = 14;     // complex with float32 real and imaginary components
            %     COMPLEX128 = 15;    // complex with float64 real and imaginary components
            % 
            %     // Non-IEEE floating-point format based on IEEE754 single-precision
            %     // floating-point number truncated to 16 bits.
            %     // This format has 1 sign bit, 8 exponent bits, and 7 mantissa bits.
            %     BFLOAT16 = 16;
            
            % When casting to INTs, allow truncation, then convert back to
            % the original MATLAB type. Cast complex to double.
            switch to
                case {1, 10, 16}
                    command = [command, sprintf('Vars.%s = single(Vars.%s);\n', Y, X)];             
                case 2
                    command = [command, sprintf('Vars.%s = cast(uint8(extractdata(Vars.%s)), ''like'', Vars.%s);\n', Y, X, X)];
                    nodeTranslation.IntegerOutputTensorNames = string(Y);
                case 3
                    command = [command, sprintf('Vars.%s = cast(int8(extractdata(Vars.%s)), ''like'', Vars.%s);\n', Y, X, X)];
                    nodeTranslation.IntegerOutputTensorNames = string(Y);
                case 4
                    command = [command, sprintf('Vars.%s = cast(uint16(extractdata(Vars.%s)), ''like'', Vars.%s);\n', Y, X, X)];
                    nodeTranslation.IntegerOutputTensorNames = string(Y);
                case 5
                    command = [command, sprintf('Vars.%s = cast(int16(extractdata(Vars.%s)), ''like'', Vars.%s);\n', Y, X, X)];
                    nodeTranslation.IntegerOutputTensorNames = string(Y);
                case 6
                    command = [command, sprintf('Vars.%s = cast(int32(extractdata(Vars.%s)), ''like'', Vars.%s);\n', Y, X, X)];
                    nodeTranslation.IntegerOutputTensorNames = string(Y);
                case 7
                    command = [command, sprintf('Vars.%s = cast(int64(extractdata(Vars.%s)), ''like'', Vars.%s);\n', Y, X, X)];
                    nodeTranslation.IntegerOutputTensorNames = string(Y);
                case 8
                    command = [command, sprintf('Vars.%s = string(Vars.%s);\n', Y, X)];
                case 9
                    command = [command, sprintf('Vars.%s = logical(Vars.%s);\n', Y, X)];
                case {11, 14, 15}
                    command = [command, sprintf('Vars.%s = double(Vars.%s);\n', Y, X)];             
                case 12
                    command = [command, sprintf('Vars.%s = cast(uint32(extractdata(Vars.%s)), ''like'', Vars.%s);\n', Y, X, X)];
                    nodeTranslation.IntegerOutputTensorNames = string(Y);
                case 13
                    command = [command, sprintf('Vars.%s = cast(uint64(extractdata(Vars.%s)), ''like'', Vars.%s);\n', Y, X, X)];
                    nodeTranslation.IntegerOutputTensorNames = string(Y);
                otherwise
                    assert(false);
            end
            command = [command, sprintf('NumDims.%s = NumDims.%s;\n', Y, X)];
            nodeTranslation.MCode = string(command);
        end

        function nodeTranslation = translateCategoryMapper(~, nodeTranslation, node, ~)
            % https://github.com/onnx/onnx/blob/master/docs/Operators-ml.md#aionnxmlcategorymapper
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "cats_int64s"       "INTS"      false	[]
                "cats_strings"      "STRINGS"	false	[]
                "default_int64"     "INT"       true    -1
                "default_string"	"STRING"	true    '_Unused'
                });
            % Parse the attributes
            [cats_int64s, cats_strings, default_int64, default_string] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = CategoryMapper(X)
            Y = node.output{1};
            X = node.input{1};
            % _CatToInt is a fake Nonlearnable holding a Map from strings to integers.
            % _IntToCat is a fake Nonlearnable holding a Map from integers to strings.
            Cat2Int = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Cat2Int']);
            Int2Cat = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Int2Cat']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxCategoryMapper(Vars.%s, Vars.%s, Vars.%s, %d, "%s", NumDims.%s);\n',...
                Y, Y, X, Cat2Int, Int2Cat, default_int64, default_string, X),...
                ];
            % Put each map into struct (so it's 1x1), then into a ranked array of rank 0
            nodeTranslation.Nonlearnables = struct(...
                Cat2Int, nnet.internal.cnn.onnx.fcn.RankedArray(struct('map',containers.Map(cats_strings, cats_int64s)),0), ...
                Int2Cat, nnet.internal.cnn.onnx.fcn.RankedArray(struct('map',containers.Map(cats_int64s, cats_strings)),0));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxCategoryMapper";
            nodeTranslation.IntegerOutputTensorNames = string(Y);
        end           
        
        function nodeTranslation = translateCeil(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'ceil', IntegerTensorNames);
        end
        
        function nodeTranslation = translateClip(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "max"  	"FLOAT"     true    Inf
                "min" 	"FLOAT"  	true    -Inf
                });
            % Parse the attributes
            [Max, Min] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y       = node.output{1};
            X       = node.input{1};
            MinName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'min']);
            MaxName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'max']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = min(Vars.%s, max(Vars.%s, Vars.%s));\n', Y, MaxName, MinName, X),...
                sprintf('NumDims.%s = NumDims.%s;\n', Y, X),...
                ];
            nodeTranslation.Nonlearnables           = struct(MinName, nnet.internal.cnn.onnx.fcn.RankedArray(Min,0), MaxName, nnet.internal.cnn.onnx.fcn.RankedArray(Max,0));
            nodeTranslation.MCode                   = string(command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateConcat(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       false    []
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = cat(axis,X1,X2,...)
            Y       = node.output{1};
            nodeInputs = node.input;
            relabeledInputs = cellfun(@(s)['Vars.' s], nodeInputs, 'UniformOutput', false);
            nodeInputVars = strjoin(relabeledInputs, ', ');
            InputRanks = cellfun(@(s)['NumDims.' s], nodeInputs, 'UniformOutput', false);
            nodeInputRanks = strjoin(InputRanks, ', ');
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxConcat(%d, {%s}, [%s]);\n', Y, Y, axis, nodeInputVars, nodeInputRanks),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxConcat";
            if ismember(nodeInputs{1}, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
            % Add all initializer inputs to Nonlearnables
            for i=1:numel(nodeInputs)
                tensorName = nodeInputs{i};
                if isInitializer(nodeTranslation.GraphTranslation, tensorName)
                    [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, tensorName);
                    nodeTranslation.Nonlearnables.(tensorName) = rankedArray;
                end
            end
        end
        function nodeTranslation = translateConstant(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "value"      "TENSOR"    false    []
                });
            % Parse the attributes
            [value] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            [tensorValue, shape] = nnet.internal.cnn.onnx.getDataFromTensorProto(value);
            % Make the value a dlarray so it could be made learnable. Make
            % it double because it's potentially an activation tensor.
            tensorValue = dlarray(double(tensorValue));     
            % Construct the constant tensor at translation-time and add it to
            % Nonlearnables
            if numel(shape)>1
                DLTShape = fliplr(shape(:)');
                tensorValue = reshape(tensorValue, DLTShape);   % Can just reshape the ONNX data because the memory ordering is the same in ONNX and DLT.
            end
            Y = node.output{1};
            nodeTranslation.Nonlearnables = struct(Y, nnet.internal.cnn.onnx.fcn.RankedArray(tensorValue, numel(shape)));
            if nnet.internal.cnn.onnx.isONNXTypeInteger(value.data_type)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateConv(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "auto_pad"      "STRING"    true    "NOTSET"
                "dilations"     "INTS"      true    []
                "group"         "INT"       true    1
                "kernel_shape"  "INTS"      true    []
                "pads"          "INTS"      true    []
                "strides"       "INTS"      true    []
                });
            % Parse the attributes
            [auto_pad, dilations, group, ~, pads, strides] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % auto_pad, pads
            if auto_pad ~= "NOTSET"
                switch auto_pad
                    case "SAME_UPPER"
                        pads = "same";
                    case "SAME_LOWER"
                        pads = "same";
                        nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                            message("nnet_cnn_onnx:onnx:AutoPadSameLower"))];
                    case "VALID"
                        % Leave default
                    otherwise
                        % Leave default
                end
            elseif ~isempty(pads)
                pads = double(pads);
            end
            % group
            numWtGroups = group;
            % 2nd input is W and the 3rd input is B.
            if numel(node.input) > 2 && ~isempty(node.input{3})
                BIAS = ['Vars.' node.input{3}];
            else
                BIAS = "''";
            end
            % Y = dlconv(X,WEIGHTS,BIAS,...)
            Y               = node.output{1};
            X               = node.input{1};
            WEIGHTS         = node.input{2};
            StrideName      = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Stride']);
            DilationName    = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'DilationFactor']);
            PaddingName     = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Padding']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[weights, bias, stride, dilationFactor, padding, dataFormat, NumDims.%s] = prepareConvArgs(Vars.%s, %s, Vars.%s, Vars.%s, Vars.%s, %d, NumDims.%s, NumDims.%s);\n', ...
                Y, WEIGHTS, BIAS, StrideName, DilationName, PaddingName, numWtGroups, X, WEIGHTS),...
                sprintf('Vars.%s = dlconv(Vars.%s, weights, bias, ''Stride'', stride, ''DilationFactor'', dilationFactor, ''Padding'', padding, ''DataFormat'', dataFormat);\n', Y, X),...
                ];
            nodeTranslation.Nonlearnables           = struct(...
                StrideName, nnet.internal.cnn.onnx.fcn.RankedArray(strides,1), ...
                DilationName, nnet.internal.cnn.onnx.fcn.RankedArray(dilations,1),...
                PaddingName, nnet.internal.cnn.onnx.fcn.RankedArray(pads,1));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareConvArgs";
        end
        
        function nodeTranslation = translateConvTranspose(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "auto_pad"      "STRING"    true    "NOTSET"
                "dilations"     "INTS"      true    1
                "group"         "INT"       true    1
                "kernel_shape"  "INTS"      true    []
                "output_padding" "INTS"     true    []
                "output_shape"  "INTS"      true    []
                "pads"          "INTS"      true    []
                "strides"       "INTS"      true    []
                });
            % Parse the attributes
            [auto_pad, dilations, group, ~, output_padding, output_shape, pads, strides] = ...
                nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % auto_pad, pads
            if auto_pad ~= "NOTSET"
                switch auto_pad
                    case "SAME_UPPER"
                        pads = "same";
                    case "SAME_LOWER"
                        pads = "same";
                        nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                            message("nnet_cnn_onnx:onnx:AutoPadSameLower"))];
                    case "VALID"
                        % Leave default
                    otherwise
                        % Leave default
                end
            elseif ~isempty(pads)
                pads = double(pads);
            end
            % group
            numWtGroups = group;
            % output_padding
            if ~isempty(output_padding)
                nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedAttribute', 'output_padding'))];
                return;
            end
            % output_shape
            if ~isempty(output_shape)
                output_shape = double(output_shape);
            end
            % Y = dltranspconv(X,WEIGHTS,BIAS,...)
            Y            = node.output{1};
            X            = node.input{1};
            WEIGHTS      = node.input{2};
            if numel(node.input) > 2 && ~isempty(node.input{3})
                BiasTerm = sprintf("Vars.%s", node.input{3});
            else
                BiasTerm = "''";
            end
            StrideName   = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Stride']);
            DilationName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'DilationFactor']);
            PadsName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Pads']);
            OutputShapeName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'OutputShape']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[weights, bias, stride, dilation, cropping, dataFormat, NumDims.%s] = prepareConvTransposeArgs(Vars.%s, %s, Vars.%s, Vars.%s, Vars.%s, "%s", Vars.%s, %d, size(Vars.%s), NumDims.%s, NumDims.%s);\n',...
                Y, WEIGHTS, BiasTerm, StrideName, DilationName, PadsName, string(auto_pad), OutputShapeName, numWtGroups, X, X, WEIGHTS),...
                sprintf('Vars.%s = dltranspconv(Vars.%s, weights, bias, ''Stride'', stride, ''DilationFactor'', dilation, ''Cropping'', cropping, ''DataFormat'', dataFormat);\n',...
                Y, X),...
                ];
            nodeTranslation.Nonlearnables           = struct(...
                StrideName, nnet.internal.cnn.onnx.fcn.RankedArray(strides,1), ...
                DilationName, nnet.internal.cnn.onnx.fcn.RankedArray(dilations,1),...
                PadsName, nnet.internal.cnn.onnx.fcn.RankedArray(pads,1),...
                OutputShapeName, nnet.internal.cnn.onnx.fcn.RankedArray(output_shape,1));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareConvTransposeArgs";
        end
                
        function nodeTranslation = translateDepthToSpace(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "blocksize"     "INT"       false    []
                });
            % Parse the attributes
            [blocksize] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            
            Y        = node.output{1};
            X        = node.input{1};
            
            command = [
                sprintf('%% %s:\n', node.op_type),...
                            sprintf('Vars.%s = permute(depthToSpace(permute(Vars.%s,[2 1 3 4]),%d,''DataFormat'', [repmat(''S'',[1 NumDims.%s-2]),''CB'']), [2 1 3 4]);\n',...
                            Y, X, blocksize, X),...             
                            sprintf('NumDims.%s = 4;\n', Y), ...
                ];
            nodeTranslation.MCode                   = string(command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end

        function nodeTranslation = translateDiv(this, nodeTranslation, node, IntegerTensorNames)
            % This is a binary infix operator, but we're not calling
            % translateUniBroadcastInfixBinaryOp because we need to generate
            % different code when doing integer division.
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.            
            AttributeTable = cell2table({
                "axis"      "INT"   true    []
                "broadcast" "INT"   true    0
                });
            % Parse the attributes
            [axis, broadcast] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);            
            D       = node.output{1};
            A       = node.input{1};
            B       = node.input{2};
            Command = sprintf('%% %s:\n', node.op_type);
            if broadcast
                Command = [Command,...
                    sprintf('Vars.%s = prepareBroadcastInfixBinaryArgs(Vars.%s, %d);\n', B, B, axis)];
            end  
            if ismember(A, IntegerTensorNames)                
                divCommand = sprintf('Vars.%s = fix(Vars.%s ./ Vars.%s);\n', D, A, B);      % integer division
                nodeTranslation.IntegerOutputTensorNames = string(D);
            else
                divCommand = sprintf('Vars.%s = Vars.%s ./ Vars.%s;\n', D, A, B);           % float division
            end            
            Command = [Command,...
                divCommand,...
                sprintf('NumDims.%s = max(NumDims.%s, NumDims.%s);\n', D, A, B),...
                ];
            nodeTranslation.MCode = string(Command);
            % Add either of the inputs to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, A)
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, A);
                nodeTranslation.Nonlearnables.(A) = rankedArray;
            end
            if isInitializer(nodeTranslation.GraphTranslation, B)
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, B);
                nodeTranslation.Nonlearnables.(B) = rankedArray;
            end
            nodeTranslation.IncludedFunctionNames   = "prepareBroadcastInfixBinaryArgs";            
        end  
        
        function nodeTranslation = translateDropout(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "ratio"      "FLOAT"    true    0.5
                "is_test"    "INT"      true    0
                });
            % Parse the attributes
            [ratio, ~] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            X = node.input{1};
            Y = node.output{1};
            switch numel(node.output)
                case 1
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[Vars.%s, NumDims.%s] = onnxDropout7(Vars.%s, %f, Training, NumDims.%s);\n', Y, Y, X, ratio, X),...
                        ];
                case 2
                    Mask = node.output{2};
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[Vars.%s, NumDims.%s, Vars.%s, NumDims.%s] = onnxDropout7(Vars.%s, %f, Training, NumDims.%s);\n', Y, Y, Mask, Mask, X, ratio, X),...
                        ];
            end
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxDropout7";
        end
        
        function nodeTranslation = translateElu(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "alpha"       "FLOAT"      true    1
                });
            % Parse the attributes
            [alpha] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y = node.output{1};
            X = node.input{1};
            Command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxElu(Vars.%s, %f, NumDims.%s);\n', Y, Y, X, alpha, X),...
                ];
            nodeTranslation.MCode = string(Command);
            nodeTranslation.IncludedFunctionNames   = "onnxElu";
        end

        function nodeTranslation = translateEqual(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUniBroadcastInfixBinaryOp(this, nodeTranslation, node, '==', IntegerTensorNames);
        end        
        
        function nodeTranslation = translateExp(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'exp', IntegerTensorNames);
        end
        
        function nodeTranslation = translateFlatten(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       true    1
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y     = node.output{1};
            X     = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[dim1, dim2, NumDims.%s] = prepareFlattenArgs(Vars.%s, %d, NumDims.%s);\n', Y, X, axis, X),...
                sprintf('Vars.%s = reshape(Vars.%s, dim1, dim2);\n', Y, X),...
                ];
            nodeTranslation.MCode = string(command);
            nodeTranslation.IncludedFunctionNames = "prepareFlattenArgs";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateFloor(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'floor', IntegerTensorNames);
        end
        
        function nodeTranslation = translateGather(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       true    0
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y      = node.output{1};
            X      = node.input{1};
            idx    = node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxGather(Vars.%s, Vars.%s, %d, NumDims.%s, NumDims.%s);\n', Y, Y, X, idx, axis, X, idx),...
                ];
            nodeTranslation.MCode = string(command);
            nodeTranslation.IncludedFunctionNames = "onnxGather";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
            % Add input 2 to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, node.input{2})
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, node.input{2});
                nodeTranslation.Nonlearnables.(node.input{2}) = rankedArray;
            end
        end

        function nodeTranslation = translateGemm(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "alpha"        "FLOAT"      true    1
                "beta"         "FLOAT"      true    1
                "transA"       "INT"        true    0
                "transB"       "INT"        true    0
                "broadcast"    "INT"        true    0        
                });
            % Parse the attributes
            [alpha, beta, transA, transB, ~] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Translate into: Y = alpha * A' * B' + beta * C, where the transposes are
            % optional and indicated by transA and transB.
            Y = node.output{1};
            A = node.input{1};
            B = node.input{2};
            C = node.input{3};
            AlphaName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'alpha']);
            BetaName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'beta']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[A, B, C, alpha, beta, NumDims.%s] = prepareGemmArgs(Vars.%s, Vars.%s, Vars.%s, Vars.%s, Vars.%s, %s, %s, NumDims.%s);\n', ...
                Y, A, B, C, AlphaName, BetaName, string(transA), string(transB), C),...
                sprintf('Vars.%s = alpha*B*A + beta*C;\n', Y), ...
                ];
            nodeTranslation.Nonlearnables           = struct(AlphaName, nnet.internal.cnn.onnx.fcn.RankedArray(alpha,0), BetaName, nnet.internal.cnn.onnx.fcn.RankedArray(beta,0));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareGemmArgs";
            if ismember(A, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateGlobalAveragePool(~, nodeTranslation, node, ~)
            Y        = node.output{1};
            X        = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[poolsize, dataFormat, NumDims.%s] = prepareGlobalAveragePoolArgs(Vars.%s, NumDims.%s);\n', Y, X, X),...
                sprintf('Vars.%s = avgpool(Vars.%s, poolsize, ''DataFormat'', dataFormat);\n', Y, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareGlobalAveragePoolArgs";
        end
        
        function nodeTranslation = translateGlobalMaxPool(~, nodeTranslation, node, ~)
            Y        = node.output{1};
            X        = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[poolsize, dataFormat, NumDims.%s] = prepareGlobalMaxPoolArgs(Vars.%s, NumDims.%s);\n', Y, X, X),...
                sprintf('Vars.%s = maxpool(Vars.%s, poolsize, ''DataFormat'', dataFormat);\n', Y, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareGlobalMaxPoolArgs";
        end

        function nodeTranslation = translateGreater(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUniBroadcastInfixBinaryOp(this, nodeTranslation, node, '>', IntegerTensorNames);
        end

        function nodeTranslation = translateGRU(this, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "activation_alpha"	  "FLOATS"    true    0
                "activation_beta" 	  "FLOATS"    true    0
                "activations"         "STRINGS"   true    []
                "clip"                "FLOAT"     true    []
                "direction"           "STRING"    true    "forward"
                "hidden_size"    	  "INT"       false   []
                "linear_before_reset" "INT"       true    0
                "output_sequence"     "INT"       true    0
                });
            % Parse the attributes
            [~, ~, activations, clip, direction, ~, linear_before_reset, ~] = ...
                nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);

           if isempty(activations)
                zrAct  = 'sigmoid';
                hidAct = 'tanh';
            else
                zrAct  = iTranslateActivationFunction(activations{1});
                hidAct = iTranslateActivationFunction(activations{2});
            end
            
            % Check that attributes are valid
            if ~ismember(zrAct, ["sigmoid", "hard-sigmoid"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedDlarrayLSTMGateActivation'));
                return;
            end
            if ~ismember(hidAct, ["tanh", "softsign"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedDlarrayLSTMHiddenActivation'));
                return;
            end                            
            if linear_before_reset ~= 1
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedAttributeValue', linear_before_reset, 'linear_before_reset'));
                return;
            end
            if ~isempty(clip)
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:UnsupportedAttribute', 'clip'));
                return;
            end                
            if direction ~= "forward"
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:UnsupportedGRUDirection"));
                return;
            end

            % [Y, HIDDENSTATE, rankY, rankH] = GRU(X, W, R, B, sequence_lens, initial_h)
            Y           = '~';
            HIDDENSTATE = '~';
            rankY       = '~';
            rankH       = '~';
            X           = ['Vars.' node.input{1}];
            W           = ['Vars.' node.input{2}];
            R           = ['Vars.' node.input{3}];
            B           = "''";
            sequence_lens = "''";
            initial_h   = "''";
            % Process the 2 optional output arguments
            if numel(node.output) > 0 && ~isempty(node.output{1})
                Y     = ['Vars.' node.output{1}];
                rankY = ['NumDims.' node.output{1}];
            end
            if numel(node.output) > 1 && ~isempty(node.output{2})
                HIDDENSTATE = ['Vars.' node.output{2}];
                rankH       = ['NumDims.' node.output{2}];
            end
            % Process the 3 optional input arguments
            if numel(node.input) > 3 && ~isempty(node.input{4})
                B = ['Vars.' node.input{4}];
            end
            if numel(node.input) > 4 && ~isempty(node.input{5})
                sequence_lens = ['Vars.' node.input{5}];
            end
            if numel(node.input) > 5 && ~isempty(node.input{6})
                initial_h = ['Vars.' node.input{6}];
            end

            InputArgs = iStringifyEmpties({W, R, B, sequence_lens, initial_h}); % See ONNX GRU Doc for the meaning of these arguments.

            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[H0, WEIGHTS, RECURRENTWEIGHTS, BIAS, %s, %s] = prepareGRUArgs(%s, %s, %s, %s, %s);\n', rankY, rankH, InputArgs{:}),...
                sprintf('[%s, %s] = gru(%s, H0, WEIGHTS, RECURRENTWEIGHTS, BIAS, ''DataFormat'', ''CBT'', ''StateActivationFunction'', ''%s'', ''GateActivationFunction'', ''%s'');\n', Y, HIDDENSTATE, X, hidAct, zrAct),...
                ];
            if Y~='~'
                % Sequence output is requested. Add code to reshape it:
                command = [command,...
                    sprintf('[C, B, T] = size(%s, 1:3);\n', Y),...
                    sprintf('%s = reshape(%s, [C B 1 T]);\n', Y, Y),...
                    ];                
            end
            nodeTranslation.IncludedFunctionNames   = "prepareGRUArgs";
            nodeTranslation.MCode                   = string(command);
            
            function C = iStringifyEmpties(C)
                for i = 1:numel(C)
                    if isempty(C{i})
                        C{i} = "''";
                    end
                end
            end
            
            function s = iTranslateActivationFunction(s)
                switch s
                    case 'Sigmoid'
                        s = 'sigmoid';
                    case 'Softsign'
                        s = 'softsign';
                    case 'Tanh'
                        s = 'tanh';
                    case 'HardSigmoid'
                        s = 'hard-sigmoid';
                    otherwise
                        % Maintain name for error message
                end
            end
        end        

        function nodeTranslation = translateHardmax(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       true    1
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = hardmax(X)
            Y     = node.output{1};
            X     = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[dim1, dim2, origSize, NumDims.%s] = prepareHardmaxArgs(Vars.%s, %d, NumDims.%s);\n', Y, X, axis, X),...
                sprintf('Vars.%s = reshape(Vars.%s, dim1, dim2);\n', Y, X),...
                sprintf('[~,I] = max(Vars.%s, [], 1);\n', Y),...
                sprintf('linearIndices = (0:dim2-1)*dim1 + I;\n'),...
                sprintf('Vars.%s(:) = 0;\n', Y),...
                sprintf('Vars.%s(linearIndices) = 1;\n', Y),...
                sprintf('Vars.%s = reshape(Vars.%s, origSize);\n', Y, Y),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareHardmaxArgs";
        end
        
        function nodeTranslation = translateIdentity(~, nodeTranslation, node, IntegerTensorNames)
            Y = node.output{1};
            X = node.input{1};
            Command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = Vars.%s;\n', Y, X),...
                sprintf('NumDims.%s = NumDims.%s;\n', Y, X),...
                ];
            nodeTranslation.MCode = string(Command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateIf(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "else_branch"      "GRAPH"    false    []
                "then_branch"      "GRAPH"    false    []
                });
            % Parse the attributes
            [else_branch, then_branch] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            cond      = node.input{1};
            outputs   = node.output;
            ThenGraph = then_branch;
            ElseGraph = else_branch';
            ThenGraphFcnName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'ThenGraph']);
            ElseGraphFcnName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'ElseGraph']);
            % Recursive calls to translate the subgraphs
            ThenGraphTranslation = nnet.internal.cnn.onnx.fcn.GraphTranslation(ThenGraph, nodeTranslation.OpsetVersion, IntegerTensorNames, ThenGraphFcnName);
            ElseGraphTranslation = nnet.internal.cnn.onnx.fcn.GraphTranslation(ElseGraph, nodeTranslation.OpsetVersion, IntegerTensorNames, ElseGraphFcnName);
            % Generate code for the IF operator call. Like graph functions,
            % all operator functions that contain subgraphs take Vars,
            % NumDims, Training, state, and return outputs followed by the
            % state.
            %   [IfOutputVars, IfOutputRanks, state] = onnxIf(Vars.cond, @thenGraphFcnName, @elseGraphFcnName, Vars, NumDims, Training, state);
            %   if ~isempty(IfOutputs)
            %       [Vars.out1,...,Vars.outK] = IfOutputVars{:};
            %       [NumDims.out1,...,NumDims.outK] = IfOutputRanks{:};
            %   end
            numOutputVars = numel(outputs);
            outputVarList = strjoin(cellfun(@(s)['Vars.' s], outputs, 'UniformOutput', false), ', ');
            outputRankList = strjoin(cellfun(@(s)['NumDims.' s], outputs, 'UniformOutput', false), ', ');
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[%s, %s, state] = onnxIf(Vars.%s, @%s, @%s, %d, Vars, NumDims, Training, state);\n', outputVarList, outputRankList,cond, ThenGraphFcnName, ElseGraphFcnName, numOutputVars),...
                sprintf('Vars = appendStructs(Vars, state);')];
            nodeTranslation.InitialState            = nnet.internal.cnn.onnx.fcn.appendStructs(ThenGraphTranslation.InitialState, ElseGraphTranslation.InitialState);
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames	 = unique(["onnxIf", ThenGraphTranslation.IncludedFunctionNames, ElseGraphTranslation.IncludedFunctionNames]);
            nodeTranslation.Nonlearnables           = nnet.internal.cnn.onnx.fcn.appendStructs(ThenGraphTranslation.Nonlearnables, ElseGraphTranslation.Nonlearnables);
            nodeTranslation.SubgraphLearnables      = nnet.internal.cnn.onnx.fcn.appendStructs(ThenGraphTranslation.Learnables, ElseGraphTranslation.Learnables);
            nodeTranslation.SubgraphFunctionCode    = [ThenGraphTranslation.GraphFunctionCode, ElseGraphTranslation.GraphFunctionCode];
            nodeTranslation.SubgraphTranslations    = [ThenGraphTranslation, ElseGraphTranslation];
            
            thenTranslationIssues                   = arrayfun(@(nodeTranslation) nodeTranslation.Issues, ThenGraphTranslation.NodeTranslations, 'UniformOutput', false);
            elseTranslationIssues                   = arrayfun(@(nodeTranslation) nodeTranslation.Issues, ElseGraphTranslation.NodeTranslations, 'UniformOutput', false);
            nodeTranslation.Issues                  = [nodeTranslation.Issues, thenTranslationIssues{:}, elseTranslationIssues{:}];
        end
        
        function nodeTranslation = translateImageScaler(~, nodeTranslation, node, ~)
            % Bias : list of floats. Bias applied to each channel, same size as C.
            % Scale : float (scalar)
            Y = node.output{1};
            X = node.input{1};
            attributeNames = arrayfun(@(a) a.name, node.attribute,'UniformOutput',false);
            attributeFs = arrayfun(@(a) a.f, node.attribute,'UniformOutput',false);
            if ~isempty(attributeNames)
                attributeMap = containers.Map(attributeNames, attributeFs);
            end
            bias = double(0);
            scale = double(1);
            if ismember('scale', attributeNames)
                scale =  double(attributeMap('scale'));
            end
            if ismember('bias', attributeNames)
                bias =  double(attributeMap('bias'));
            end
            if isempty(bias)
                bias = double(0);
            end
            ScaleName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'scale']);
            BiasName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'bias']);
            Command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = Vars.%s .* Vars.%s + Vars.%s;\n', Y, X, ScaleName, BiasName),...
                sprintf('NumDims.%s = NumDims.%s;\n', Y, X),...
                ];
            nodeTranslation.Nonlearnables = struct(ScaleName, nnet.internal.cnn.onnx.fcn.RankedArray(scale,0), BiasName, nnet.internal.cnn.onnx.fcn.RankedArray(bias,2));
            nodeTranslation.MCode = string(Command);
        end
        
        function nodeTranslation = translateInstanceNormalization(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "epsilon"      "FLOAT"      true    1e-5
                });
            % Parse the attributes
            epsilon = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            if epsilon < single(1e-5)
                epsilon = double(1e-5);     
                nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node, ...
                    message('nnet_cnn_onnx:onnx:BadEpsilon'))];
            end
            ScaleName	= node.input{2};
            BName       = node.input{3};
            Y          	= node.output{1};
            X       	= node.input{1};
            code = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('if NumDims.%s > 2\n', X),...
                sprintf('Vars.%s = instancenorm(Vars.%s, Vars.%s, Vars.%s, ''Epsilon'', %f, ''DataFormat'', [repmat(''S'',[1 NumDims.%s-2]),''CB'']);\n',...
                Y, X, BName, ScaleName, epsilon, X),...
                sprintf('end\n'),...
                sprintf('NumDims.%s = NumDims.%s;\n', Y, X);
                ];
            nodeTranslation.MCode = string(code);
        end
        
        function nodeTranslation = translateLeakyRelu(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "alpha"       "FLOAT"      true    .01
                });
            % Parse the attributes
            [alpha] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y = node.output{1};
            X = node.input{1};
            Command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = leakyrelu(Vars.%s, %f);\n', Y, X, alpha),...
                sprintf('NumDims.%s = NumDims.%s;\n', Y, X),...
                ];
            nodeTranslation.MCode                   = string(Command);
        end

        function nodeTranslation = translateLess(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUniBroadcastInfixBinaryOp(this, nodeTranslation, node, '<', IntegerTensorNames);
        end        
        
        function nodeTranslation = translateLog(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'log', IntegerTensorNames);
        end
        
        function nodeTranslation = translateLoop(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "body"      "GRAPH"    false    []
                });
            % Parse the attributes
            [body] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            M           = node.input{1};
            cond        = node.input{2};
            v_initial	= node.input(3:end);            % "variadic. The initial values of any loop-carried dependencies (values that change across loop iterations)"
            v_final_and_scan_outputs = node.output;     % "Final N loop carried dependency values then K scan_outputs"
            numScanOutputs = numel(v_final_and_scan_outputs) - numel(v_initial);
            % Recursive call to translate the subgraph
            BodyGraphFcnName     = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'BodyGraph']);
            BodyGraphTranslation = nnet.internal.cnn.onnx.fcn.GraphTranslation(body, nodeTranslation.OpsetVersion, IntegerTensorNames, BodyGraphFcnName);
            % Generate code for the Loop operator call.
            %
            % Inputs: According to ONNX Doc, Loop takes 2+N variadic inputs
            % (iteration_num, condition, loop_carried_dependencies...).
            % There are N loop carried dependencies (LCDs). Our
            % loopOperator function will take 12 input arguments:
            % iteration_num, condition, v_initial(a cell of LCDs), then the
            % NumDims of the previous 3 args, then a handle to the "body"
            % subgraph, then the full Vars and NumDims structs, Training,
            % State, a handle to the subgraph function, and
            % numScanOutputs(which is needed to distinguish v_final from
            % scan_outputs).
            %
            % Outputs: According to ONNX Doc, Loop has variadic outputs
            % consisting of the N LCDs followed by K "scan outputs". Our
            % loopOperator function will return that, plus the NumDims of
            % those variables, and the updated State. Then there must be a
            % second line of code to update Vars from State.
            %
            %    [LCDAndScanOutputs,... LCDAndScanNumDims,... State] = loopOperator(Vars.M, Vars.cond, v_initialCell, @BodyGraphFcnName, Vars, NumDims, Training, state);
            %    Vars = appendStructs(Vars, State);     % This updates Vars from State.
            %
            v_initialVarList   = strjoin(cellfun(@(s)['Vars.' s], v_initial, 'UniformOutput', false), ', ');
            v_initialRanksList = strjoin(cellfun(@(s)['NumDims.' s], v_initial, 'UniformOutput', false), ', ');
            outputVarList      = strjoin(cellfun(@(s)['Vars.' s], v_final_and_scan_outputs, 'UniformOutput', false), ', ');
            outputRanksList    = strjoin(cellfun(@(s)['NumDims.' s], v_final_and_scan_outputs, 'UniformOutput', false), ', ');
            command = [...
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[%s, %s, state] = onnxLoop(Vars.%s, Vars.%s, {%s}, NumDims.%s, NumDims.%s, {%s}, Vars, NumDims, Training, state, @%s, %d);\n', ...
                outputVarList, outputRanksList, ...
                M, cond, v_initialVarList, ...
                M, cond, v_initialRanksList, ...
                BodyGraphFcnName, numScanOutputs),...
                sprintf('Vars = appendStructs(Vars, state);\n')];
            nodeTranslation.InitialState          	= BodyGraphTranslation.InitialState;
            nodeTranslation.MCode                	= string(command);
            nodeTranslation.IncludedFunctionNames	= unique(["onnxLoop", BodyGraphTranslation.IncludedFunctionNames]);
            nodeTranslation.Nonlearnables           = nnet.internal.cnn.onnx.fcn.appendStructs(nodeTranslation.Nonlearnables, BodyGraphTranslation.Nonlearnables);
            nodeTranslation.SubgraphLearnables    	= BodyGraphTranslation.Learnables;
            nodeTranslation.SubgraphFunctionCode  	= BodyGraphTranslation.GraphFunctionCode;
            nodeTranslation.SubgraphTranslations  	= BodyGraphTranslation;
            % Set IntegerOutputTensorNames to be the integer outputs of the subgraph
            isIntGraphOutput                        = arrayfun(@nnet.internal.cnn.onnx.isONNXTypeInteger, nodeTranslation.SubgraphTranslations.ExternalOutputTypes);
            nodeTranslation.IntegerOutputTensorNames = string(nodeTranslation.SubgraphTranslations.ExternalOutputNames(isIntGraphOutput));
            
            % Collect all translation issues
            bodyTranslationIssues                   = arrayfun(@(nodeTranslation) nodeTranslation.Issues, BodyGraphTranslation.NodeTranslations, 'UniformOutput', false);
            nodeTranslation.Issues                  = [nodeTranslation.Issues, bodyTranslationIssues{:}];
        end
        
        function nodeTranslation = translateLRN(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "alpha"    "FLOAT"      true    .0001
                "beta"     "FLOAT"  	true    .75
                "bias"     "FLOAT"      true    1
                "size"     "INT"        false   []
                });
            % Parse the attributes
            [alpha, beta, bias, windowSize] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = crosschannelnorm(X,CHANNELWINDOWSIZE,'DataFormat',FMT,...)
            Y               = node.output{1};
            X               = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = crosschannelnorm(Vars.%s, %d, ''Alpha'', %d, ''Beta'', %d, ''K'', %d, ''DataFormat'', [repmat(''S'', 1, NumDims.%s-2) ''CB'']);\n',...
                Y, X, windowSize, alpha, beta, bias, X),...
                sprintf('NumDims.%s = NumDims.%s;\n', Y, X),...
                ];
            nodeTranslation.MCode = string(command);
        end

        function nodeTranslation = translateLSTM(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "activation_alpha"	"FLOATS"    true    0
                "activation_beta" 	"FLOATS"    true    0
                "activations"       "STRINGS"   true    ["sigmoid","tanh","tanh"]
                "clip"              "FLOAT"     true    []
                "direction"         "STRING"    true    "forward"
                "hidden_size"    	"INT"       false   []
                "input_forget"    	"INT"       true    0
                "output_sequence"   "INT"       true    0
                });
            % Parse the attributes
            [~, ~, activations, ~, direction, ~, ~, ~] = ...
                nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            if isequal(direction, "reverse")
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:NoReverseLSTM"));
                return;
            end
            iofAct = itranslateActivationFunction(activations(1));
            cellAct = itranslateActivationFunction(activations(2));
            hidAct = itranslateActivationFunction(activations(3));
            % Check that activation functions are valid
            if ~ismember(iofAct, ["sigmoid", "hard-sigmoid"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:UnsupportedDlarrayLSTMGateActivation"));
                return;
            end
            if ~ismember(cellAct, ["tanh", "softsign", "relu"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:UnsupportedDlarrayLSTMCellActivation"));
                return;
            end
            if ~ismember(hidAct, ["tanh", "softsign", "relu"])
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:UnsupportedDlarrayLSTMHiddenActivation"));
                return;
            end
            if hidAct~=cellAct
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message("nnet_cnn_onnx:onnx:CellAndHiddenActsUnequal"));
                return;
            end
            % [Y, HIDDENSTATE, CELLSTATE, rankY, rankH, rankC] = LSTM(X, W, R, B, sequence_lens, initial_h, initial_c, P)
            Y           = '~';
            HIDDENSTATE = '~';
            CELLSTATE   = '~';
            rankY       = '~';
            rankH       = '~';
            rankC       = '~';
            X           = ['Vars.' node.input{1}];
            W           = ['Vars.' node.input{2}];
            R           = ['Vars.' node.input{3}];
            B           = "''";
            sequence_lens = "''";
            initial_h   = "''";
            initial_c   = "''";
            P           = "''";
            % Process the 3 optional output arguments
            if numel(node.output) > 0 && ~isempty(node.output{1})
                Y     = ['Vars.' node.output{1}];
                rankY = ['NumDims.' node.output{1}];
            end
            if numel(node.output) > 1 && ~isempty(node.output{2})
                HIDDENSTATE = ['Vars.' node.output{2}];
                rankH       = ['NumDims.' node.output{2}];
            end
            if numel(node.output) > 2 && ~isempty(node.output{3})
                CELLSTATE = ['Vars.' node.output{3}];
                rankC     = ['NumDims.' node.output{3}];
            end
            % Process the 5 optional input arguments
            if numel(node.input) > 3 && ~isempty(node.input{4})
                B = ['Vars.' node.input{4}];
            end
            if numel(node.input) > 4 && ~isempty(node.input{5})
                sequence_lens = ['Vars.' node.input{5}];
            end
            if numel(node.input) > 5 && ~isempty(node.input{6})
                initial_h = ['Vars.' node.input{6}];
            end
            if numel(node.input) > 6 && ~isempty(node.input{7})
                initial_c = ['Vars.' node.input{7}];
            end
            if numel(node.input) > 7 && ~isempty(node.input{8})
                P = ['Vars.' node.input{8}];
            end
            InputArgs = iStringifyEmpties({W, R, B, sequence_lens, initial_h, initial_c, P}); % See ONNX LSTM Doc for the meaning of these arguments.
            switch direction
                case 'forward'
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[H0, C0, WEIGHTS, RECURRENTWEIGHTS, BIAS, %s, %s, %s] = prepareLSTMArgs(%s, %s, %s, %s, %s, %s, %s);\n', rankY, rankH, rankC, InputArgs{:}),...
                        sprintf('[%s, %s, %s] = lstm(%s, H0, C0, WEIGHTS, RECURRENTWEIGHTS, BIAS, ''DataFormat'', ''CBT'', ''StateActivationFunction'', ''%s'', ''GateActivationFunction'', ''%s'');\n', Y, HIDDENSTATE, CELLSTATE, X, hidAct, iofAct),...
                        ];
                    if Y~='~'
                        % Sequence output is requested. Add code to reshape it:
                        command = [command,...
                            sprintf('[C, B, T] = size(%s, 1:3);\n', Y),...
                            sprintf('%s = reshape(%s, [C B 1 T]);\n', Y, Y),...
                            ];
                    end
                    nodeTranslation.IncludedFunctionNames   = "prepareLSTMArgs";
                case 'bidirectional'
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[%s, %s, %s, %s, %s, %s] = onnxBidirectionalLSTM(%s, %s, %s, %s, %s, %s, %s, %s, ''%s'', ''%s'');\n', Y, HIDDENSTATE, CELLSTATE, rankY, rankH, rankC, X, InputArgs{:}, hidAct, iofAct),...
                        ];
                    nodeTranslation.IncludedFunctionNames = "onnxBidirectionalLSTM";
                otherwise
                    assert(false);
            end
            nodeTranslation.MCode                   = string(command);
            
            function C = iStringifyEmpties(C)
                for i = 1:numel(C)
                    if isempty(C{i})
                        C{i} = "''";
                    end
                end
            end
            
            function s = itranslateActivationFunction(s)
                switch s
                    case 'Sigmoid'
                        s = 'sigmoid';
                    case 'Softsign'
                        s = 'softsign';
                    case 'Tanh'
                        s = 'tanh';
                    case 'HardSigmoid'
                        s = 'hard-sigmoid';
                    otherwise
                        % Maintain name for error message
                end
            end
        end
        
        function nodeTranslation = translateMatMul(~, nodeTranslation, node, IntegerTensorNames)
            % D = MatMul(A,B)
            D = node.output{1};
            A = node.input{1};
            B = node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxMatMul(Vars.%s, Vars.%s, NumDims.%s, NumDims.%s);\n', D, D, A, B, A, B),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxMatMul";
            if ismember(A, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(D);
            end
        end
        
        function nodeTranslation = translateMax(~, nodeTranslation, node, IntegerTensorNames)
            % ONNX: D = Max(A,B,C,...)
            D               = node.output{1};
            nodeInputs      = [node.input];
            relabeledInputs = cellfun(@(s)['Vars.' s], nodeInputs, 'UniformOutput', false);
            relabeledInputRanks = cellfun(@(s)['NumDims.' s], nodeInputs, 'UniformOutput', false);
            nodeInputVars   = strjoin(relabeledInputs, ', ');
            nodeInputRanks  = strjoin(relabeledInputRanks, ', ');
            Command = [sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxMax({%s}, [%s]);\n', D, D, nodeInputVars, nodeInputRanks),...
                ];
            nodeTranslation.MCode = string(Command);
            nodeTranslation.IncludedFunctionNames = "onnxMax";
            if ismember(nodeInputs{1}, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(D);
            end
        end

        function nodeTranslation = translateMaxPool(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "auto_pad"          "STRING"    true    "NOTSET"
                "kernel_shape"      "INTS"      false   []
                "pads"              "INTS"      true    []
                "strides"           "INTS"      true    []
                });
            % Parse the attributes
            [auto_pad,  kernel_shape, pads, strides] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % auto_pad, pads
            numSpatialDims = numel(kernel_shape);
            padding = zeros(2*numSpatialDims,1);
            if auto_pad ~= "NOTSET"
                switch auto_pad
                    case "SAME_UPPER"
                        padding = "same";
                    case "SAME_LOWER"
                        padding = "same";
                        nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                            message("nnet_cnn_onnx:onnx:AutoPadSameLower"))];
                    case "VALID"
                        % Leave default
                    otherwise
                        % Leave default
                end
            elseif isempty(pads)
                padding = zeros(2*numSpatialDims,1);
            else
                padding = double(pads);
            end
            % strides
            if isempty(strides)
                strides = ones(numSpatialDims,1);
            end
            % Y = maxpool(X,POOLSIZE,...)
            Y        = node.output{1};
            X        = node.input{1};
            PoolsizeName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'PoolSize']);
            StrideName   = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Stride']);
            PaddingName  = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Padding']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[poolsize, stride, padding, dataFormat, NumDims.%s] = prepareMaxPool7Args(Vars.%s, Vars.%s, Vars.%s, NumDims.%s);\n', Y, PoolsizeName, StrideName, PaddingName, X),...
                sprintf('Vars.%s = maxpool(Vars.%s, poolsize, ''Stride'', stride, ''Padding'', padding, ''DataFormat'', dataFormat);\n', Y, X),...
                ];
            nodeTranslation.Nonlearnables           = struct(...
                PoolsizeName, nnet.internal.cnn.onnx.fcn.RankedArray(kernel_shape,1), ...
                StrideName, nnet.internal.cnn.onnx.fcn.RankedArray(strides,1), ...
                PaddingName, nnet.internal.cnn.onnx.fcn.RankedArray(padding,1));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareMaxPool7Args";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateMin(~, nodeTranslation, node, IntegerTensorNames)
            % ONNX: D = Min(A,B,C,...)
            D               = node.output{1};
            nodeInputs      = [node.input];
            relabeledInputs = cellfun(@(s)['Vars.' s], nodeInputs, 'UniformOutput', false);
            relabeledInputRanks = cellfun(@(s)['NumDims.' s], nodeInputs, 'UniformOutput', false);
            nodeInputVars   = strjoin(relabeledInputs, ', ');
            nodeInputRanks  = strjoin(relabeledInputRanks, ', ');
            Command = [sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxMin({%s}, [%s]);\n', D, D, nodeInputVars, nodeInputRanks),...
                ];
            nodeTranslation.MCode = string(Command);
            nodeTranslation.IncludedFunctionNames = "onnxMin";
            if ismember(nodeInputs{1}, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(D);
            end
        end

        function nodeTranslation = translateMul(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUniBroadcastInfixBinaryOp(this, nodeTranslation, node, '.*', IntegerTensorNames);
        end        

        function nodeTranslation = translateNeg(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, '-', IntegerTensorNames);
        end   

        function nodeTranslation = translateNot(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'not', IntegerTensorNames);
        end        

        function nodeTranslation = translateOr(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUniBroadcastInfixBinaryOp(this, nodeTranslation, node, '|', IntegerTensorNames);
        end             
        
        function nodeTranslation = translatePad(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "mode"      "STRING"    true    "constant"
                "pads"  	"INTS"      false 	[]
                "value" 	"FLOAT"     true    0
                });
            % Parse the attributes
            [mode, pads, value] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = onnxPad(X, padding, value)
            Y         	= node.output{1};
            X         	= node.input{1};
            PaddingName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Padding']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxPad(Vars.%s, Vars.%s, %f, ''%s'', NumDims.%s);\n', Y, Y, X, PaddingName, value, mode, X)];
            nodeTranslation.Nonlearnables           = struct(PaddingName, nnet.internal.cnn.onnx.fcn.RankedArray(pads,2));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxPad";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end

        function nodeTranslation = translatePow(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUniBroadcastInfixBinaryOp(this, nodeTranslation, node, '.^', IntegerTensorNames);
        end          

        function nodeTranslation = translatePRelu(~, nodeTranslation, node, IntegerTensorNames)
            Y = node.output{1};
            X = node.input{1};
            slope	= node.input{2};
            Command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = max(0,Vars.%s) + Vars.%s.*min(0,Vars.%s);\n', Y, X, slope, X),...
                sprintf('NumDims.%s = NumDims.%s;\n', Y, X),...
                ];
            nodeTranslation.MCode = string(Command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end

        function nodeTranslation = translateRandomUniform(~, nodeTranslation, node, ~) 
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "dtype"     "INT"      true    1  
                "high"      "FLOAT"    true    1.0
                "low"       "FLOAT"    true    0.0
                "seed"      "FLOAT"    true    []  
                "shape"     "INTS"     false   []
                });
            % Parse the attributes
            [dtype, high, low, seed, shape] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % From TensorProto, dtype can be:
            %     UNDEFINED = 0;
            %     // Basic types.
            %     FLOAT = 1;   // float
            %     UINT8 = 2;   // uint8_t
            %     INT8 = 3;    // int8_t
            %     UINT16 = 4;  // uint16_t
            %     INT16 = 5;   // int16_t
            %     INT32 = 6;   // int32_t
            %     INT64 = 7;   // int64_t
            %     STRING = 8;  // string
            %     BOOL = 9;    // bool
            output   = node.output{1};
            DLTShape = fliplr(shape(:)');   % Reverse-onnx shape as a row vector
            ShapeStr = strjoin(string(DLTShape), ', ');
            command = sprintf('%% %s:\n', node.op_type);
            if ~isempty(seed)
                command = [command, sprintf('rng(%f);\n', seed)];
            end
            if ismember(dtype, [2 3 4 5 6 7 9])
                % Random integer or bool
                command = [command, sprintf('Vars.%s = dlarray(round(rand([%s])*(%d - %d) + %d));\n', output, ShapeStr, high, low, low)];
                nodeTranslation.IntegerOutputTensorNames = string(output);
            else
                % Random float
                command = [command, sprintf('Vars.%s = dlarray(rand([%s])*(%d - %d) + %d);\n', output, ShapeStr, high, low, low)];
            end
            command = [command, sprintf('NumDims.%s = %d;\n', output, numel(shape))];
            nodeTranslation.MCode = string(command);
        end

        function nodeTranslation = translateReciprocal(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, '1./', IntegerTensorNames);
        end
                
        function nodeTranslation = translateReduceL2(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axes"          "INTS"      true    []
                "keepdims"      "INT"       true    1
                });
            % Parse the attributes
            [axes, keepdims] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y	= node.output{1};
            X	= node.input{1};
            AxesName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Axes']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('dims = prepareReduceArgs(Vars.%s, NumDims.%s);\n', AxesName, X),...
                ];
            if ismember(X, IntegerTensorNames)
                command = [command, sprintf('Vars.%s = fix(sqrt(sum(Vars.%s.^2, dims)));\n', Y, X)];
            else
                command = [command, sprintf('Vars.%s = sqrt(sum(Vars.%s.^2, dims));\n', Y, X)];
            end
            if keepdims
                command = [command, sprintf('NumDims.%s = NumDims.%s;\n', Y, X)];
            else
                command = [command, sprintf('[Vars.%s, NumDims.%s] = onnxSqueeze(Vars.%s, Vars.%s, NumDims.%s);\n', Y, Y, Y, AxesName, X)];
            end
            nodeTranslation.Nonlearnables           = struct(AxesName, nnet.internal.cnn.onnx.fcn.RankedArray(axes,2));
            nodeTranslation.MCode                   = string(command);
            if keepdims
                nodeTranslation.IncludedFunctionNames   = "prepareReduceArgs";
            else
                nodeTranslation.IncludedFunctionNames   = ["prepareReduceArgs", "onnxSqueeze"];
            end
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
 
        function nodeTranslation = translateReduceMax(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axes"          "INTS"      true    []
                "keepdims"      "INT"       true    1
                });
            % Parse the attributes
            [axes, keepdims] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y	= node.output{1};
            X	= node.input{1};
            AxesName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Axes']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('dims = prepareReduceArgs(Vars.%s, NumDims.%s);\n', AxesName, X),...
                sprintf('Vars.%s = max(Vars.%s, [], dims);\n', Y, X),...
                ];
            if keepdims
                command = [command, sprintf('NumDims.%s = NumDims.%s;\n', Y, X)];
            else
                command = [command, sprintf('[Vars.%s, NumDims.%s] = onnxSqueeze(Vars.%s, Vars.%s, NumDims.%s);\n', Y, Y, Y, AxesName, X)];
            end
            nodeTranslation.Nonlearnables           = struct(AxesName, nnet.internal.cnn.onnx.fcn.RankedArray(axes,2));
            nodeTranslation.MCode                   = string(command);
            if keepdims
                nodeTranslation.IncludedFunctionNames   = "prepareReduceArgs";
            else
                nodeTranslation.IncludedFunctionNames   = ["prepareReduceArgs", "onnxSqueeze"];
            end
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateReduceMean(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axes"          "INTS"      true    []
                "keepdims"      "INT"       true    1
                });
            % Parse the attributes
            [axes, keepdims] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y	= node.output{1};
            X	= node.input{1};
            AxesName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Axes']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('dims = prepareReduceArgs(Vars.%s, NumDims.%s);\n', AxesName, X),...
                ];
            if ismember(X, IntegerTensorNames)
                command = [command, sprintf('Vars.%s = fix(mean(Vars.%s, dims));\n', Y, X)];
            else
                command = [command, sprintf('Vars.%s = mean(Vars.%s, dims);\n', Y, X)];
            end
            if keepdims
                command = [command, sprintf('NumDims.%s = NumDims.%s;\n', Y, X)];
            else
                command = [command, sprintf('[Vars.%s, NumDims.%s] = onnxSqueeze(Vars.%s, Vars.%s, NumDims.%s);\n', Y, Y, Y, AxesName, X)];
            end
            nodeTranslation.Nonlearnables           = struct(AxesName, nnet.internal.cnn.onnx.fcn.RankedArray(axes,2));
            nodeTranslation.MCode                   = string(command);
            if keepdims
                nodeTranslation.IncludedFunctionNames   = "prepareReduceArgs";
            else
                nodeTranslation.IncludedFunctionNames   = ["prepareReduceArgs", "onnxSqueeze"];
            end
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateReduceMin(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axes"          "INTS"      true    []
                "keepdims"      "INT"       true    1
                });
            % Parse the attributes
            [axes, keepdims] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y	= node.output{1};
            X	= node.input{1};
            AxesName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Axes']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('dims = prepareReduceArgs(Vars.%s, NumDims.%s);\n', AxesName, X),...
                sprintf('Vars.%s = min(Vars.%s, [], dims);\n', Y, X),...
                ];
            if keepdims
                command = [command, sprintf('NumDims.%s = NumDims.%s;\n', Y, X)];
            else
                command = [command, sprintf('[Vars.%s, NumDims.%s] = onnxSqueeze(Vars.%s, Vars.%s, NumDims.%s);\n', Y, Y, Y, AxesName, X)];
            end
            nodeTranslation.Nonlearnables           = struct(AxesName, nnet.internal.cnn.onnx.fcn.RankedArray(axes,2));
            nodeTranslation.MCode                   = string(command);
            if keepdims
                nodeTranslation.IncludedFunctionNames   = "prepareReduceArgs";
            else
                nodeTranslation.IncludedFunctionNames   = ["prepareReduceArgs", "onnxSqueeze"];
            end
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateReduceProd(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axes"          "INTS"      true    []
                "keepdims"      "INT"       true    1
                });
            % Parse the attributes
            [axes, keepdims] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y	= node.output{1};
            X	= node.input{1};
            AxesName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Axes']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('dims = prepareReduceArgs(Vars.%s, NumDims.%s);\n', AxesName, X),...
                sprintf('Vars.%s = prod(Vars.%s, dims);\n', Y, X),...
                ];
            if keepdims
                command = [command, sprintf('NumDims.%s = NumDims.%s;\n', Y, X)];
            else
                command = [command, sprintf('[Vars.%s, NumDims.%s] = onnxSqueeze(Vars.%s, Vars.%s, NumDims.%s);\n', Y, Y, Y, AxesName, X)];
            end
            nodeTranslation.Nonlearnables           = struct(AxesName, nnet.internal.cnn.onnx.fcn.RankedArray(axes,2));
            nodeTranslation.MCode                   = string(command);
            if keepdims
                nodeTranslation.IncludedFunctionNames   = "prepareReduceArgs";
            else
                nodeTranslation.IncludedFunctionNames   = ["prepareReduceArgs", "onnxSqueeze"];
            end
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateReduceSum(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axes"          "INTS"      true    []
                "keepdims"      "INT"       true    1
                });
            % Parse the attributes
            [axes, keepdims] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y	= node.output{1};
            X	= node.input{1};
            AxesName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Axes']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('dims = prepareReduceArgs(Vars.%s, NumDims.%s);\n', AxesName, X),...
                sprintf('Vars.%s = sum(Vars.%s, dims);\n', Y, X),...
                ];
            if keepdims
                command = [command, sprintf('NumDims.%s = NumDims.%s;\n', Y, X)];
            else
                command = [command, sprintf('[Vars.%s, NumDims.%s] = onnxSqueeze(Vars.%s, Vars.%s, NumDims.%s);\n', Y, Y, Y, AxesName, X)];
            end
            nodeTranslation.Nonlearnables           = struct(AxesName, nnet.internal.cnn.onnx.fcn.RankedArray(axes,2));
            nodeTranslation.MCode                   = string(command);
            if keepdims
                nodeTranslation.IncludedFunctionNames   = "prepareReduceArgs";
            else
                nodeTranslation.IncludedFunctionNames   = ["prepareReduceArgs", "onnxSqueeze"];
            end
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end

        function nodeTranslation = translateRelu(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'relu', IntegerTensorNames);
        end
        
        function nodeTranslation = translateReshape(~, nodeTranslation, node, IntegerTensorNames)
            % B = reshape(A, SHAPE)
            B     = node.output{1};
            A     = node.input{1};
            SHAPE = node.input{2};
            allowzero = 0; % Infer shape if it has value 0
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[shape, NumDims.%s] = prepareReshapeArgs(Vars.%s, Vars.%s, NumDims.%s, %d);\n', B, A, SHAPE, A, allowzero),...
                sprintf('Vars.%s = reshape(Vars.%s, shape{:});\n', B, A),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareReshapeArgs";
            if ismember(A, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(B);
            end
            % Add SHAPE to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, SHAPE)
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, SHAPE);
                nodeTranslation.Nonlearnables.(SHAPE) = rankedArray;
            end
        end
        
        function nodeTranslation = translateShape(~, nodeTranslation, node, ~)
            Y = node.output{1};
            X = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxShape(Vars.%s, NumDims.%s);\n',...
                Y, Y, X, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxShape";
            nodeTranslation.IntegerOutputTensorNames = string(Y);
        end
        
        function nodeTranslation = translateSigmoid(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'sigmoid', IntegerTensorNames);
        end

        function nodeTranslation = translateSoftmax(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       true    1
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = softmax(X)
            Y     = node.output{1};
            X     = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[dim1, dim2, origSize, NumDims.%s] = prepareSoftmaxArgs(Vars.%s, %d, NumDims.%s);\n', Y, X, axis, X),...
                sprintf('Vars.%s = reshape(Vars.%s, dim1, dim2);\n', Y, X),...
                sprintf('Vars.%s = softmax(Vars.%s, ''DataFormat'', ''CB'');\n', Y, Y),...
                sprintf('Vars.%s = reshape(Vars.%s, origSize);\n', Y, Y),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareSoftmaxArgs";
        end
        
        function nodeTranslation = translateSlice(~, nodeTranslation, node, IntegerTensorNames)
            Y       = node.output{1};
            X       = node.input{1};
            % Y = slice(X), with attributes: Axes, End, Starts. (Steps are always 1).
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axes"     "INTS"      true     []
                "ends"     "INTS"      false    []
                "starts"   "INTS"      false    []
                });
            % Parse the attributes
            [Axes, Ends, Starts] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Steps = '';
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Indices, NumDims.%s] = prepareSliceArgs(Vars.%s, [%s], [%s], [%s], [%s], NumDims.%s);\n',...
                Y, X, strjoin(string(Starts), ', '), strjoin(string(Ends), ', '), strjoin(string(Axes), ', '), Steps, X),...
                sprintf('Vars.%s = subsref(Vars.%s, Indices);\n', Y, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareSliceArgs";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
                         
        function nodeTranslation = translateSpaceToDepth(~, nodeTranslation, node, ~)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "blocksize"     "INT"       false    []
                });
            % Parse the attributes
            [blocksize] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = onnxSpaceToDepth(X, blocksize);
            Y        = node.output{1};
            X        = node.input{1};
            
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = permute(spaceToDepth(permute(Vars.%s,[2 1 3 4]),%d, ''DataFormat'', [repmat(''S'',[1 NumDims.%s-2]),''CB'']),[2 1 3 4]);\n',...
                Y, X, blocksize, X),...
                sprintf('NumDims.%s = 4;\n', Y), ...
                ];
            nodeTranslation.MCode                   = string(command);
        end

        function nodeTranslation = translateSplit(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"      "INT"       true    0
                "split"     "INTS"      true    []
                });
            % Parse the attributes
            [axis, split] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % optional split attribute. If missing, "the tensor is split to equal sized
            % parts" (one per output variable).
            if isempty(split)
                numSplits = numel(node.output);
            else
                numSplits = 0;
            end
            SplitName  	= nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Split']);
            OutputList  = strjoin(cellfun(@(s)strcat("Vars.", s), node.output), ', ');
            OutputRankList  = strjoin(cellfun(@(s)strcat("NumDims.", s), node.output), ', ');
            X         	= node.input{1};
            code = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[%s, %s] = onnxSplit(Vars.%s, %d, Vars.%s, %d, NumDims.%s);\n', OutputList, OutputRankList, X, axis, SplitName, numSplits, X),...
                ];
            nodeTranslation.Nonlearnables           = struct(SplitName, nnet.internal.cnn.onnx.fcn.RankedArray(split,2));
            nodeTranslation.MCode                   = string(code);
            nodeTranslation.IncludedFunctionNames   = "onnxSplit";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(node.output);
            end
        end
        
        function nodeTranslation = translateSqrt(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'sqrt', IntegerTensorNames);
        end
        
        function nodeTranslation = translateSqueeze(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axes"     "INTS"      true    []
                });
            % Parse the attributes
            [axes] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            AxesName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Axes']);
            % Y = Squeeze(X, axes)
            Y       = node.output{1};
            X       = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxSqueeze(Vars.%s, Vars.%s, NumDims.%s);\n', Y, Y, X, AxesName, X),...
                ];
            nodeTranslation.Nonlearnables           = struct(AxesName, nnet.internal.cnn.onnx.fcn.RankedArray(axes,2));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxSqueeze";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end

        function nodeTranslation = translateSub(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUniBroadcastInfixBinaryOp(this, nodeTranslation, node, '-', IntegerTensorNames);
        end

        function nodeTranslation = translateSum(~, nodeTranslation, node, ~)
            % ONNX: D = Sum(A,B,C,...)
            % DLT:  D = A+B+C...
            D               = node.output{1};
            nodeInputs      = [node.input];
            relabeledInputs = cellfun(@(s)['Vars.' s], nodeInputs, 'UniformOutput', false);
            relabeledInputRanks = cellfun(@(s)['NumDims.' s], nodeInputs, 'UniformOutput', false);
            nodeInputVars   = strjoin(relabeledInputs, ' + ');
            nodeInputRanks  = strjoin(relabeledInputRanks, ', ');
            Command = [sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = %s;\n', D,  nodeInputVars),...
                sprintf('NumDims.%s = max([%s]);\n', D, nodeInputRanks),...
                ];
            nodeTranslation.MCode = string(Command);
        end
        
        function nodeTranslation = translateTanh(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'tanh', IntegerTensorNames);
        end
        
        function nodeTranslation = translateTile(~, nodeTranslation, node, IntegerTensorNames)
            % B = Tile(A, repeats)
            B     = node.output{1};
            A     = node.input{1};
            repeats = node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[sz, NumDims.%s] = prepareTileArgs(Vars.%s);\n', B, repeats),...
                sprintf('Vars.%s = repmat(Vars.%s, sz);\n', B, A),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareTileArgs";
            if ismember(A, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(B);
            end
        end
        
        function nodeTranslation = translateTopK(~, nodeTranslation, node, IntegerTensorNames)
            % K is an attribute.
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"      "INT"       true    -1
                "k"         "INT"       false    []
                });
            % Parse the attributes
            [axis, k] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % [T, I] = TopK(X)
            T	= node.output{1};
            I 	= node.output{2};
            X	= node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, Vars.%s, NumDims.%s, NumDims.%s] = onnxTopK(Vars.%s, %d, %d, NumDims.%s);\n', T, I, T, I, X, k, axis, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxTopK";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(T);
            end
            nodeTranslation.IntegerOutputTensorNames = string(I);
        end
        
        function nodeTranslation = translateTranspose(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "perm"     "INTS"      true    []
                });
            % Parse the attributes
            [perm] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % B = permute(A, ORDER). We'll pass ORDER='' in the default case.
            B        = node.output{1};
            A        = node.input{1};
            PermName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Perm']);
            % Get the perm
            if isempty(perm)
                ORDER = "''";
            else
                ORDER              = sprintf('Vars.%s', PermName);
                nodeTranslation.Nonlearnables = struct(PermName, nnet.internal.cnn.onnx.fcn.RankedArray(perm,2));
            end
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[perm, NumDims.%s] = prepareTransposeArgs(%s, NumDims.%s);\n', B, ORDER, A),...
                sprintf('if ~isempty(perm)\n'),...
                sprintf('Vars.%s = permute(Vars.%s, perm);\n', B, A),...
                sprintf('end\n'),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareTransposeArgs";
            if ismember(A, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(B);
            end
        end
        
        function nodeTranslation = translateUnsqueeze(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axes"     "INTS"      false    []
                });
            % Parse the attributes
            [axes] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % Y = unsqueeze(X)
            Y       = node.output{1};
            X       = node.input{1};
            AxesName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Axes']);
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[shape, NumDims.%s] = prepareUnsqueezeArgs(Vars.%s, Vars.%s, NumDims.%s);\n', Y, X, AxesName, X),...
                sprintf('Vars.%s = reshape(Vars.%s, shape);\n', Y, X),...
                ];
            nodeTranslation.Nonlearnables = struct(AxesName, nnet.internal.cnn.onnx.fcn.RankedArray(axes,2));
            nodeTranslation.MCode = string(command);
            nodeTranslation.IncludedFunctionNames = "prepareUnsqueezeArgs";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end

        %% Utilities:
        function nodeTranslation = translateUnsupportedONNXLayers(~, nodeTranslation, node, ~)
            InputList = cell(1, numel(node.input));
            for i = 1:numel(node.input)
                if ~isempty(node.input{i})
                    InputList{i} = ['Vars.' node.input{i}];
                end
            end
            nonEmptyInputs = cellfun(@(x) ~isempty(x), InputList);
            InputList = InputList(nonEmptyInputs);

            OutputVarList = cell(1, numel(node.output));
            OutputNumDimsList = cell(1, numel(node.output));
            for i = 1:numel(node.output)
                if ~isempty(node.output{i})
                    OutputVarList{i} = ['Vars.' node.output{i}];
                    OutputNumDimsList{i} = ['NumDims.' node.output{i}];
                end
            end
            nonEmptyOutputs = cellfun(@(x) ~isempty(x), OutputVarList);
            OutputVarList = OutputVarList(nonEmptyOutputs);
            OutputNumDimsList = OutputNumDimsList(nonEmptyOutputs);

            command = [
                sprintf('%% PLACEHOLDER FUNCTION FOR UNSUPPORTED OPERATOR (%s):\n', node.op_type),...
                sprintf('[%s] = PLACEHOLDER(%s);\n', strjoin([OutputVarList, OutputNumDimsList], ', '), strjoin(InputList, ', '))];
            nodeTranslation.MCode   = string(command);
        end   

        function nodeTranslation = translateUnaryOperator(~, nodeTranslation, node, MATLABFcn, IntegerTensorNames)
            Y = node.output{1};
            X = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = %s(Vars.%s);\n', Y, MATLABFcn, X),...
                sprintf('NumDims.%s = NumDims.%s;\n', Y, X),...
                ];
            nodeTranslation.MCode = string(command);
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end 

        function nodeTranslation = translateUniBroadcastInfixBinaryOp(~, nodeTranslation, node, MATLABFcn, IntegerTensorNames)
            % Undirectionally broadcast (left to right) infix binary
            % operator with attributes 'broadcast' and 'axis'
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.            
            AttributeTable = cell2table({
                "axis"      "INT"   true    []
                "broadcast" "INT"   true    0
                });
            % Parse the attributes
            [axis, broadcast] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            D       = node.output{1};
            A       = node.input{1};
            B       = node.input{2};
            Command = sprintf('%% %s:\n', node.op_type);
            if broadcast && ~isempty(axis)
                Command = [Command,...
                    sprintf('Vars.%s = prepareBroadcastInfixBinaryArgs(Vars.%s, %d);\n', B, B, axis)];
            end            
            Command = [Command,...
                sprintf('Vars.%s = Vars.%s %s Vars.%s;\n', D, A, MATLABFcn, B),...
                sprintf('NumDims.%s = max(NumDims.%s, NumDims.%s);\n', D, A, B),...
                ];
            nodeTranslation.MCode = string(Command);
            if ismember(A, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(D);
            end
            % Add either of the inputs to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, A)
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, A);
                nodeTranslation.Nonlearnables.(A) = rankedArray;
            end
            if isInitializer(nodeTranslation.GraphTranslation, B)
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, B);
                nodeTranslation.Nonlearnables.(B) = rankedArray;
            end
            nodeTranslation.IncludedFunctionNames   = "prepareBroadcastInfixBinaryArgs";                        
        end
    end
end