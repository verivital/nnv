classdef Opset7TranslationStrategy < nnet.internal.cnn.onnx.fcn.Opset6TranslationStrategy
    % A strategy class implementing operator translators for opset version
    % 7.

    %   Copyright 2020-2022 The MathWorks, Inc.     
    methods       
        function nodeTranslation = translateAdd(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateInfixBinaryOperator(this, nodeTranslation, node, '+', IntegerTensorNames);
        end
        
        function nodeTranslation = translateAnd(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateInfixBinaryOperator(this, nodeTranslation, node, '&', IntegerTensorNames);
        end          

        function nodeTranslation = translateCos(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'cos', IntegerTensorNames);
        end

        function nodeTranslation = translateDiv(~, nodeTranslation, node, IntegerTensorNames)
            % This is a binary infix operator, but we're not calling
            % translateInfixBinaryOperator because we need to generate
            % different code when doing integer division.
            D       = node.output{1};
            A       = node.input{1};
            B       = node.input{2};
            if ismember(A, IntegerTensorNames)                
                divCommand = sprintf('Vars.%s = fix(Vars.%s ./ Vars.%s);\n', D, A, B);      % integer division
                nodeTranslation.IntegerOutputTensorNames = string(D);
            else
                divCommand = sprintf('Vars.%s = Vars.%s ./ Vars.%s;\n', D, A, B);           % float division
            end
            Command = [...
                sprintf('%% %s:\n', node.op_type),...
                divCommand,...
                sprintf('NumDims.%s = max(NumDims.%s, NumDims.%s);\n', D, A, B),...
                ];
            nodeTranslation.MCode = string(Command);
            % Add either of the inputs to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, A)
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, A);
                nodeTranslation.Nonlearnables.(A) = rankedArray;
            end
            if isInitializer(nodeTranslation.GraphTranslation, B)
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, B);
                nodeTranslation.Nonlearnables.(B) = rankedArray;
            end
        end

        function nodeTranslation = translateEqual(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateInfixBinaryOperator(this, nodeTranslation, node, '==', IntegerTensorNames);
        end

        function nodeTranslation = translateGreater(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateInfixBinaryOperator(this, nodeTranslation, node, '>', IntegerTensorNames);
        end

        function nodeTranslation = translateLess(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateInfixBinaryOperator(this, nodeTranslation, node, '<', IntegerTensorNames);
        end

        function nodeTranslation = translateMul(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateInfixBinaryOperator(this, nodeTranslation, node, '.*', IntegerTensorNames);
        end        
        
        function nodeTranslation = translateOr(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateInfixBinaryOperator(this, nodeTranslation, node, '|', IntegerTensorNames);
        end

        function nodeTranslation = translatePow(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translatePrefixBinaryOperator(this, nodeTranslation, node, 'power', IntegerTensorNames);
        end    

        function nodeTranslation = translateSin(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'sin', IntegerTensorNames);
        end

        function nodeTranslation = translateSub(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateInfixBinaryOperator(this, nodeTranslation, node, '-', IntegerTensorNames);
        end

        function nodeTranslation = translateTan(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'tan', IntegerTensorNames);
        end

        function nodeTranslation = translateUpsample(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "mode"      "STRING"    true    "nearest"
                "scales"    "FLOATS"    false   []
                });
            % Parse the attributes
            [mode, scales] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            if ~isequal(mode, "nearest")
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                    message("nnet_cnn_onnx:onnx:ModeNearest"));
                mode = "nearest";
            end
            scalesName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Scales']);
            % Y = onnxUpsample(X, scales, mode)
            Y         	= node.output{1};
            X         	= node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[DLTScales, DLTSizes, dataFormat, Method, GeometricTransformMode, NearestRoundingMode, NumDims.%s] = prepareResize11Args([], Vars.%s, dlarray([]), "half_pixel", "%s", "round", NumDims.%s);\n', ...
                Y, scalesName, mode, X),...
                sprintf('Vars.%s = dlresize(Vars.%s, ''Scale'', DLTScales, ''DataFormat'', dataFormat, ''Method'', Method, ''GeometricTransformMode'', GeometricTransformMode, ''NearestRoundingMode'', NearestRoundingMode);\n', ...
                Y, X),...
                ];
            nodeTranslation.Nonlearnables = struct(scalesName, nnet.internal.cnn.onnx.fcn.RankedArray(scales,1));
            nodeTranslation.MCode = string(command);
            nodeTranslation.IncludedFunctionNames = "prepareResize11Args";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        % Utilities:
        function nodeTranslation = translateInfixBinaryOperator(~, nodeTranslation, node, MATLABFcn, IntegerTensorNames)
            D       = node.output{1};
            A       = node.input{1};
            B       = node.input{2};
            Command = [sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = Vars.%s %s Vars.%s;\n', D, A, MATLABFcn, B),...
                sprintf('NumDims.%s = max(NumDims.%s, NumDims.%s);\n', D, A, B),...
                ];
            nodeTranslation.MCode = string(Command);
            if ismember(A, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(D);
            end
            % Add either of the inputs to Nonlearnables if it's an initializer
            if isInitializer(nodeTranslation.GraphTranslation, A)
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, A);
                nodeTranslation.Nonlearnables.(A) = rankedArray;
            end
            if isInitializer(nodeTranslation.GraphTranslation, B)
                [~, rankedArray] = getInitializerValue(nodeTranslation.GraphTranslation, B);
                nodeTranslation.Nonlearnables.(B) = rankedArray;
            end
        end
        
        function nodeTranslation = translatePrefixBinaryOperator(~, nodeTranslation, node, MATLABFcn, ~)
            D       = node.output{1};
            A       = node.input{1};
            B       = node.input{2};
            Command = [sprintf('%% %s:\n', node.op_type),...
                sprintf('Vars.%s = %s(Vars.%s, Vars.%s);\n', D, MATLABFcn, A, B),...
                sprintf('NumDims.%s = max(NumDims.%s, NumDims.%s);\n', D, A, B),...
                ];
            nodeTranslation.MCode = string(Command);
        end        
    end
end
