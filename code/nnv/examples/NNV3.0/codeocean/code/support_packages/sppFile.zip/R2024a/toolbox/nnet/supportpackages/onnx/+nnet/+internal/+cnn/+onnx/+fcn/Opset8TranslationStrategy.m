classdef Opset8TranslationStrategy < nnet.internal.cnn.onnx.fcn.Opset7TranslationStrategy
    methods
        function nodeTranslation = translateExpand(~, nodeTranslation, node, IntegerTensorNames)    % Introduced in opset 8
            Y       = node.output{1};
            X       = node.input{1};
            shape	= node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[shape, NumDims.%s] = prepareExpandArgs(Vars.%s);\n', Y, shape),...
                sprintf('Vars.%s = Vars.%s + zeros(shape);\n', Y, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareExpandArgs";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
                
        function nodeTranslation = translateMaxPool(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "auto_pad"          "STRING"    true    "NOTSET"
                "kernel_shape"      "INTS"      false   []
                "pads"              "INTS"      true    []
                "storage_order"     "INT"       true    []          % new in opset 8
                "strides"           "INTS"      true    []
                });
            % Parse the attributes
            [auto_pad,  kernel_shape, pads, storage_order, strides] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            numSpatialDims = numel(kernel_shape);
            padding = zeros(2*numSpatialDims,1);
            % auto_pad, pads
            if auto_pad ~= "NOTSET"
                switch auto_pad
                    case "SAME_UPPER"
                        padding = "same";
                    case "SAME_LOWER"
                        padding = "same";
                        nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                            message("nnet_cnn_onnx:onnx:AutoPadSameLower"))];
                    case "VALID"
                        % Leave default
                    otherwise
                        % Leave default
                end
            elseif isempty(pads)
                padding = zeros(2*numSpatialDims,1);
            else
                padding = double(pads);
            end
            % strides
            if isempty(strides)
                strides = ones(numSpatialDims,1);
            end
            % column-major not supported
            if storage_order==1
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationError(node,...
                    message('nnet_cnn_onnx:onnx:AttributeMustHaveValue', node.name, 'MaxPool', 'storage_order', '0'));
                return;
            end
            switch numel(node.output)
                case 1
                    % Single-output: Y = maxpool(X,POOLSIZE,...)
                    Y        = node.output{1};
                    X        = node.input{1};
                    PoolsizeName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'PoolSize']);
                    StrideName   = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Stride']);
                    PaddingName  = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Padding']);
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[poolsize, stride, padding, dataFormat, NumDims.%s] = prepareMaxPool8Args(Vars.%s, Vars.%s, Vars.%s, NumDims.%s);\n', Y, PoolsizeName, StrideName, PaddingName, X),...
                        sprintf('Vars.%s = maxpool(Vars.%s, poolsize, ''Stride'', stride, ''Padding'', padding, ''DataFormat'', dataFormat);\n', Y, X),...
                        ];
                case 2  % New in opset 8
                    % Two-output: [Y, Indices] = maxpool(X,POOLSIZE,...)
                    Y        = node.output{1};
                    Indices  = node.output{2};
                    X        = node.input{1};
                    PoolsizeName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'PoolSize']);
                    StrideName   = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Stride']);
                    PaddingName  = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Padding']);
                    command = [
                        sprintf('%% %s:\n', node.op_type),...
                        sprintf('[poolsize, stride, padding, dataFormat, NumDims.%s, NumDims.%s] = prepareMaxPool8Args(Vars.%s, Vars.%s, Vars.%s, NumDims.%s);\n',...
                        Y, Indices, PoolsizeName, StrideName, PaddingName, X),...
                        sprintf('[Vars.%s, Vars.%s] = maxpool(Vars.%s, poolsize, ''Stride'', stride, ''Padding'', padding, ''DataFormat'', dataFormat);\n', Y, Indices, X),...
                        ];
                    nodeTranslation.IntegerOutputTensorNames = string(Indices);
            end
            nodeTranslation.Nonlearnables           = struct(...
                PoolsizeName, nnet.internal.cnn.onnx.fcn.RankedArray(kernel_shape,1), ...
                StrideName, nnet.internal.cnn.onnx.fcn.RankedArray(strides,1), ...
                PaddingName, nnet.internal.cnn.onnx.fcn.RankedArray(padding,1));
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareMaxPool8Args";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames(end+1) = string(Y);
            end
        end
    end
end
