classdef Opset9TranslationStrategy < nnet.internal.cnn.onnx.fcn.Opset8TranslationStrategy
%
 
%   Copyright 2020-2022 The MathWorks, Inc.     
    methods
        function nodeTranslation = translateBatchNormalization(~, nodeTranslation, node, IntegerTensorNames)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "epsilon"      "FLOAT"      true    1e-5
                "momentum"     "FLOAT"  	true    0.9
                % "spatial" removed in opset 9
                });
            % Parse the attributes
            [Epsilon, momentum] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            if Epsilon < single(1e-5)
                nodeTranslation.Issues = [nodeTranslation.Issues nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                    message('nnet_cnn_onnx:onnx:BadEpsilon'))];
            end
            Epsilon         = double(max(Epsilon, 1e-5));
            ScaleName       = node.input{2};
            OffsetName      = node.input{3};
            meanName        = node.input{4};
            varName         = node.input{5};
            % The call to Batchnorm is followed by code that updates state variables:
            % [Y,DATASETMEAN,DATASETVARIANCE] = batchnorm(X,OFFSET,SCALE,DATASETMEAN,DATASETVARIANCE,'DataFormat',FMT)
            % state.DATASETMEAN               = DATASETMEAN;
            % state.DATASETVARIANCE           = DATASETVARIANCE;
            Y               = node.output{1};
            DATASETMEAN     = meanName;
            DATASETVARIANCE = varName;
            X               = node.input{1};
            OFFSET          = OffsetName;
            SCALE           = ScaleName;
            code = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[offset, scale, datasetMean, datasetVariance, dataFormat, NumDims.%s, NumDims.%s, NumDims.%s] = prepareBatchNormalizationArgs(Vars.%s, Vars.%s, Vars.%s, Vars.%s, NumDims.%s, NumDims.%s, NumDims.%s);\n',...
                Y, DATASETMEAN, DATASETVARIANCE, OFFSET, SCALE, DATASETMEAN, DATASETVARIANCE, X, DATASETMEAN, DATASETVARIANCE),...
                sprintf('if Training\n'),...
                sprintf('[Vars.%s, dsmean, dsvar] = batchnorm(Vars.%s, offset, scale, datasetMean, datasetVariance, ''Epsilon'', %f, ''DataFormat'', dataFormat);\n', Y, X, Epsilon),...
                sprintf('Vars.%s = dlarray(dsmean);\n', DATASETMEAN),...
                sprintf('Vars.%s = dlarray(dsvar);\n', DATASETVARIANCE),...
                sprintf('else\n'),...
                sprintf('Vars.%s = batchnorm(Vars.%s, offset, scale, datasetMean, datasetVariance, ''Epsilon'', %f, ''DataFormat'', dataFormat);\n', Y, X, Epsilon),...
                sprintf('end\n'),...
                sprintf('state.%s = Vars.%s;\n', DATASETMEAN, DATASETMEAN),...
                sprintf('state.%s = Vars.%s;\n', DATASETVARIANCE, DATASETVARIANCE)];
            nodeTranslation.InitialState            = struct(DATASETMEAN, [], DATASETVARIANCE, []);
            nodeTranslation.MCode                   = string(code);
            nodeTranslation.IncludedFunctionNames   = "prepareBatchNormalizationArgs";
        end

        function nodeTranslation = translateCompress(~, nodeTranslation, node, IntegerTensorNames)    	% Introduced in opset 9
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       true    -1
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y       = node.output{1};
            X       = node.input{1};
            condition = node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Indices, NumDims.%s] = prepareCompressArgs(Vars.%s, Vars.%s, %d, NumDims.%s);\n', Y, X, condition, axis, X),...
                ];
            if axis < 0
                command = [command, sprintf('Vars.%s = Vars.%s(Indices);\n', Y, X)];            % X is implicitly flattened first.
            else
                command = [command, sprintf('Vars.%s = subsref(Vars.%s, Indices);\n', Y, X)];   % X is not flattened first.
            end
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "prepareCompressArgs";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end   
                
        function nodeTranslation = translateConstantOfShape(~, nodeTranslation, node, IntegerTensorNames)    	% Introduced in opset 9
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "value"       "TENSOR"      true    []
                });
            % Parse the attributes
            [value] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            ShapeName = node.input{1};
            Y         = node.output{1};
            if isempty(value)
                % Default for optional attribute 'value' is float32 with value 0.
                val = double(0);
            else
                val = double(nnet.internal.cnn.onnx.getDataFromTensorProto(value));
            end
            ValueName       = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'Value']);
            nodeTranslation.Nonlearnables = struct(ValueName, nnet.internal.cnn.onnx.fcn.RankedArray(val,0));
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxConstantOfShape(Vars.%s, Vars.%s);\n', Y, Y, ValueName, ShapeName),...
                ];
            nodeTranslation.MCode = string(command);
            nodeTranslation.IncludedFunctionNames = "onnxConstantOfShape";
            if isempty(value) || nnet.internal.cnn.onnx.isONNXTypeInteger(value.data_type)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end

        function nodeTranslation = translateErf(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'erf', IntegerTensorNames);
        end

        function nodeTranslation = translateNonZero(~, nodeTranslation, node, IntegerTensorNames)       % Introduced in opset 9
            Y = node.output{1};
            X = node.input{1};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxNonZero(Vars.%s, NumDims.%s);\n', Y, Y, X, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxNonZero";
            nodeTranslation.IntegerOutputTensorNames = string(Y);
        end
        
        function nodeTranslation = translateOneHot(~, nodeTranslation, node, IntegerTensorNames)        % Introduced in opset 9
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"         "INT"       true    -1
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            % B = OneHot(Indices, Depth, Values)
            B       = node.output{1};
            Indices	= node.input{1};
            Depth  	= node.input{2};
            Values 	= node.input{3};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxOneHot(Vars.%s, Vars.%s, Vars.%s, %d, NumDims.%s);\n', ...
                B, B, Indices, Depth, Values, axis, Indices),...
                ];
            nodeTranslation.MCode = string(command);
            nodeTranslation.IncludedFunctionNames = "onnxOneHot";
            if ismember(Values, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(B);
            end
        end
        
        function nodeTranslation = translateScan(~, nodeTranslation, node, IntegerTensorNames)             
            AttributeTable = cell2table({
                "body"                   "GRAPH"     false   []
                "num_scan_inputs"        "INT"       false   []
                "scan_input_axes"        "INTS"      true    []
                "scan_input_directions"  "INTS"      true    []
                "scan_output_axes"       "INTS"      true    []
                "scan_output_directions" "INTS"      true    []
                });

            % Parse the attributes
            [body, num_scan_inputs, scan_input_axes, scan_input_directions,...
                scan_output_axes, scan_output_directions] = ...
                nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);            
            
            % Get the names of inputs and outputs
            numInputs = numel(node.input);
            numOutputs = numel(node.output);
            numStateInputs = numInputs - num_scan_inputs;
            numScanOutputs = numOutputs - numStateInputs;            
            initialStateInputs = node.input(1:numStateInputs);
            initialScanInputs = node.input(numStateInputs+1:end);
            finalStateOutputs = node.output(1:numStateInputs);
            finalScanOutputs = node.output(numStateInputs+1:end);

            % Set the optional attributes to their defaults.
            % Note: The defaults depend on num_scan_inputs, itself an
            % attribute, so cannot be set automatically by
            % parseNodeAttributes.
            if isempty(scan_input_axes)
                scan_input_axes = zeros(1, num_scan_inputs);
            end
            
            if isempty(scan_input_directions)
                scan_input_directions = zeros(1, num_scan_inputs);
            end
            
            if isempty(scan_output_axes)
                scan_output_axes = zeros(1, numScanOutputs);
            end  
            
            if isempty(scan_output_directions)
                scan_output_directions = zeros(1, numScanOutputs);
            end  
            
            scanInputAxesVarName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'InputAxes']);
            scanInputDirectionsVarName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'InputDirections']);
            scanOutputAxesVarName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'OutputAxes']);
            scanOutputDirectionsVarName = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'OutputDirections']);
            
            nodeTranslation.Nonlearnables = struct(...
                scanInputAxesVarName, nnet.internal.cnn.onnx.fcn.RankedArray(scan_input_axes,1),...
                scanInputDirectionsVarName, nnet.internal.cnn.onnx.fcn.RankedArray(scan_input_directions,1),...
                scanOutputAxesVarName, nnet.internal.cnn.onnx.fcn.RankedArray(scan_output_axes,1),...
                scanOutputDirectionsVarName, nnet.internal.cnn.onnx.fcn.RankedArray(scan_output_directions,1));
            
            % Lists of the inputs, outputs, and their ranks
            initialStateVarList   = strjoin(cellfun(@(s)['Vars.' s], initialStateInputs, 'UniformOutput', false), ', ');
            initialScanVarList   = strjoin(cellfun(@(s)['Vars.' s], initialScanInputs, 'UniformOutput', false), ', ');
            initialStateRankList = strjoin(cellfun(@(s)['NumDims.' s], initialStateInputs, 'UniformOutput', false), ', ');
            initialScanRankList = strjoin(cellfun(@(s)['NumDims.' s], initialScanInputs, 'UniformOutput', false), ', ');            
            finalStateVarList      = strjoin(cellfun(@(s)['Vars.' s], finalStateOutputs, 'UniformOutput', false), ', ');
            finalScanVarList      = strjoin(cellfun(@(s)['Vars.' s], finalScanOutputs, 'UniformOutput', false), ', ');            
            finalStateRankList = strjoin(cellfun(@(s)['NumDims.' s], finalStateOutputs, 'UniformOutput', false), ', ');
            finalScanRankList = strjoin(cellfun(@(s)['NumDims.' s], finalScanOutputs, 'UniformOutput', false), ', ');               
            
            % Translate the subgraph
            BodyGraphFcnName     = nnet.internal.cnn.onnx.fcn.uniqueName([node.op_type, 'BodyGraph']);
            BodyGraphTranslation = nnet.internal.cnn.onnx.fcn.GraphTranslation(body, nodeTranslation.OpsetVersion, IntegerTensorNames, BodyGraphFcnName);                       
            
            command = [...
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[%s, %s, %s, %s, state] = onnxScan({%s}, {%s}, {%s}, {%s},Vars, NumDims, Training, state, @%s, %d, %d, Vars.%s, Vars.%s, Vars.%s, Vars.%s);\n', ...
                finalStateVarList, finalScanVarList, finalStateRankList, finalScanRankList, ...
                initialStateVarList, initialScanVarList, initialStateRankList, initialScanRankList,...
                BodyGraphFcnName, num_scan_inputs, numScanOutputs, ...
                scanInputAxesVarName, scanInputDirectionsVarName, scanOutputAxesVarName, scanOutputDirectionsVarName),...
                sprintf('Vars = appendStructs(Vars, state);\n')];
            nodeTranslation.InitialState          	= BodyGraphTranslation.InitialState;
            nodeTranslation.MCode                	= string(command);
            nodeTranslation.IncludedFunctionNames	= unique(["onnxScan", BodyGraphTranslation.IncludedFunctionNames]);
            nodeTranslation.Nonlearnables           = nnet.internal.cnn.onnx.fcn.appendStructs(nodeTranslation.Nonlearnables, BodyGraphTranslation.Nonlearnables);
            nodeTranslation.SubgraphLearnables    	= BodyGraphTranslation.Learnables;
            nodeTranslation.SubgraphFunctionCode  	= BodyGraphTranslation.GraphFunctionCode;
            nodeTranslation.SubgraphTranslations  	= BodyGraphTranslation;
            % Set the new IntegerOutputTensorNames to be the integer outputs of the subgraph
            isIntGraphOutput                        = arrayfun(@nnet.internal.cnn.onnx.isONNXTypeInteger, nodeTranslation.SubgraphTranslations.ExternalOutputTypes);
            nodeTranslation.IntegerOutputTensorNames = string(nodeTranslation.SubgraphTranslations.ExternalOutputNames(isIntGraphOutput));
            
             % Collect all translation issues
            bodyTranslationIssues                   = arrayfun(@(nodeTranslation) nodeTranslation.Issues, BodyGraphTranslation.NodeTranslations, 'UniformOutput', false);
            nodeTranslation.Issues                  = [nodeTranslation.Issues, bodyTranslationIssues{:}];
        end        
        
        function nodeTranslation = translateScatter(~, nodeTranslation, node, IntegerTensorNames)        % Introduced in opset 9
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "axis"      "INT"       true    0
                });
            % Parse the attributes
            [axis] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            Y       = node.output{1};
            X       = node.input{1};
            Indices	= node.input{2};
            Updates	= node.input{3};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxScatter(Vars.%s, Vars.%s, Vars.%s, %d, NumDims.%s);\n', ...
                Y, Y, X, Indices, Updates, axis, X),...
                ];
            nodeTranslation.MCode                   = string(command);
            nodeTranslation.IncludedFunctionNames   = "onnxScatter";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end

        function nodeTranslation = translateSign(this, nodeTranslation, node, IntegerTensorNames)
            nodeTranslation = translateUnaryOperator(this, nodeTranslation, node, 'sign', IntegerTensorNames);
        end
        
        function nodeTranslation = translateUpsample(~, nodeTranslation, node, IntegerTensorNames)
            % OPSET 9 version: 'scales' is now an input instead of an attribute.
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            AttributeTable = cell2table({
                "mode"      "STRING"    true    "nearest"
                });
            % Parse the attributes
            [mode] = nnet.internal.cnn.onnx.parseNodeAttributes(node, AttributeTable);
            if ~isequal(mode, "nearest")
                nodeTranslation.Issues = nnet.internal.cnn.onnx.NodeTranslationWarning(node,...
                    message("nnet_cnn_onnx:onnx:ModeNearest"));
                mode = "nearest";
            end
            % Y = onnxUpsample(X, scales, mode)
            Y         	= node.output{1};
            X         	= node.input{1};
            scales     	= node.input{2};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[DLTScales, DLTSizes, dataFormat, Method, GeometricTransformMode, NearestRoundingMode, NumDims.%s] = prepareResize11Args([], Vars.%s, dlarray([]), "half_pixel", "%s", "round", NumDims.%s);\n', ...
                Y, scales, mode, X),...
                sprintf('Vars.%s = dlresize(Vars.%s, ''Scale'', DLTScales, ''DataFormat'', dataFormat, ''Method'', Method, ''GeometricTransformMode'', GeometricTransformMode, ''NearestRoundingMode'', NearestRoundingMode);\n', ...
                Y, X),...
                ];
            nodeTranslation.MCode = string(command);
            nodeTranslation.IncludedFunctionNames = "prepareResize11Args";
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(Y);
            end
        end
        
        function nodeTranslation = translateWhere(~, nodeTranslation, node, IntegerTensorNames)        % Introduced in opset 9
            output         	= node.output{1};
            condition       = node.input{1};
            X               = node.input{2};
            Y               = node.input{3};
            command = [
                sprintf('%% %s:\n', node.op_type),...
                sprintf('[Vars.%s, NumDims.%s] = onnxWhere(Vars.%s, Vars.%s, Vars.%s, NumDims.%s, NumDims.%s, NumDims.%s);\n', ...
                    output, output, condition, X, Y, condition, X, Y),...
                ];
            nodeTranslation.MCode = string(command);
            nodeTranslation.IncludedFunctionNames = "onnxWhere";            
            if ismember(X, IntegerTensorNames)
                nodeTranslation.IntegerOutputTensorNames = string(output);
            end
        end
    end
end
