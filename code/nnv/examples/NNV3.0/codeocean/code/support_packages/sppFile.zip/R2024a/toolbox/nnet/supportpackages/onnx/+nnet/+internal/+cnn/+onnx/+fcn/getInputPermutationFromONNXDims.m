function perm = getInputPermutationFromONNXDims(onnxNDims)
if onnxNDims == 4
    % Convert MATLAB HWCN -> NCHW
    perm = [4 3 1 2];
end
end
