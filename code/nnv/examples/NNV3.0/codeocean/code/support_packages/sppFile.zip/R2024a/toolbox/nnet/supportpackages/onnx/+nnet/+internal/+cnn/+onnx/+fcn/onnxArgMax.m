function [Y, numDimsY] = onnxArgMax(X, ONNXAxis, keepdims, numDimsX)
% Implements the ONNX ArgMax operator.
if ONNXAxis < 0
    ONNXAxis = ONNXAxis + numDimsX;
end
DLTAxis = numDimsX - ONNXAxis;
[~, DLTI] = max(X, [], DLTAxis);
Y = DLTI - 1;
if keepdims
    numDimsY = numDimsX;
else
    Y = onnxSqueeze(Y, ONNXAxis, numDimsX);
    numDimsY = numDimsX - 1; 
end
end
