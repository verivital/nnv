function [Y, numDimsX] = onnxCumSum(X, ONNXAxis, exclusive, reverse, numDimsX)
% Implements the ONNX CumSum operator. It needs to work on dlarrays and be
% differentiable. dlarray has no cumsum method. To achieve
% differentiability, this implementation performs the cumsum in a loop of
% dlarray "+" operations.
Y = zeros(size(X), 'like', X);
% ONNXaxis is origin 0.
if ONNXAxis<0
    ONNXAxis = ONNXAxis + numDimsX;
end
DLTAxis = numDimsX - ONNXAxis;
D = size(X, DLTAxis);
if reverse
    % Set the Dth element:
    sD = iMakeSubs(D, DLTAxis, numDimsX);
    Y = subsasgn(Y,sD, subsref(X,sD));                          % Y(:,:,D,:,:) = X(:,:,D,:,:)
    % Compute the cumsum downward from D-1 to 1
    for i = D-1:-1:1
        s = iMakeSubs(i, DLTAxis, numDimsX);
        sPrev = iMakeSubs(i+1, DLTAxis, numDimsX);
        Y = subsasgn(Y,s, subsref(Y,sPrev) + subsref(X,s));     % Y(:,:,i,:,:) = Y(:,:,i+1,:,:) + X(:,:,i,:,:)
    end
    % Shift down if exclusive
    if exclusive
        sTo = iMakeSubs(1:D-1, DLTAxis, numDimsX);
        sFrom = iMakeSubs(2:D, DLTAxis, numDimsX);
        Y = subsasgn(Y,sTo, subsref(Y,sFrom));                  % Y(:,:,1:D-1,:,:) = Y(:,:,2:D,:,:)
        Y = subsasgn(Y,sD, 0);                                  % Y(:,:,D,:,:) = 0
    end
else  % not reverse
    % Set the 1st element
    s1 = iMakeSubs(1, DLTAxis, numDimsX);
    Y = subsasgn(Y,s1, subsref(X,s1));                          % Y(:,:,1,:,:) = X(:,:,1,:,:)
    % Compute the cumsum upward from 2 to D
    for i = 2:D
        s = iMakeSubs(i, DLTAxis, numDimsX);
        sPrev = iMakeSubs(i-1, DLTAxis, numDimsX);
        Y = subsasgn(Y,s, subsref(Y,sPrev) + subsref(X,s));     % Y(:,:,i,:,:) = Y(:,:,i-1,:,:) + X(:,:,i,:,:)
    end
    % Shift up if exclusive
    if exclusive
        sFrom = iMakeSubs(1:D-1, DLTAxis, numDimsX);
        sTo = iMakeSubs(2:D, DLTAxis, numDimsX);
        Y = subsasgn(Y,sTo, subsref(Y,sFrom));                  % Y(:,:,2:D,:,:) = Y(:,:,1:D-1,:,:)
        Y = subsasgn(Y,s1, 0);                                  % Y(:,:,1,:,:) = 0
    end
end

    function s = iMakeSubs(i, DLTAxis, numDims)
        % Make a subsref struct to index (:,:,i,:,:), where the i is
        % placed on axis DLTAxis. i can be a single integer of a range
        % like 1:N or 1:2:N
        C = repmat({':'}, 1, numDims);
        C{DLTAxis} = i;
        s = substruct('()',C);
    end
end
