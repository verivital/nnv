function [X, numDimsX] = onnxElu(X, alpha, numDimsX)
% Implements the ONNX Elu operator
X(X<=0) = alpha*(exp(X(X<=0))-1);
end
