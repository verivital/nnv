function [output_sequence, output_sequenceNumDims] = onnxSplitToSequence(X, ONNXAxis, split, keepdims, numDimsX, numDimsSplit)
% Implements the ONNX SplitToSequence operator

% ONNXaxis is origin 0.
if ONNXAxis<0
    ONNXAxis = ONNXAxis + numDimsX;
end
DLTAxis = numDimsX - ONNXAxis;
% Set 'splits' to be the split sizes
axisSize = size(X, DLTAxis);
if isempty(split)
    % Split them all
    splits      = ones(1, axisSize);
elseif numDimsSplit==0
    % 'split' is the number of splits
    each        = floor(axisSize/split);
    splits      = repmat(each, 1, split-1);     % Fill all but last
    splits(end)	= axisSize-each*(split-1);      % Fill last
    keepdims    = 1;
else
    % 'split' is 1D and gives the sizes
    splits      = extractdata(split);
    keepdims    = 1;
end
% Do the splitting
S      = struct;
S.type = '()';
S.subs = repmat({':'}, 1, ndims(X));
splitIndices = [0 cumsum(splits(:)')];
numY = numel(splitIndices)-1;
if keepdims
    numDimsY = numDimsX;
else
    numDimsY = numDimsX-1;
end
for i = 1:numY
    from                = splitIndices(i) + 1;
    to                  = splitIndices(i+1);
    S.subs{DLTAxis}     = from:to;
    % The first numY outputs are the Y's. The second numY outputs are their
    % numDims.
    output_sequence{i}	= subsref(X, S);
    if ~keepdims
        output_sequence{i} = onnxSqueeze(output_sequence{i}, ONNXAxis, numDimsX);
    end
    output_sequence{i + numY} = numDimsY;
end
output_sequenceNumDims = 1;     % NumDims of the 1D sequence itself.
end
