function [offset, scale, datasetMean, datasetVariance, dataFormat, numDimsY, numDimsDatasetMean, numDimsDatasetVariance] = prepareBatchNormalizationArgs(...
    offset, scale, datasetMean, datasetVariance, numDimsX, numDimsDatasetMean, numDimsDatasetVariance)
% Prepares arguments for implementing the ONNX BatchNormalization operator
offset = dlarray(offset,'C');
scale = dlarray(scale,'C');
datasetMean = extractdata(datasetMean);
datasetVariance = extractdata(datasetVariance);
datasetVariance(datasetVariance <= 0) = realmin('single');  % Set nonpositive variance components to a value below eps('single')
dataFormat = [repmat('S', 1, numDimsX-2), 'CB'];
numDimsY = numDimsX;
end
