function [Indices, numDimsY] = prepareCompressArgs11(X, condition, ONNXAxis, numDimsX)
% Prepares arguments for implementing the ONNX Compress operator
if isempty(ONNXAxis)
    % No axis was specified, so X will be flattened first
    Indices = [extractdata(condition); false(numel(X) - numel(condition), 1)];
    numDimsY = 1;
else
    % Handle negative axis
    if ONNXAxis<0
        ONNXAxis = ONNXAxis + numDimsX;
    end
    DLTAxis = numDimsX - ONNXAxis;
    condition = [extractdata(condition); false(size(X, DLTAxis) - numel(condition), 1)];
    Indices.subs          = repmat({':'}, 1, numDimsX);
    Indices.subs{DLTAxis} = condition;
    Indices.type          = '()';
    numDimsY = numDimsX;
end
end
