function [DLTAxis, numDimsY] = prepareHardmax13Args(ONNXAxis, numDimsX)
% Prepares arguments for implementing the ONNX HardMax operator
if ONNXAxis<0
    ONNXAxis = ONNXAxis + numDimsX;
end
DLTAxis = numDimsX - ONNXAxis;
numDimsY = numDimsX;
end