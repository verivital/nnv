function [poolsize, stride, padding, dataFormat, numDimsY, numDimsIndices] = prepareMaxPool8Args(poolsize, stride, padding, numDimsX)
% Prepares arguments for implementing the ONNX MaxPool-8 operator
poolsize    = fliplr(extractdata(poolsize(:)'));
stride      = fliplr(extractdata(stride(:)'));
% padding
if isa(padding, 'dlarray')
    padding = extractdata(padding);
end
if isnumeric(padding)
    % ONNX: [x1_begin, ..., xn_begin, x1_end, ...,xn_end]
    % DLT:  [xn_begin, ..., x1_begin;
    %        xn_end, ..., x1_end]       (Note the lrflip and semicolon)
    padding = fliplr(transpose(reshape(padding, [], 2)));
end
dataFormat  = [repmat('S', 1, numDimsX-2) 'CB'];
numDimsY    = numDimsX;
numDimsIndices = numDimsX;                      % New in opset 8
end
