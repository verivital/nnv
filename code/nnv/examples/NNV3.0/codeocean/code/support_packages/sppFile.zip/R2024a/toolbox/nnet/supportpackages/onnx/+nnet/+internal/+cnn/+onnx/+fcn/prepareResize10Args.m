function [DLTScales, dataFormat, Method, numDimsY] = prepareResize10Args(ONNXScales, mode, numDimsX)
% Prepares arguments for implementing the ONNX Resize-10 operator

% ONNXScales are in ONNX dimension ordering
DLTScales = flip(extractdata(ONNXScales(:)'));
switch mode
    case "nearest"
        Method = "nearest";
    case "linear"
        Method = "linear";
    otherwise
        assert(false);
end
dataFormat = repmat('S', [1 numDimsX]);
numDimsY = numDimsX;
end
