function str = uniqueName(desiredString)
% Generate a new name within the legal MATLAB limit of 63 chars.
persistent nameNumber
if isempty(nameNumber)
    nameNumber = 1000;
else
    nameNumber = nameNumber + 1;
end
suff = num2str(nameNumber);
desiredString = char(desiredString);
str = [desiredString(1:min(numel(desiredString), 63-numel(suff))) suff];
end
