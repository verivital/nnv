classdef ConverterForResizeLayers < nnet.internal.cnn.onnx.NNTLayerConverter
    % Class to convert resize2dLayer or resize3dLayer into ONNX.
    
    % Copyright 2020-2021 The MathWorks, Inc.
    
    methods
        function this = ConverterForResizeLayers(layerAnalyzer)
            this@nnet.internal.cnn.onnx.NNTLayerConverter(layerAnalyzer);
        end
        
        function [nodeProto, parameterInitializers, networkInputs, networkOutputs, TensorNameMap, TensorLayoutMap] ...
                = toOnnx(this, nodeProto, TensorNameMap, TensorLayoutMap)
            import nnet.internal.cnn.onnx.*
            
            [onnxName, nameChanged] = legalizeNNTName(this, this.NNTLayer.Name);
            onnxName                = makeUniqueName({nodeProto.name}, onnxName);
            
            % Create the resize node.
            resizeNode         = NodeProto;
            resizeNode.name    = onnxName;
            resizeNode.output  = {onnxName};
            
            if this.OpsetVersion < 7
                resizeNode.op_type = 'Upsample';
                resizeNode.input   = mapTensorNames(this, this.InputLayerNames(1), TensorNameMap);
                method = this.NNTLayer.Method;
                if isa(this.NNTLayer, 'nnet.cnn.layer.Resize3DLayer')
                    error(message("nnet_cnn_onnx:onnx:CantExportLayer", class(this.NNTLayer)));
                end
                [scale, outputTensorLayout] = iGetScaleValues(this);
                if any(scale<1)
                    error(message("nnet_cnn_onnx:onnx:UnsupportedResizeScale"));
                end
                if strcmp(this.NNTLayer.GeometricTransformMode,'half-pixel')
                    warning(message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyExport", this.NNTLayer.Name, 'GeometricTransformMode',this.NNTLayer.GeometricTransformMode,this.OpsetVersion));
                end
                if strcmp(this.NNTLayer.NearestRoundingMode,'round')
                    warning(message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyExport", this.NNTLayer.Name, 'NearestRoundingMode',this.NNTLayer.NearestRoundingMode,this.OpsetVersion));
                end
                resizeNode.attribute = [...
                    makeAttributeProto('height_scale', 'FLOAT', scale(end-1)),...
                    makeAttributeProto('mode', 'STRING', method),...
                    makeAttributeProto('width_scale', 'FLOAT', scale(end))
                    ];
                parameterInitializers = [];
                
            elseif this.OpsetVersion >= 7 && this.OpsetVersion < 9
                resizeNode.op_type = 'Upsample';
                resizeNode.input    = mapTensorNames(this, this.InputLayerNames(1), TensorNameMap);
                method = iConvertMethodToONNX(this.NNTLayer, this.OpsetVersion);
                [scale, outputTensorLayout] = iGetScaleValues(this);
                if any(scale<1)
                    error(message("nnet_cnn_onnx:onnx:UnsupportedResizeScale"));
                end
                if strcmp(this.NNTLayer.GeometricTransformMode,'half-pixel')
                    warning(message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyExport", this.NNTLayer.Name, 'GeometricTransformMode',this.NNTLayer.GeometricTransformMode,this.OpsetVersion));
                end
                if strcmp(this.NNTLayer.NearestRoundingMode,'round')
                    warning(message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyExport", this.NNTLayer.Name, 'NearestRoundingMode',this.NNTLayer.NearestRoundingMode,this.OpsetVersion));
                end
                [resizeNode,parameterInitializers] = iFillResizeNodeAttributes(resizeNode, scale, method);
                
                
            elseif this.OpsetVersion == 9
                resizeNode.op_type = 'Upsample';
                scalesName = [onnxName '_scales'];
                method = iConvertMethodToONNX(this.NNTLayer, this.OpsetVersion);
                resizeNode.input   = mapTensorNames(this, {this.InputLayerNames{1},scalesName}, TensorNameMap);
                [scale, outputTensorLayout] = iGetScaleValues(this);
                if any(scale<1)
                    error(message("nnet_cnn_onnx:onnx:UnsupportedResizeScale"));
                end
                if strcmp(this.NNTLayer.GeometricTransformMode,'half-pixel')
                    warning(message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyExport", this.NNTLayer.Name, 'GeometricTransformMode',this.NNTLayer.GeometricTransformMode,this.OpsetVersion));
                end
                if strcmp(this.NNTLayer.NearestRoundingMode,'round')
                    warning(message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyExport", this.NNTLayer.Name, 'NearestRoundingMode',this.NNTLayer.NearestRoundingMode,this.OpsetVersion));
                end
                [resizeNode,parameterInitializers] = iFillResizeNodeAttributes(resizeNode, scale, method);
            elseif this.OpsetVersion == 10
                resizeNode.op_type = 'Resize';
                scalesName = [onnxName '_scales'];
                method = iConvertMethodToONNX(this.NNTLayer, this.OpsetVersion);
                resizeNode.input   = mapTensorNames(this, {this.InputLayerNames{1},scalesName}, TensorNameMap);
                [scale, outputTensorLayout] = iGetScaleValues(this);
                if strcmp(this.NNTLayer.GeometricTransformMode,'half-pixel')
                    warning(message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyExport", this.NNTLayer.Name, 'GeometricTransformMode',this.NNTLayer.GeometricTransformMode,this.OpsetVersion));
                end
                if strcmp(this.NNTLayer.NearestRoundingMode,'round')
                    warning(message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyExport", this.NNTLayer.Name, 'NearestRoundingMode',this.NNTLayer.NearestRoundingMode,this.OpsetVersion));
                end
                [resizeNode,parameterInitializers] = iFillResizeNodeAttributes(resizeNode, scale, method);
            elseif this.OpsetVersion >= 11 && this.OpsetVersion < 13
                % For opset version 11-12.
                resizeNode.op_type = 'Resize';
                roiName = [onnxName '_roi'];
                scalesName = [onnxName '_scales'];
                resizeNode.input = mapTensorNames(this, {this.InputLayerNames{1},roiName,scalesName}, TensorNameMap);
                method = iConvertMethodToONNX(this.NNTLayer, this.OpsetVersion);
                coordinateTransformMode = iConvertGeometricTransformToONNX(this.NNTLayer.GeometricTransformMode);
                [scale, outputTensorLayout] = iGetScaleValues(this);
                isUpsample = all(scale(3:end)>=1);
                nearestMode = iConvertNearestModeToONNX(this.NNTLayer.NearestRoundingMode, isUpsample);
                resizeNode.attribute = [...
                    makeAttributeProto('mode', 'STRING', method),...
                    makeAttributeProto('coordinate_transformation_mode', 'STRING', coordinateTransformMode),...
                    makeAttributeProto('cubic_coeff_a', 'FLOAT', -0.75),...
                    makeAttributeProto('exclude_outside', 'INT', 0),...
                    makeAttributeProto('extrapolation_value', 'FLOAT', 0),...
                    makeAttributeProto('nearest_mode', 'STRING', nearestMode)
                    ];
                
                % Make parameter for roi and scales.
                t1              = TensorProto;
                t1.name         = [onnxName '_roi'];
                t1.data_type	= TensorProto_DataType.FLOAT;
                t1.raw_data     = rawData([]);
                t1.dims         = dimVector(numel([]),1);
                
                t2              = TensorProto;
                t2.name         = [onnxName '_scales'];
                t2.data_type	= TensorProto_DataType.FLOAT;
                t2.raw_data     = rawData(single(scale));
                t2.dims         = dimVector(numel(scale),1);
                
                parameterInitializers   = [t1 t2];
            else % opset >= 13
                % 'roi' and 'scales' are now optional. 'roi' is only used 
                % when coordinate_transformation_mode=tf_crop_and_resize. 
                % Exactly one of 'scales' or 'sizes' must be set. The other 
                % may be specified as an empty string.
                resizeNode.op_type = 'Resize';
                scalesName = [onnxName '_scales'];
                method = iConvertMethodToONNX(this.NNTLayer, this.OpsetVersion);
                coordinateTransformMode = iConvertGeometricTransformToONNX(this.NNTLayer.GeometricTransformMode);
                [scale, outputTensorLayout] = iGetScaleValues(this);
                resizeNode.input = mapTensorNames(this, {this.InputLayerNames{1},'',scalesName}, TensorNameMap);

                isUpsample = all(scale(3:end)>=1);
                nearestMode = iConvertNearestModeToONNX(this.NNTLayer.NearestRoundingMode, isUpsample);
                resizeNode.attribute = [...
                    makeAttributeProto('mode', 'STRING', method),...
                    makeAttributeProto('coordinate_transformation_mode', 'STRING', coordinateTransformMode),...
                    makeAttributeProto('cubic_coeff_a', 'FLOAT', -0.75),...
                    makeAttributeProto('exclude_outside', 'INT', 0),...
                    makeAttributeProto('extrapolation_value', 'FLOAT', 0),...
                    makeAttributeProto('nearest_mode', 'STRING', nearestMode)
                    ];

                % Make parameter for scales
                t1              = TensorProto;
                t1.name         = scalesName;
                t1.data_type	= TensorProto_DataType.FLOAT;
                t1.raw_data     = rawData(single(scale));
                t1.dims         = dimVector(numel(scale),1);               
                parameterInitializers   = t1;
            end
            
            nodeProto               = [nodeProto resizeNode];
            networkInputs           = [];
            networkOutputs          = [];
            
            TensorNameMap(this.NNTLayer.Name) = onnxName;
            % Update layout map
            TensorLayoutMap(onnxName) = outputTensorLayout;
            
            % Update network if current layer is danglingLayer
            [nodeProto, networkOutputs, TensorNameMap, TensorLayoutMap] ...
                = this.updateNetworkOutputForDanglingLayers(nodeProto, networkOutputs, TensorNameMap, TensorLayoutMap);
        end
    end
end

function method  = iConvertMethodToONNX(layer,version)
if strcmp(layer.Method,'bilinear')
    method = 'linear';
elseif strcmp(layer.Method,'trilinear')
    % Currently, onnxruntime does not support linear method for 5D data.
    % Switching method to nearest.
    % https://github.com/microsoft/onnxruntime/blob/master/onnxruntime/core/providers/cpu/tensor/upsample.h#L278
    warning(message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyExport", layer.Name,'Method',layer.Method,version));
    method = 'nearest';
else
    method = 'nearest';
end
end

function [scale, outputTensorLayout, inputTensorSize] = iGetScaleValues(this)
if isa(this.NNTLayer, 'nnet.cnn.layer.Resize2DLayer')
    outputTensorLayout = 'nchw';
    inputTensorSize = this.InputLayerSizes{1};
    inputImageSize  = inputTensorSize(1:2);    
    if ~isempty(this.NNTLayer.Scale)
        scale = [1 1 this.NNTLayer.Scale];
    elseif ~isempty(this.NNTLayer.OutputSize)
        outputSize = this.NNTLayer.OutputSize;
        if ~any(isnan(outputSize))
            scale = [1 1 outputSize./inputImageSize];
        else
            idx = find(~isnan(outputSize));
            scale = [1 1 repelem(outputSize(idx)/inputImageSize(idx),2)];
        end
    elseif this.NNTLayer.EnableReferenceInput
        % Take the output size from the reference port
        outputSize = this.InputLayerSizes{2}(1:2);
        scale = [1 1 outputSize./inputImageSize];
    end
    inputTensorSize = inputTensorSize([3 1 2]); % CHW
elseif isa(this.NNTLayer, 'nnet.cnn.layer.Resize3DLayer')
    outputTensorLayout = 'nchwd';
    inputTensorSize = this.InputLayerSizes{1};    
    inputImageSize  = inputTensorSize(1:3);
    if ~isempty(this.NNTLayer.Scale)
        scale = [1 1 this.NNTLayer.Scale];
    elseif ~isempty(this.NNTLayer.OutputSize)
        outputSize = this.NNTLayer.OutputSize;
        if ~any(isnan(outputSize))
            scale = [1 1 outputSize./inputImageSize];
        else
            idx = find(~isnan(outputSize));
            scale = [1 1 repelem(outputSize(idx)/inputImageSize(idx),3)];
        end
    elseif this.NNTLayer.EnableReferenceInput
        % Take the output size from the reference port
        outputSize = this.InputLayerSizes{2}(1:3);
        scale = [1 1 outputSize./inputImageSize];        
    end
    inputTensorSize = inputTensorSize([4 1 2 3]); % CHWD
else
    error(message("nnet_cnn_onnx:onnx:UnexpectedLayer", 'nnet.cnn.layer.Resize2DLayer', 'nnet.cnn.layer.Resize3DLayer', class(this.NNTLayer)));
end
end

function [resizeNode,parameterInitializers] = iFillResizeNodeAttributes(resizeNode, scale, method)
import nnet.internal.cnn.onnx.*
if numel(resizeNode.input) == 1
    resizeNode.attribute = [...
        makeAttributeProto('scales', 'FLOATS', scale),...
        makeAttributeProto('mode', 'STRING', method)
        ];
    parameterInitializers   = [];
else
    resizeNode.attribute = [...
        nnet.internal.cnn.onnx.makeAttributeProto('mode', 'STRING', method)
        ];
    
    % Make parameter for scales.
    t1              = TensorProto;
    t1.name         = [resizeNode.name '_scales'];
    t1.data_type	= TensorProto_DataType.FLOAT;
    t1.raw_data     = rawData(single(scale));
    t1.dims         = dimVector(numel(scale),1);
    
    parameterInitializers   = t1;
end
end

function val  = iConvertGeometricTransformToONNX(val)
if strcmp(val,'half-pixel')
    val = 'half_pixel';
end
end

function val  = iConvertNearestModeToONNX(val, isUpsample)
if strcmp(val,'round')
    val = 'round_prefer_ceil';
else
    if isUpsample
        val = 'floor';
    else
        val = 'ceil';
    end
end
end