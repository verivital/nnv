classdef ConverterForSigmoidLayer < nnet.internal.cnn.onnx.NNTLayerConverter
    % Class to convert a SigmoidLayer into ONNX
        
    % Copyright 2020-2021 The MathWorks, Inc.

    methods
        function this = ConverterForSigmoidLayer(layerAnalyzer)
            this@nnet.internal.cnn.onnx.NNTLayerConverter(layerAnalyzer);
        end
        
        function [nodeProto, parameterInitializers,...
                networkInputs, networkOutputs, TensorNameMap, TensorLayoutMap]...
                = toOnnx(this, nodeProto, TensorNameMap, TensorLayoutMap)
            import nnet.internal.cnn.onnx.*
            
            [onnxName, nameChanged] = legalizeNNTName(this, this.NNTLayer.Name);
            inputTensorNames    = mapTensorNames(this, this.InputLayerNames, TensorNameMap);
            inputTensorLayout   = TensorLayoutMap(inputTensorNames{1});
            
            % Make the nodeProto
            newNode           = NodeProto;
            newNode.op_type	  = 'Sigmoid';
            newNode.name      = onnxName;
            newNode.input     = mapTensorNames(this, this.InputLayerNames(1), TensorNameMap);
            newNode.output    = {onnxName};
            
            nodeProto(end+1)        = newNode;
            parameterInitializers   = [];
            networkInputs           = [];
            networkOutputs          = [];
            
            if nameChanged
                TensorNameMap(this.NNTLayer.Name) = onnxName;
            end
            TensorLayoutMap(onnxName) = inputTensorLayout;
            
            % Update network if current layer is danglingLayer
            [nodeProto, networkOutputs, TensorNameMap, TensorLayoutMap] ...
                = this.updateNetworkOutputForDanglingLayers(nodeProto, networkOutputs, TensorNameMap, TensorLayoutMap);
        end
    end
end
