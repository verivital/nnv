classdef CustomLayerManager < handle

    % Copyright 2021-2024 The MathWorks, Inc.

    properties (SetAccess=protected)
        %% Graph-related properties

        % The top-level graph of the model
        TopLevelGraphProtoManager nnet.internal.cnn.onnx.GraphProtoManager

        % The full graph as digraphs
        NodeDigraph                     % digraph nodes are ONNX nodes

        %% Tensor-labeling properties

        % An object containing ONNX tensor labels and the names of fully-supported nodes
        OnnxTensorLabeler nnet.internal.cnn.onnx.ONNXTensorLabeler

        %% Custom layer-related properties

        % Package name in which to save custom layer classdef files
        PackageName char
        OrigPackageName char

        % An array of the names of the generated custom layer classes
        CustomLayerNames string

        % The input DLT format strings of the generated
        % custom layer classes. A cell array of string arrays.
        CustomLayerDLTInputFormats cell

        % The output DLT format strings of the generated custom layer
        % classes. A cell array of string arrays.
        CustomLayerDLTOutputFormats cell

        % A map from node names to custom layer names
        NodeToCustomLayerMap % containers.Map

        % An array of ModelProto objects, one for each custom layer
        ModelProtos nnet.internal.cnn.onnx.ModelProto

        % An array of ModelTranslation objects, one for each custom layer
        ModelTranslations nnet.internal.cnn.onnx.fcn.ModelTranslation

        % FullySupportedNodeNames
        FullySupportedNodeNames string

        % Whether any custom layers were created by splitting a concave
        % connected component, causing one layer to pass dlarrays to the
        % other
        AnyCoupledCustomLayers logical = false

        % How to handle grouping of nodes when creating custom layers.
        CustomLayerContent string

        %% Other properties
        OpsetVersion double
    end

    methods
        function this = CustomLayerManager(graphProtoManager, opsetVersion, ...
                onnxTensorLabeler, fullySupportedNodeNames, packageName, ...
                origPackageName, CustomLayerContent)
            this.TopLevelGraphProtoManager = graphProtoManager;
            this.OpsetVersion           = opsetVersion;
            this.OnnxTensorLabeler      = onnxTensorLabeler;
            this.NodeToCustomLayerMap   = containers.Map;
            this.FullySupportedNodeNames = fullySupportedNodeNames;
            this.PackageName            = packageName;
            this.OrigPackageName        = origPackageName;
            this.NodeDigraph            = graphProtoToDigraph(graphProtoManager);
            this.CustomLayerContent        = CustomLayerContent;

            customDigraphs = segmentUnsupportedSubgraphs(this);
            if ~isempty(customDigraphs)
                warnIfPackageNameChanged(this);
            end
            dynamicReferencesCell = findNonlocalDynamicTensorReferences(this, customDigraphs);
            for i=1:numel(customDigraphs)
                nodeNames = string(customDigraphs{i}.Nodes.Name);
                nameStem = makeCustomLayerName(this, nodeNames);
                this.ModelProtos(i) = subgraphToModelProto(this, nodeNames, nameStem, dynamicReferencesCell{i}, dynamicReferencesCell);
                this.ModelTranslations(i) = genCustomLayerFunction(this, this.ModelProtos(i), nameStem);
                [this.CustomLayerNames(i), this.CustomLayerDLTInputFormats{i}, ...
                    this.CustomLayerDLTOutputFormats{i}, classFileCode] = genCustomLayerClass(this, this.ModelTranslations(i), nameStem);
                addToCustomLayerMap(this, nodeNames, this.CustomLayerNames(i));
                % Write a classdef file.
                writeClassdefFile(this, this.CustomLayerNames(i), classFileCode);
            end
            % Rehash to make sure newly-written classdefs are found
            rehash
        end

        function warnIfPackageNameChanged(this)
            if ~isequal(this.PackageName, this.OrigPackageName)
                warning(message('nnet_cnn_onnx:onnx:InvalidPackageName', this.OrigPackageName, this.PackageName))
            end
        end

        function cellOfCellstrs = findNonlocalDynamicTensorReferences(this, customDigraphs)
            % For each component, find tensor names that are referenced
            % from inside the component's nested graphs via dynamic
            % scoping, but which are not created by this component. (Later,
            % these tensors will be made inputs to the custom layer for
            % this component.) The candidates in the toplevel graph are all
            % graph inputs and all node output tensors. Initializers aren't
            % candidates, even if they're dynamically referenced, because
            % they're known at translation-time. So they can be put right
            % into the network at translation time and don't need to be
            % passed around at runtime
            cellOfCellstrs = {};
            graphProtoManager = this.TopLevelGraphProtoManager;
            candidates = unique([graphProtoManager.ExternalInputNames allNodeOutputNames(graphProtoManager)], 'stable');
            for i=1:numel(customDigraphs)
                subgraphNodeNames = string(customDigraphs{i}.Nodes.Name);
                subgraphNodeProtos = nodesFromNames(graphProtoManager, subgraphNodeNames);
                dynamicRefsForDigraph = string.empty;
                for nodeNum = 1:numel(subgraphNodeProtos)
                    dynamicRefsForDigraph = [dynamicRefsForDigraph, dynamicallyReferencedTensorNamesInNode(graphProtoManager, subgraphNodeProtos(nodeNum), candidates)];
                end
                % Now, from among the dynamic references, find the nonlocal
                % ones (tensors not created in, or input to, this digraph).
                % We remove all output tensors in this subgraph, because
                % they were locally created. We also remove all inputs,
                % because those will already have been made available to
                % this custom layer.
                allSubgraphInputNames = unique([subgraphNodeProtos.input], 'stable');
                allSubgraphOutputNames = unique([subgraphNodeProtos.output], 'stable');
                nonlocalDynamicRefs = setdiff(dynamicRefsForDigraph, [allSubgraphInputNames, allSubgraphOutputNames], 'stable');
                % Return that list for this subgraph
                cellOfCellstrs{i} = cellstr(nonlocalDynamicRefs);
            end
        end

        function nameStem = makeCustomLayerName(this, customLayerNodeNames)
            if numel(customLayerNodeNames)<2
                firstNodeName = customLayerNodeNames(1);
                firstNode = nodesFromNames(this.TopLevelGraphProtoManager, firstNodeName);
                firstNodeOpType = firstNode.op_type;
                nameStem = firstNodeOpType;
            else
                firstAndLastNodeNames = [customLayerNodeNames(1) customLayerNodeNames(end)];
                firstAndLastNodes = nodesFromNames(this.TopLevelGraphProtoManager, firstAndLastNodeNames);
                firstNodeOpType = firstAndLastNodes(1).op_type;
                lastNodeOpType = firstAndLastNodes(2).op_type;
                nameStem = firstNodeOpType + "_To_" + lastNodeOpType;
            end
        end

        % Questions about the custom layers
        function onnxParams = onnxParamsForLayerName(this, layerName)
            [~,loc] = ismember(layerName, this.CustomLayerNames);
            onnxParams = this.ModelTranslations(loc).Params;
        end

        function names = customLayerInputTensorNames(this, layerName)
            [~,loc] = ismember(layerName, this.CustomLayerNames);
            names = string(this.ModelTranslations(loc).ToplevelGraphTranslation.ExternalInputNames);
        end

        function names = customLayerInputNumDimsNames(this, layerName)
            inputTensorNames = customLayerInputTensorNames(this, layerName);
            hasNumDims = isTensorWithNumDims(this, inputTensorNames);
            if any(hasNumDims)
                names = inputTensorNames(hasNumDims) + "NumDims";
            else
                names = string.empty;
            end
        end

        function names = customLayerOutputTensorNames(this, layerName)
            % Output tensor names, not including NumDims outputs.
            [~,loc] = ismember(layerName, this.CustomLayerNames);
            names = string(this.ModelTranslations(loc).ToplevelGraphTranslation.ExternalOutputNames);
        end

        function names = customLayerOutputNumDimsNames(this, layerName)
            outputTensorNames = customLayerOutputTensorNames(this, layerName);
            hasNumDims = isTensorWithNumDims(this, outputTensorNames);
            if any(hasNumDims)
                names = outputTensorNames(hasNumDims) + "NumDims";
            else
                names = string.empty;
            end
        end

        function tf = isNodeLastInSubgraph(this, nodeName, customLayerName)
            % Returns true if the node is (topologically) last in its
            % subgraph. This means all of the subgraph's input tensors are
            % available.
            [~,customLayerIdx] = ismember(customLayerName, this.CustomLayerNames);
            subgraphModelProto = this.ModelProtos(customLayerIdx);
            lastSubgraphNodeName = subgraphModelProto.graph.node(end).name;
            tf = isequal(nodeName, lastSubgraphNodeName);
        end

        function customLayerName = nodeCustomLayerName(this, nodeName)
            % Return the name of the auto-generated custom layer that
            % includes node nodeName, or empty if the node is not in a
            % custom layer.
            if isKey(this.NodeToCustomLayerMap, nodeName)
                customLayerName = this.NodeToCustomLayerMap(nodeName);
            else
                customLayerName = string.empty;
            end
        end

        function tf = isTensorLabeled(this, tensorName)
            tf = tensorLabel(this, tensorName) ~= "";
        end

        function str = tensorLabel(this, tensorName)
            str = tensorLabel(this.OnnxTensorLabeler, tensorName);
        end

        function tfs = isTensorWithNumDims(this, tensorNames)
            % true for each tensor that needs an accompanying numdims
            % variable. This is all tensors that are unlabeled and which
            % are not output tensors of the top-level graph. It includes
            % unlabeled input tensors and internal tensors created by
            % auto-generated custom layers.
            isLabeled           = arrayfun(@(name)isTensorLabeled(this, name), tensorNames);
            isExternalOutput    = arrayfun(@(name)ismember(name, this.TopLevelGraphProtoManager.OutputNames), tensorNames);
            tfs                 = ~isLabeled & ~isExternalOutput;
        end
    end

    methods(Access=protected)
        function writeClassdefFile(this, className, code)
            % className string
            % code char
            outputFilename = className + ".m";
            folderName = "+" + this.PackageName;
            outputPath = fullfile(folderName, outputFilename);
            % Save code to file
            if isempty(dir(folderName))   % Search the current directory, not the path.
                try
                    mkdir(folderName);
                catch me
                    error(message('nnet_cnn_onnx:onnx:MkdirFailed', folderName, me.message));
                end
            end
            if ~isempty(dir(outputPath))   % Search the current directory, not the path.
                try
                    delete(outputPath);
                catch me
                    error(message('nnet_cnn_onnx:onnx:FileOverwrite', outputPath, me.message));
                end
            end
            [f, errmsg] = fopen(outputPath, 'w');
            if f < 0
                error(message('nnet_cnn_onnx:onnx:FileCreation', outputPath, errmsg));
            end
            fprintf(f, '%s', code);
            fclose(f);
        end

        function addToCustomLayerMap(this, nodeNames, customLayerName)
            for i=1:numel(nodeNames)
                this.NodeToCustomLayerMap(nodeNames(i)) = customLayerName;
            end
        end

        %% Segmenting out unsupported subgraphs, and generating custom layer code

        function digraphCell = segmentUnsupportedSubgraphs(this)
            % Toposort the graph, then rename the nodes by number. Then,
            % any subset of nodes can be toposorted by just sorting their
            % names numerically.
            [~, fullGraph] = toposort(this.NodeDigraph, 'Order', 'stable');
            origNodeNames = string(fullGraph.Nodes{:,:});                 	% Maps nodeNum-->original name
            nodeNums = 1:numel(origNodeNames);
            nodeNumMap = containers.Map;
            if ~isempty(origNodeNames)
                nodeNumMap = containers.Map(origNodeNames, nodeNums);          	% Maps origNodeName-->nodeNum
            end
            fullGraph.Nodes.Name = string(nodeNums)';                       % This renames the edges too
            % Make reachability and adjacency matrices
            FullReachabilityMatrix = iMakeReachabilityMatrix(fullGraph);
            FullAdjacencyMatrix = full(adjacency(fullGraph));
            % Delete fully-supported nodes
            FullySupportedNodeNums = arrayfun(@(name)nodeNumMap(name), this.FullySupportedNodeNames);
            unsupportedSubgraph = rmnode(fullGraph, FullySupportedNodeNums);
            % Check whether the subgraph is empty
            digraphCell = {};
            if numel(unsupportedSubgraph.Nodes) > 0
                % Make digraphs of unsupported nodes
                if ismember(this.CustomLayerContent, ["groupedOperators", "entireNetwork"])
                    % Find connected components covering all unsupported nodes
                    digraphCell = iConnectedComponentDigraphs(unsupportedSubgraph);
                else
                    assert(isequal(this.CustomLayerContent, "individualOperators"))
                    % Make each unsupported node into its own (trivial) digraph
                    digraphCell = iSingleNodeDigraphs(unsupportedSubgraph);
                end                    
                numComponents = numel(digraphCell);
                % Split concave digraphs into convex ones
                digraphCell = splitConcaveDigraphs(this, digraphCell, fullGraph, FullReachabilityMatrix, FullAdjacencyMatrix);
                % Restore the original names in all the graphs
                digraphCell = restoreOriginalSubgraphNames(this, digraphCell, origNodeNames);
                % Record whether any components were split, thereby
                % creating "coupled" custom layers
                if numel(digraphCell) > numComponents
                    this.AnyCoupledCustomLayers = true;
                end
            end
        end

        function digraphCell = splitConcaveDigraphs(this, digraphCell, fullGraph, FullReachabilityMatrix, FullAdjacencyMatrix)
            % Split convex digraphs into concave ones, delete them from the
            % list, and add the new ones to the end. Iterate in reverse so
            % we can stably modify the list as we go
            for i = numel(digraphCell):-1:1
                [isConcave, badOutputNodeNames] = isConcaveSubgraph(this, digraphCell{i}.Nodes.Name, fullGraph, FullReachabilityMatrix, FullAdjacencyMatrix);
                if isConcave
                    newDigraphs = splitOneConcaveDigraph(this, fullGraph, digraphCell{i}, badOutputNodeNames);
                    digraphCell(i) = [];
                    digraphCell = [digraphCell, newDigraphs]; %#ok<*AGROW>
                end
            end
        end

        function digraphCell = splitOneConcaveDigraph(~, fullGraph, dg, badOutputNodeNames)
            % Split the node list at the "bad" output nodes. First, sort
            % the nodes "globally topologically" so that all nodes upstream
            % of a 'bad' node precede it in the list. This is why we
            % renamed all the nodes as numbers, so we can do this on a
            % subgraph using 'sort'. It would NOT be enough to just sort
            % the subgraph topologically in isolation.
            digraphCell = {};
            dgNodeNames = string(sort(str2double(dg.Nodes.Name)));              % Globally toposort the dg node names.
            badOutputNodeNames = string(sort(str2double(badOutputNodeNames)));  % Globally toposort the badOutputNodeNames.
            % Split into subgraphs at each bad node
            [~, badLocs] = ismember(badOutputNodeNames, dgNodeNames);
            splitLocs = [0, badLocs(:)', numel(dgNodeNames)];                   % Note that the last node can't be bad
            for i = 2:numel(splitLocs)
                subgraphNodeNames = dgNodeNames(splitLocs(i-1)+1 : splitLocs(i));
                newDg = subgraph(fullGraph, subgraphNodeNames);
                % newDg may consist of disjoint components. Split them and
                % append them to the list
                newDgCell = iConnectedComponentDigraphs(newDg);
                digraphCell = [digraphCell, newDgCell];
            end
        end

        function [tf, badOutputNodeNames] = isConcaveSubgraph(~, nodeNames, fullGraph, FullReachabilityMatrix, FullAdjacencyMatrix)
            % Return true if the subgraph defined by nodeNames is a concave
            % subgraph of the full graph. Algorithm: Find all nodes that
            % are forward-reachable from any of the subgraph's nodes and
            % also backward-reachable from any of the subgraph's nodes.
            % (Note that this does not contain all nodes in the subgraph
            % itself.) If any such nodes are outside the subgraph, return
            % true. badOutputNodeNames is a cellstr of nodes in the
            % subgraph that send connections directly to external nodes.
            [~,nodeIdx] = ismember(nodeNames, fullGraph.Nodes.Name);
            fwd         = sum(FullReachabilityMatrix(nodeIdx,:), 1) > 0;
            bwd         = sum(FullReachabilityMatrix(:,nodeIdx), 2)' > 0;
            bothIdx     = find(fwd & bwd);
            externalIdx = setdiff(bothIdx, nodeIdx);
            tf          = ~isempty(externalIdx);
            % Find bad output nodes
            badOutputNodeNames = {};
            if tf
                block               = FullAdjacencyMatrix(nodeIdx, externalIdx);
                blockIdx            = sum(block, 2) > 0;  % Indices into the nodeIdx list
                badOutputIdx        = nodeIdx(blockIdx);
                badOutputNodeNames  = fullGraph.Nodes.Name(badOutputIdx);
            end
        end

        function digraphCell = restoreOriginalSubgraphNames(~, digraphCell, origNodeNames)
            % Restore the original names in all the graphs
            for i=1:numel(digraphCell)
                nodeNums = str2double(digraphCell{i}.Nodes.Name);
                origNames = origNodeNames(nodeNums);
                digraphCell{i}.Nodes.Name = origNames;                                  % This renames the edges too
            end
        end

        function modelProto = subgraphToModelProto(this, subgraphNodeNames, modelName, ...
                myDynamicTensorReads, allDynamicTensorReads)
            % Create a modelProto from a subset of nodes in a graph. The
            % nodes are assumed to constitute a connected component (DAG).
            % This modelProto will later be converted into a custom layer.
            [subgraphInputActivationNames, subgraphOutputActivationNames] = findSubgraphInputAndOutputNames(this, subgraphNodeNames, myDynamicTensorReads, allDynamicTensorReads);
            [inputVIPs, outputVIPs] = makeSubgraphInputAndOutputVIPs(this, subgraphInputActivationNames, subgraphOutputActivationNames);
            % Select the initializers used in this subgraph
            subgraphNodeProtos       = nodesFromNames(this.TopLevelGraphProtoManager, subgraphNodeNames);
            allSubgraphInputNames    = iFindAllSubgraphInputNames(subgraphNodeProtos);
            subgraphInitializerNames = intersect(this.TopLevelGraphProtoManager.AllInitializerNames, allSubgraphInputNames);
            fullInitializers         = findFullInitializers(this.TopLevelGraphProtoManager, subgraphInitializerNames);
            sparseInitializers       = findSparseInitializers(this.TopLevelGraphProtoManager, subgraphInitializerNames);
            % First create a graphProto:
            %            node: [1×66 nnet.internal.cnn.onnx.NodeProto]
            %            name: 'squeezenet'
            %     initializer: [1×52 nnet.internal.cnn.onnx.TensorProto]
            %      doc_string: []
            %           input: [1×53 nnet.internal.cnn.onnx.ValueInfoProto]
            %          output: [1×1 nnet.internal.cnn.onnx.ValueInfoProto]
            %      value_info: []
            subgraphProto                    = nnet.internal.cnn.onnx.GraphProto;
            subgraphProto.name               = char(modelName);
            subgraphProto.node               = subgraphNodeProtos;
            subgraphProto.initializer        = fullInitializers;
            subgraphProto.sparse_initializer = sparseInitializers;
            subgraphProto.input              = inputVIPs;
            subgraphProto.output             = outputVIPs;
            % Now create the modelProto
            opsetIdProto = nnet.internal.cnn.onnx.OperatorSetIdProto;
            opsetIdProto.version        = int64(this.OpsetVersion);
            modelProto                  = nnet.internal.cnn.onnx.ModelProto;
            modelProto.ir_version       = int64(1.6);
            modelProto.opset_import     = opsetIdProto;
            modelProto.producer_name    = '';
            modelProto.producer_version = '';
            modelProto.domain           = '';
            modelProto.model_version  	= int64(1);
            modelProto.doc_string       = char(modelName);               % Storing the model name in it's doc_string field.
            modelProto.graph            = subgraphProto;
            modelProto.metadata_props	= [];
        end

        function [inputNames, outputNames] = findSubgraphInputAndOutputNames(this, subgraphNodeNames, myDynamicTensorReads, allDynamicReferencesCell)
            subgraphNodeProtos = nodesFromNames(this.TopLevelGraphProtoManager, subgraphNodeNames);
            allSubgraphOutputNames = unique([subgraphNodeProtos.output], 'stable');                               % Includes intermediate tensors
            allSubgraphOutputNames(cellfun(@isempty, allSubgraphOutputNames)) = [];
            nonSubgraphNodeNames = setdiff(this.TopLevelGraphProtoManager.NodeNames, subgraphNodeNames, 'stable');
            nonSubgraphNodeProtos = nodesFromNames(this.TopLevelGraphProtoManager, nonSubgraphNodeNames);
            % Find the activation inputs to the subgraph. These are the
            % node inputs minus tensors created inside the subgraph, minus
            % initializers:
            allInitializerNames = this.TopLevelGraphProtoManager.AllInitializerNames;
            inputNames = setdiff(unique([subgraphNodeProtos.input], 'stable'), allSubgraphOutputNames, 'stable');   % External inputs only (activations and weights).
            inputNames = setdiff(inputNames, allInitializerNames, 'stable');                      % External activation inputs only.
            inputNames(cellfun(@isempty, inputNames)) = [];
            % Add tensors that are created outside this custom layer and
            % read from my nested graphs via dynamic scoping
            inputNames = [inputNames, myDynamicTensorReads];
            % outputNames are all subgraph node outputs that are consumed
            % outside the subgraph. This includes (1) tensors that are
            % inputs to nonsubgraph nodes, (2) tensors that are external
            % outputs of the parent graph, and (3) tensors that are known
            % to be accessed by other layers' nested graphs but not created
            % by those layers:
            allConsumedTensorNames = unique([...
                this.TopLevelGraphProtoManager.OutputNames, ...    % Put outputs first so they're in the same order as in the network...
                [nonSubgraphNodeProtos.input],...
                [allDynamicReferencesCell{:}]...   % These are consumed by other layers but not necessarily created here.
                ], 'stable');
            outputNames = intersect(allConsumedTensorNames, allSubgraphOutputNames, 'stable');   % ... put outputs first here too.
        end

        function [inputVIPs, outputVIPs] = makeSubgraphInputAndOutputVIPs(this, subgraphInputActivationNames, subgraphOutputActivationNames)
            parentGraphMgr = this.TopLevelGraphProtoManager;
            % This subgraph may have input activation tensors that were not
            % inputs to the original graph, namely intermediate activation
            % tensors of the original graph. These intermedite tensors need
            % to have valueInfoProtos created for them.
            %   * First, copy known VIPs from full graph:
            [inputVIPFound, inputLocs] = ismember(subgraphInputActivationNames, parentGraphMgr.InputNames);
            inputVIPs(inputVIPFound) = parentGraphMgr.InputVIPs(inputLocs(inputVIPFound));
            %   * Next, make VIPs for intermediate tensors
            notFoundNames = subgraphInputActivationNames(~inputVIPFound);
            notFoundLocs = find(~inputVIPFound);
            for i=1:numel(notFoundNames)
                name = notFoundNames{i};
                loc = notFoundLocs(i);
                if isTensorLabeled(this, name)
                    % This input tensor is labeled, so create a VIP of known rank.
                    ndims = strlength(tensorLabel(this, name));
                    inputVIPs(loc) = nnet.internal.cnn.onnx.makeValueInfoProtoOfVariableSize(name, nnet.internal.cnn.onnx.TensorProto_DataType.FLOAT, ndims);
                else
                    % This input tensor is not labeled, so create a VIP of unknown rank.
                    inputVIPs(loc) = nnet.internal.cnn.onnx.makeValueInfoProtoOfUnknownRank(name, nnet.internal.cnn.onnx.TensorProto_DataType.FLOAT);
                end
            end
            % Special case of a custom layer with no inputs: Have it take
            % input from the first input to the network.
            if isempty(inputVIPs)
                dummyInputName = parentGraphMgr.InputNames{1};
                inputVIPs = nnet.internal.cnn.onnx.makeValueInfoProtoOfUnknownRank(dummyInputName, nnet.internal.cnn.onnx.TensorProto_DataType.FLOAT);
            end
            % This subgraph may have output activation tensors that were
            % not outputs of the original graph, namely intermediate
            % activation tensors of the original graph. These intermediate
            % tensors need to have valueInfoProtos created for them.
            %   * First, copy known output tensor VIPs from full graph:
            [outputVIPFound, outputLocs] = ismember(subgraphOutputActivationNames, parentGraphMgr.OutputNames);
            outputVIPs(outputVIPFound) = parentGraphMgr.OutputVIPs(outputLocs(outputVIPFound));
            %   * Next, make VIPs for subgraph output tensors
            notFoundNames = subgraphOutputActivationNames(~outputVIPFound);
            notFoundLocs = find(~outputVIPFound);
            for i=1:numel(notFoundNames)
                name = notFoundNames{i};
                loc = notFoundLocs(i);
                if isTensorLabeled(this, name)
                    % This tensor has a known ONNX format.
                    ndims = strlength(tensorLabel(this, name));
                    outputVIPs(loc) = nnet.internal.cnn.onnx.makeValueInfoProtoOfVariableSize(name, nnet.internal.cnn.onnx.TensorProto_DataType.FLOAT, ndims);	% ndims is specified but not the sizes.
                else
                    % This tensor has an unknown ONNX format.
                    outputVIPs(loc) = nnet.internal.cnn.onnx.makeValueInfoProtoOfUnknownRank(name, nnet.internal.cnn.onnx.TensorProto_DataType.FLOAT);          % The shape of this VIP is empty.
                end
            end
        end

        %% Code generation
        function modelTranslation = genCustomLayerFunction(~, modelProto, nameStem)
            maxNameLength = 20;
            modelFcnPath = "";  % Current directory
            modelFcnName = nameStem + "Fcn";
            modelTranslation = nnet.internal.cnn.onnx.fcn.ModelTranslation(modelProto, modelFcnPath, modelFcnName, maxNameLength, true);
        end

        function [className, DLTInputFormats, DLTOutputFormats, classFileCode] = genCustomLayerClass(this, modelTranslation, nameStem)
            % Generate custom layer class code and save to file. Model
            % function code is included in the file.
            className       = nnet.internal.cnn.onnx.fcn.uniqueName(nameStem + "Layer");
            modelFcnName    = nameStem + "Fcn";
            learnableNames  = string(fieldnames(modelTranslation.Params.Learnables));
            predictInputTensorNames = string(modelTranslation.ToplevelGraphTranslation.ExternalInputNames);
            needsNumDims = isTensorWithNumDims(this, predictInputTensorNames);
            if any(needsNumDims)
                predictInputNumDimsNames = predictInputTensorNames(needsNumDims) + "NumDims";
            else
                predictInputNumDimsNames = string.empty;
            end
            predictInputNames = [predictInputTensorNames predictInputNumDimsNames];
            inputModelFcnNumDimsNames = predictInputTensorNames + "NumDims";                 % Pass all input variable numdims to the modelfcn.
            inPermCell = modelFcnInputDataPermutations(this, predictInputTensorNames);
            numDimsVarsCode = genNumDimsVarsCode(this, predictInputTensorNames);
            % Outputs
            predictOutputTensorNames  = string(modelTranslation.ToplevelGraphTranslation.ExternalOutputNames);
            needsNumDims = isTensorWithNumDims(this, predictOutputTensorNames);
            if any(needsNumDims)
                predictOutputNumDimsNames = predictOutputTensorNames(needsNumDims) + "NumDims";
            else
                predictOutputNumDimsNames = string.empty;
            end
            predictOutputNames = [predictOutputTensorNames predictOutputNumDimsNames];
            outputModelFcnNumDimsNames = predictOutputTensorNames + "NumDims";
            outPermCell = modelFcnOutputDataPermutations(this, predictOutputTensorNames);
            % Set DLTInputFormats. NumDims vars will have "".
            DLTInputFormats = repmat("", 1, numel(predictInputNames));
            for i=1:numel(predictInputTensorNames)
                tensorName = predictInputTensorNames(i);
                label = tensorLabel(this, tensorName);
                DLTInputFormats(i) = nnet.internal.cnn.onnx.ModelTranslationIntoLayers.onnxLabelToDLTLabel(label);
            end
            % Set DLTOutputFormats. NumDims vars will have "".
            DLTOutputFormats = repmat("", 1, numel(predictOutputNames));
            for i=1:numel(predictOutputTensorNames)
                tensorName = predictOutputTensorNames(i);
                label = tensorLabel(this, tensorName);
                DLTOutputFormats(i) = nnet.internal.cnn.onnx.ModelTranslationIntoLayers.onnxLabelToDLTLabel(label);
            end
            % Generate numInputs, numOutputs lines
            NumInputsLine = string.empty;
            if numel(predictInputNames)>1
                NumInputsLine = "this.NumInputs = " + numel(predictInputNames) + ";";
            end
            NumOutputsLine = string.empty;
            if numel(predictOutputNames)>1
                NumOutputsLine = "this.NumOutputs = " + numel(predictOutputNames) + ";";
            end
            % Generate OutputNames line
            OutputNamesLine = "this.OutputNames = {'" + strjoin(predictOutputNames, "', '") + "'};";
            % Code to check for illegal outputs (empty or nonnumeric tensors)
            checkOutputsCode = genCodeToCheckOutputs(this, className, predictOutputTensorNames);
            % Code to apply dlarray formats to the layer's outputs
            outputFormatCode = genCodeToLabelOutputs(this, predictOutputTensorNames, predictOutputNumDimsNames);
            % Code to support codegen
            codegenCode = predictOutputCodegen(this, [predictOutputTensorNames, predictOutputNumDimsNames]);
            % Assemble the classdef code
            classdefCode = [
                "classdef " + className + " < nnet.layer.Layer & nnet.layer.Formattable"
                "% " + getString(message('nnet_cnn_onnx:onnx:CustomLayerDescription'))
                ""
                "%#codegen"
                "%#ok<*PROPLC>"
                "%#ok<*NBRAK>"
                "%#ok<*INUSL>"
                "%#ok<*VARARG>"
                ""
                "properties (Learnable)"
                learnableNames
                "end"
                ""
                "properties"
                "ONNXParams         % " + getString(message('nnet_cnn_onnx:onnx:CustomLayerONNXParams'))
                "end"
                ""
                "methods"
                "function this = " + className + "(name, onnxParams)"
                "this.Name = name;"
                NumInputsLine
                NumOutputsLine
                OutputNamesLine
                "this.ONNXParams = onnxParams;"
                iAssignPropertiesFromONNXParamsCode(learnableNames)
                "end"
                ""
                "function " + "[" + join(predictOutputNames, ", ") + "] = predict(this, " + join(predictInputNames, ", ") + ")"
                iStripInputDimsCode(predictInputTensorNames)
                numDimsVarsCode
                iAssignONNXParamsFromPropertiesCode(learnableNames)
                "[" + join([predictOutputTensorNames outputModelFcnNumDimsNames], ", ") + "] = " + modelFcnName + "(" + join([predictInputTensorNames inputModelFcnNumDimsNames], ", ") + ", onnxParams, 'Training', false, ..."
                "'InputDataPermutation', " + iStringifyPermutationCell(inPermCell) + ", ..."
                "'OutputDataPermutation', " + iStringifyPermutationCell(outPermCell) + ");"
                checkOutputsCode
                outputFormatCode
                codegenCode
                "end"
                ""
                "function " + "[" + join(predictOutputNames, ", ") + "] = forward(this, " + join(predictInputNames, ", ") + ")"
                iStripInputDimsCode(predictInputTensorNames)
                numDimsVarsCode
                iAssignONNXParamsFromPropertiesCode(learnableNames)
                "[" + join([predictOutputTensorNames outputModelFcnNumDimsNames], ", ") + "] = " + modelFcnName + "(" + join([predictInputTensorNames inputModelFcnNumDimsNames], ", ") + ", onnxParams, 'Training', true, ..."
                "'InputDataPermutation', " + iStringifyPermutationCell(inPermCell) + ", ..."
                "'OutputDataPermutation', " + iStringifyPermutationCell(outPermCell) + ");"
                checkOutputsCode
                outputFormatCode
                codegenCode
                "end"
                "end"
                "end"
                ];
            classdefCode = string(nnet.internal.cnn.onnx.util.indentcode(char(join(classdefCode',newline))));
            classFileCode = classdefCode + newline + newline + modelTranslation.ModelFunctionCode;
        end

        function numDimsVarsCode = genNumDimsVarsCode(this, predictInputTensorNames)
            % Gen code to assign values to numdims vars in this custom
            % layer
            numDimsVarsCode = string.empty;
            for i=1:numel(predictInputTensorNames)
                tensorName = string(predictInputTensorNames(i));
                numDimsVarName = tensorName + "NumDims";
                label = tensorLabel(this, tensorName);
                if label==""
                    % For unlabeled tensors, numDims is passed as an input
                    % to its predict() and forward() methods as a vector of
                    % length NumDims.
                    numDimsVarsCode = [numDimsVarsCode; numDimsVarName + " = numel(" + numDimsVarName + ");"];
                else
                    % For labeled tensors, we can derive NumDims from the
                    % label
                    numDimsVarsCode = [numDimsVarsCode; numDimsVarName + " = " + string(strlength(label)) + ";"];
                end
            end
        end

        function permCell = modelFcnInputDataPermutations(this, inputTensorNames)
            % Find input permutation vectors. Labeled tensors need to be
            % permuted from DLT to reverse-onnx. Unlabeled tensors are
            % already in reverse-onnx.
            for i=1:numel(inputTensorNames)
                tensorName = inputTensorNames(i);
                if isTensorLabeled(this, tensorName)
                    permCell{i} = nnet.internal.cnn.onnx.ModelTranslationIntoLayers.permDLTToONNX(tensorLabel(this, tensorName));
                else
                    % Tensor is already in reverse-ONNX dimension ordering
                    permCell{i} = "'as-is'";
                end
            end
            % Add 'as-is' permutations for all the numdims input vars
            inputNumDimsNames = inputTensorNames + "NumDims";
            for i=1:numel(inputNumDimsNames)
                permCell{end+1} = "'as-is'";
            end
        end

        function permCell = modelFcnOutputDataPermutations(this, outputTensorNames)
            % Find output permutation vectors. Labeled tensors need to be
            % permuted from reverse-onnx to DLT. Unlabeled tensors should
            % remain in reverse-onnx.
            for i=1:numel(outputTensorNames)
                tensorName = outputTensorNames(i);
                if isTensorLabeled(this, tensorName)
                    permCell{i} = nnet.internal.cnn.onnx.ModelTranslationIntoLayers.permONNXToDLT(tensorLabel(this, tensorName));
                else
                    % Tensor stays in reverse-ONNX dimension ordering.
                    permCell{i} = "'as-is'";
                end
            end
            % Add 'as-is' permutations for all the numdims output vars
            outputNumDimsNames = outputTensorNames + "NumDims";
            for i=1:numel(outputNumDimsNames)
                permCell{end+1} = "'as-is'";
            end
        end

        function checkOutputsCode = genCodeToCheckOutputs(~, className, predictOutputTensorNames)
            % Generate code to check for illegal outputs (nonnumeric, non-logical tensors)
            checkOutputsCode = [
                "if any(cellfun(@(A)~isnumeric(A) && ~islogical(A), {" + join(predictOutputTensorNames, ", ") + "}))"
                "fprintf('Runtime error in network. At least one output of custom layer ''%s'' is a non-numeric, non-logical value.\n', '" + className + "');"
                "error(message('nnet_cnn_onnx:onnx:BadCustomLayerRuntimeOutput', '" + className + "'));"
                "end"
                ];
        end

        function outputFormatCode = genCodeToLabelOutputs(this, predictOutputTensorNames, predictOutputNumDimsNames)
            % Generate code to label the dlarray outputs of a custom
            % layer's predict method
            outputFormatCode = string.empty;
            outputLabelCell = arrayfun(@(name)tensorLabel(this, name), predictOutputTensorNames, 'UniformOutput',false);
            % Label the output tensors
            for i=1:numel(predictOutputTensorNames)
                if outputLabelCell{i}==""
                    % The output tensor has no label. Generate code that
                    % formats it with U's at runtime
                    outputNumDimsName = predictOutputTensorNames(i) + "NumDims";
                    fmt = "repmat('U', 1, max(2, " + outputNumDimsName + "))";
                    outputFormatCode(i,1) = predictOutputTensorNames(i) + " = dlarray(single(" + predictOutputTensorNames(i) + "), " + fmt + ");";
                else
                    % The output tensor has a label.
                    fmt = nnet.internal.cnn.onnx.ModelTranslationIntoLayers.onnxLabelToDLTLabel(outputLabelCell{i});
                    outputFormatCode(i,1) = predictOutputTensorNames(i) + " = dlarray(single(" + predictOutputTensorNames(i) + "), '" + fmt + "');";
                end
            end
            % Now construct and label the output numDims vars. To pass
            % NumDims between layers, we encode it as a vector of ones,
            % with 'UU' dlarray format. To make sure it respects GPU/CPU
            % status, we make its type 'like' that of the layer's first
            % output tensor.
            for j=1:numel(predictOutputNumDimsNames)
                % Generate code that formats it with UU at runtime
                outputFormatCode(numel(predictOutputTensorNames)+j,1) = ...
                    predictOutputNumDimsNames(j) + " = dlarray(ones(1," + predictOutputNumDimsNames(j) + ",'like'," + predictOutputTensorNames(1) + "), 'UU');";
            end
        end

        function codegenCode = predictOutputCodegen(~, allOutputTensorNames)
            % Generate code to extract data from the output dlarrays if
            % we're doing codegen
            codegenCode = "if ~coder.target('MATLAB')";
            for varName = allOutputTensorNames
                codegenCode = [codegenCode; varName + " = extractdata(" + varName + ");"];
            end
            codegenCode = [codegenCode; "end"];
        end
    end

    methods
        function issues = getCustomLayerTranslationIssues(this)
            % Get the set of translation issues across all generated custom
            % layers.
            issues = arrayfun(@(mt) getTranslationIssues(mt), this.ModelTranslations, 'UniformOutput', false);
            issues = [issues{:}];
        end
    end
end

%% File-internal helper functions

function digraphCell = iConnectedComponentDigraphs(dg)
% Split a digraph into its disjoint connected component digraphs.
digraphCell = {dg};
ccbins = conncomp(dg, 'Type','weak');                           % Find connected components. 'weak' means use connections in both directions.
% Make digraphs from the connected components
for i=1:max(ccbins)
    names               = dg.Nodes.Name(ccbins==i);
    digraphCell{i}      = subgraph(dg, names);
end
end

function digraphCell = iSingleNodeDigraphs(dg)
% Split a digraph into all single-node digraphs.
digraphCell = {dg};
% Make digraphs from the bins
for i=1:height(dg.Nodes)
    name               = dg.Nodes.Name(i);
    digraphCell{i}     = subgraph(dg, name);
end
end

function R = iMakeReachabilityMatrix(dg)
% R(i,j)>0 iff there is a directed path from i to j.
D = transclosure(dg);
R = full(adjacency(D));
end

function code = iAssignPropertiesFromONNXParamsCode(learnableNames)
code = arrayfun(@(name)"this." + name + " = onnxParams.Learnables." + name + ";", learnableNames);
code = code(:);
end

function code = iStripInputDimsCode(inputTensorNames)
code = arrayfun(@(name)"if isdlarray(" + name + ")" + newline + name + " = stripdims(" + name + ");" + newline + "end", inputTensorNames);
code = code(:);
end

function code = iAssignONNXParamsFromPropertiesCode(learnableNames)
code = [
    "onnxParams = this.ONNXParams;"
    arrayfun(@(name)"onnxParams.Learnables." + name + " = this." + name + ";", learnableNames)
    ];
end

function code = iStringifyPermutationCell(permCell)
% permCell is a cell array of numeric permutation vectors. Output a string
% of code that lists those vectors in a cell array.
code = "{";
for i=1:numel(permCell)
    arraycode(i) = "[" + join(string(permCell{i}), ' ') + "]";
end
code = code + join(arraycode, ', ');
code = code + "}";
end

function Names = iFindAllSubgraphInputNames(nodeProtos)
Names = iUniqueInputNamesInGraphTree(nodeProtos);
end

function Names = iUniqueInputNamesInGraphTree(nodeProtos)
% Find all the unique names in the graph tree.
% First, collect all names from the current flat graph:
if ~isempty(nodeProtos)
    Names = [nodeProtos.input];
    % Recursively add names from subgraphs:
    for i=1:numel(nodeProtos)
        Names = [Names iNamesFromNode(nodeProtos(i))];
    end
    % Remove empty names
    isEmptyName = cellfun(@isempty, Names);
    Names(isEmptyName) = [];
    % Get unique names
    Names = unique(Names, 'stable');
else
    Names = {};
end
end

function Names = iNamesFromNode(nodeProto)
% Recursively find all the names in subgraph trees under this node
Names = {};
for i = 1:numel(nodeProto.attribute)
    subgraphs = [nodeProto.attribute(i).g, nodeProto.attribute(i).graphs];
    for g = 1:numel(subgraphs)
        Names = [Names, iUniqueInputNamesInGraphTree(subgraphs(g).node)];
    end
end
end
