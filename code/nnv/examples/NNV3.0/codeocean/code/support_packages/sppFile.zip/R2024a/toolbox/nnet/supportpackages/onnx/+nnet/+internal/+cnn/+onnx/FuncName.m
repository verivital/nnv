classdef FuncName < int32
    
    %   Copyright 2019-2021 The MathWorks, Inc.
    enumeration
        % These fields must exactly match those of onnxmex.cpp/FuncName, in
        % order, and the numeric values here must be 0,1,...
        
        % The (de)serialize functions either save or load a
        % ModelProtoObject to/from file.
        EdeserializeFromFile        (0)
        EserializeToFile            (1)
        
        % The 'decode' functions take a pointer to an ONNX protobuf object
        % and create a MATLAB object that represents it.
        EdecodeModelProto             (2)
        EdecodeOperatorSetIdProto     (3)
        EdecodeGraphProto             (4)
        EdecodeNodeProto              (5)
        EdecodeAttributeProto         (6)
        EdecodeTensorProto            (7)
        EdecodeTensorProto_Segment    (8)
        EdecodeValueInfoProto         (9)
        EdecodeTypeProto              (10)
        EdecodeTypeProto_Map          (11)
        EdecodeTypeProto_Sequence     (12)
        EdecodeTypeProto_Tensor       (13)
        EdecodeTypeProto_Opaque       (14)    
        EdecodeTypeProto_SparseTensor (15)        
        EdecodeStringStringEntryProto (16)
        EdecodeTensorShapeProto       (17)
        EdecodeTensorShapeProto_Dimension (18)
        EdecodeSparseTensorProto      (19)
        EdecodeTensorAnnotation       (20)
        EdecodeTrainingInfoProto      (21)
        
        % The 'encode' functions take a MATLAB object and create a C++ ONNX
        % protobuf object out of it, returning a pointer back to MATLAB.
        EnewModelProto                  (22)
        EencodeModelProto             	(23)
        EencodeOperatorSetIdProto       (24)
        EencodeGraphProto           	(25)
        EencodeNodeProto                (26)
        EencodeAttributeProto        	(27)
        EencodeTensorProto              (28)
        EencodeTensorProto_Segment      (29) 
        EencodeValueInfoProto           (30)
        EencodeTypeProto                (31)
        EencodeTypeProto_Map            (32)
        EencodeTypeProto_Sequence       (33)
        EencodeTypeProto_Tensor         (34)
        EencodeTypeProto_Opaque         (35)
        EencodeTypeProto_SparseTensor  	(36)        
        EencodeStringStringEntryProto   (37)
        EencodeTensorShapeProto         (38)
        EencodeTensorShapeProto_Dimension (39)
        EencodeSparseTensorProto        (40)
        EencodeTensorAnnotation         (41)        
        EencodeTrainingInfoProto        (42)
        
        
        EdestroyModelProto              (43)
    end
end