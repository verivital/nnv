classdef InputLayerTypeEnum
    enumeration
        IMAGE2D
        IMAGE3D
        RECURRENT
        FEATURE
    end
end


