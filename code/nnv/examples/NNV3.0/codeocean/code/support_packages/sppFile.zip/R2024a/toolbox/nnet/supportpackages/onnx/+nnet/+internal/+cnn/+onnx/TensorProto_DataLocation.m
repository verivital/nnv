classdef TensorProto_DataLocation < int32
%     DEFAULT = 0;
%     EXTERNAL = 1;
    
    %   Copyright 2019 The MathWorks, Inc.

    enumeration
        DEFAULT     (0)
        EXTERNAL	(1)
    end
end