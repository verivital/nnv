classdef TranslatorForArgMax < nnet.internal.cnn.onnx.TranslatorForArgMinMax
    
    %   Copyright 2021 The MathWorks, Inc.
    
end
