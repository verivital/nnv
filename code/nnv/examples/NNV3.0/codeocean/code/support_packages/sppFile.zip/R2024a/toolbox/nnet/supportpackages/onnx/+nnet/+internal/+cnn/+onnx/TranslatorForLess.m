classdef TranslatorForLess < nnet.internal.cnn.onnx.TranslatorForUnsupportedMISOBroadcastOp
    
    % Copyright 2021 The MathWorks, Inc.
    
end
