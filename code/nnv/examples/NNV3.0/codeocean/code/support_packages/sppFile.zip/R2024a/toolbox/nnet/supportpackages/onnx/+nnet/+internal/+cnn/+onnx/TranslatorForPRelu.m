classdef TranslatorForPRelu < nnet.internal.cnn.onnx.OperatorTranslator
    % A class to translate ONNX PRelu operators into MATLAB layers
    
    % Copyright 2021-2022 The MathWorks, Inc.
    
    methods
        % Do initial setup. this.Node has been set already.
        function initialize(this)
            this.CanPropagateSingletonFormats = true;
        end
        
        % Given the node and the current input and output formats, update
        % the formats in the specified direction to the extent possible.
        % Direction is either "forward" or "reverse". Each format variable
        % is a string array, where each string is one of the members of the
        % constant 'SupportedONNXLabels' property, or empty. Set a format
        % string to "" if its format cannot be determined.
        function [inputFormats, outputFormats] = propagateTensorFormats(this, direction, inputFormats, outputFormats)
            [inputFormats, outputFormats] = propagateSISOPassthroughOp(this, direction, inputFormats, outputFormats);
        end
        
        % Translate the node into a MATLAB layer, and return any
        % translation issues.
        function [Layer, issues] = translateIntoLayer(this, inputTensorFormats, outputTensorFormats)
            Layer = [];
            issues = nnet.internal.cnn.onnx.NodeTranslationIssue.empty;
            if supportedFormat(this, inputTensorFormats(1), outputTensorFormats(1))
                % slope is input 2
                if numel(this.Node.input)~=2
                    issues = [issues nnet.internal.cnn.onnx.NodeTranslationError(this.Node,...
                        message('nnet_cnn_onnx:onnx:PReluNumargs'))];
                    Layer = [];
                    return;
                end
                
                % Import slope and create layer
                slopeName	= this.Node.input{2};
                slope    	= double((initializerRawData(this.GraphProtoManager, slopeName)));
                slopeDim 	= double((initializerSize(this.GraphProtoManager, slopeName)));
                numChannels = numel(slope);
                if ~supportedSlope(this, inputTensorFormats(1), slopeDim)
                    issues = [issues nnet.internal.cnn.onnx.NodeTranslationError(this.Node,...
                        message('nnet_cnn_onnx:onnx:PReluSlopeDim'))];
                    Layer = [];
                    return;
                else
                    DLTChannelDim = getDLTChannelDim(this, inputTensorFormats(1));
                    [Layer, issues] = constructLayer(this, 'nnet.onnx.layer.PreluLayer', this.Node.name, this.Node, this.Node.name, numChannels, DLTChannelDim, slope);
                end
            end
            
        end
    end
    
    methods(Access=private)
        function tf = supportedFormat(~, inputTensorFormat, outputTensorFormat)
            tf = false;
            supportedFormats = ["BCSS", "BCSSS", "BC", "BCT", "TBC", "1BC", "T1BC"];
            if ismember(inputTensorFormat, supportedFormats) && isequal(inputTensorFormat, outputTensorFormat)
                tf = true;
            end
        end
        
        function tf = supportedSlope(~, inputTensorFormat, slopeDim)
            % Here we do no ONNX legality checking, but assume it is legal
            % in ONNX. We just check for the cases that DLT supports, which
            % is either a scalar slope, or a vector slope where the only
            % non-singleton duimension is in the C location.
            if ismember(inputTensorFormat, ["BC", "TBC", "1BC", "T1BC"])
                % Check for singletons in all but the last dimension:
                tf = all(slopeDim(1:numel(slopeDim)-1)==1);                             % slopeDim is [1* C]
            elseif inputTensorFormat=="BCT"
                % Broadcast to length 3 then check for singletons in dims 1 and 3:
                fullSlopeDim = [ones(1,3-numel(slopeDim)) slopeDim];
                tf = isequal(fullSlopeDim([1 3]), [1 1]);
            elseif inputTensorFormat=="BCSS"
                % Broadcast to length 4 then check for singletons in dims 1,3,4:
                fullSlopeDim = [ones(1,4-numel(slopeDim)) slopeDim];
                tf = isequal(fullSlopeDim([1 3 4]), [1 1 1]);
            else % BCSSS
                % Broadcast to length 5 then check for singletons in dims 1,3,4,5:
                fullSlopeDim = [ones(1,5-numel(slopeDim)) slopeDim];
                tf = isequal(fullSlopeDim([1 3 4 5]), [1 1 1 1]);
            end
        end
        
        function DLTChannelDim = getDLTChannelDim(~, inputTensorFormat)
            if ismember(inputTensorFormat, ["BC", "BCT", "TBC", "1BC", "T1BC"])
                DLTChannelDim = 1;                                          % CB, CBT
            elseif inputTensorFormat=="BCSS"
                DLTChannelDim = 3;                                          % SSCB
            else % BCSSS
                DLTChannelDim = 4;                                          % SSSCB
            end
        end
    end
end
