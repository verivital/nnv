classdef TranslatorForPad < nnet.internal.cnn.onnx.TranslatorForUnsupportedSISOPassthroughOp
    
    % Copyright 2021 The MathWorks, Inc.
    
end
