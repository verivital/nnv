classdef TranslatorForReduceL2 < nnet.internal.cnn.onnx.TranslatorForReduceOperators
end
