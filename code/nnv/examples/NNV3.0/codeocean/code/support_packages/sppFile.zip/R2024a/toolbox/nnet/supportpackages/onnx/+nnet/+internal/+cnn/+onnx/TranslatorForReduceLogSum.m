classdef TranslatorForReduceLogSum < nnet.internal.cnn.onnx.TranslatorForReduceOperators
end
