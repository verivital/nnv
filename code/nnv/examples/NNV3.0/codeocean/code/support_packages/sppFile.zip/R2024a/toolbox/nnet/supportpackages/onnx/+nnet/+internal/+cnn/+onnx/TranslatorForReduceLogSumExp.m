classdef TranslatorForReduceLogSumExp < nnet.internal.cnn.onnx.TranslatorForReduceOperators
end
