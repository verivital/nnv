classdef TranslatorForReduceMax < nnet.internal.cnn.onnx.TranslatorForReduceOperators
end
