classdef TranslatorForReduceMean < nnet.internal.cnn.onnx.TranslatorForReduceOperators
end
