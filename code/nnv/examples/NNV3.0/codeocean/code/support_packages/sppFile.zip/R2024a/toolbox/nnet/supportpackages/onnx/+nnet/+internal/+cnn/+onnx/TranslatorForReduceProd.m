classdef TranslatorForReduceProd < nnet.internal.cnn.onnx.TranslatorForReduceOperators
end
