classdef TranslatorForReduceSumSquare < nnet.internal.cnn.onnx.TranslatorForReduceOperators
end
