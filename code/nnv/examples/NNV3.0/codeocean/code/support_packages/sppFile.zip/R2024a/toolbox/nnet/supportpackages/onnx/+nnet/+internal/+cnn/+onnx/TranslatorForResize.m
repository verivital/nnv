classdef TranslatorForResize < nnet.internal.cnn.onnx.OperatorTranslator
    properties
        % Operator Attributes
        mode
        coordinate_transformation_mode
        cubic_coeff_a
        exclude_outside
        extrapolation_value
        nearest_mode
        
        % Cached layer and issues
        Layer
        Issues
    end
    
    methods
        % Do initial setup. this.Node has been set already.
        function initialize(this)
            % Define the legal attributes. Table columns are: onnxName, type, isOptional, default.
            % To see legal type strings: string(enumeration('nnet.internal.cnn.onnx.AttributeProto_AttributeType'))
            if this.GraphProtoManager.OpsetVersion == 10
                AttributeTable = cell2table({
                    "mode"	       "STRING"   true    "nearest"
                    });
                this.mode = nnet.internal.cnn.onnx.parseNodeAttributes(this.Node, AttributeTable);
                this.coordinate_transformation_mode = '';
                this.nearest_mode = '';
            else
                % Attributes for opset version 11.
                AttributeTable = cell2table({
                    "coordinate_transformation_mode"	"STRING"      true    "half-pixel"
                    "cubic_coeff_a"                     "FLOAT"       true    -0.75
                    "exclude_outside"                   "INT"         true    0
                    "extrapolation_value"               "FLOAT"       true    0
                    "mode"                              "STRING"      true    "nearest"
                    "nearest_mode"                      "STRING"      true    "round_prefer_floor"
                    });
                [this.coordinate_transformation_mode ,~,~,~, this.mode, this.nearest_mode]  = nnet.internal.cnn.onnx.parseNodeAttributes(this.Node, AttributeTable);
            end
        end
        
        % Given the node and the current input and output formats, update
        % the formats in the specified direction to the extent possible.
        % Direction is either "forward" or "reverse". Each format variable
        % is a string array, where each string is one of the members of the
        % constant 'SupportedONNXLabels' property, or empty. Set a format
        % string to empty if its format cannot be determined.
        function [inputTensorFormats, outputTensorFormats] = propagateTensorFormats(this, direction, inputTensorFormats, outputTensorFormats)
            [inputTensorFormats, outputTensorFormats] = propagateSISOPassthroughOp(this, direction, inputTensorFormats, outputTensorFormats);
        end
        
        % Translate the node into a MATLAB layer, and return any
        % translation issues.
        function [Layer, issues] = translateIntoLayer(this, inputTensorFormats, outputTensorFormats)
            Layer = [];
            issues = nnet.internal.cnn.onnx.NodeTranslationIssue.empty;
            if ~nnet.internal.cnn.onnx.isInstalledIPT()
                issues = nnet.internal.cnn.onnx.NodeTranslationError(this.Node, message('nnet_cnn_onnx:onnx:noIPTForOperator', 'Resize'));
            elseif ismember(inputTensorFormats(1), ["BCSS", "BCSSS"]) ...
                    && outputTensorFormats(1)~="" ...
                    && all(isNodeInputInitializer(this.GraphProtoManager, this.Node, 2:numel(inputTensorFormats)))
                LayerName = this.Node.name;
                % Validate and return the attributes supported by MATLAB.
                [this.coordinate_transformation_mode, coordTransModeIssue] = iValidateAndReturnCoordinateTransformMode(this.coordinate_transformation_mode, this.Node);
                [this.nearest_mode, nearestModeIssue] = iValidateAndReturnNearestMode(this.nearest_mode, this.Node);
                [modeIssue]                     = iValidateMode(this.mode, this.Node);
                [inputIssues]                   = iValidateInputs(this.Node, this.GraphProtoManager);
                % If any issues require a placeholder layer, return an empty layer and
                % the list of all issues
                issues = [coordTransModeIssue nearestModeIssue modeIssue inputIssues];
                placeholders = arrayfun(@(x) isa(x, "nnet.internal.cnn.onnx.NodeTranslationError"), issues);
                if any(placeholders)
                    Layer = [];
                    return;
                else
                    if numel(this.Node.input) == 2
                        scaleName = this.Node.input{2};
                        scales = single(initializerRawData(this.GraphProtoManager, scaleName));
                        [Layer, scaleIssue] = iCreateLayerFromONNX(this, this.coordinate_transformation_mode, this.nearest_mode, this.mode, 'Scale', scales, LayerName, this.Node);
                    elseif numel(this.Node.input) == 3
                        scaleName = this.Node.input{3};
                        scales = single(initializerRawData(this.GraphProtoManager, scaleName));
                        [Layer, scaleIssue] = iCreateLayerFromONNX(this, this.coordinate_transformation_mode, this.nearest_mode, this.mode, 'Scale', scales, LayerName, this.Node);
                    else
                        outputSizeName = this.Node.input{4};
                        outputSize = single(initializerRawData(this.GraphProtoManager, outputSizeName));
                        [Layer, scaleIssue] = iCreateLayerFromONNX(this, this.coordinate_transformation_mode, this.nearest_mode, this.mode, 'OutputSize', outputSize, LayerName, this.Node);
                    end
                    if ~isempty(scaleIssue)
                        issues = [issues scaleIssue];
                        Layer = [];
                    end
                end
            end
        end
    end
end

function [layer, issue] = iCreateLayerFromONNX(this, coordinateTransformMode, nearestMode, mode, type, value, LayerName, node)
% iCreateLayerFromONNX returns a layer. Inputs arguments are coordinate
% transform mode, nearest rounding mode, interpolation method,
% type (Scale or OutputSize), value of scale or output size, and layer
% name.
layer = [];
if numel(value) == 4
    value = [value(end-1) value(end)];
    mode = iConvertMethodFromONNX(mode, false);
    [layer, issue] = constructLayer(this, 'resize2dLayer', LayerName, node, 'Name', ...
        LayerName, type, value, 'Method', mode, 'NearestRoundingMode', nearestMode, ...
        'GeometricTransformMode', coordinateTransformMode);
elseif numel(value) == 5
    value = [value(end-2) value(end-1) value(end)];
    mode = iConvertMethodFromONNX(mode, true);
    [layer, issue] = constructLayer(this, 'resize3dLayer', LayerName, node, 'Name', ...
        LayerName, type, value, 'Method', mode, 'NearestRoundingMode', nearestMode, ...
        'GeometricTransformMode', coordinateTransformMode);
else
    issue = nnet.internal.cnn.onnx.NodeTranslationError(node, message("nnet_cnn_onnx:onnx:UnsupportedNumberOfElementsScale"));
end
end

function mode = iConvertMethodFromONNX(mode, has3dInput)
% Converts interpolation method string to layer type.
if strcmpi(mode,'linear')
    if has3dInput
        mode = 'trilinear';
    else
        mode = 'bilinear';
    end
end
end

function [coordinateTransformMode, issue] = iValidateAndReturnCoordinateTransformMode(coordinateTransformMode, node)
coordinateTransformMode = char(coordinateTransformMode);
issue = nnet.internal.cnn.onnx.NodeTranslationIssue.empty;
switch coordinateTransformMode
    case 'asymmetric'
        coordinateTransformMode = 'asymmetric';
    case 'half_pixel'
        coordinateTransformMode = 'half-pixel';
    case 'pytorch_half_pixel'
        issue = nnet.internal.cnn.onnx.NodeTranslationWarning(node, ...
            message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyImport",...
            string(coordinateTransformMode),"nearest_mode","half-pixel"));
        coordinateTransformMode = 'half-pixel';
    case ''
        coordinateTransformMode = 'asymmetric';
    otherwise
        issue = nnet.internal.cnn.onnx.NodeTranslationError(node, ...
            message("nnet_cnn_onnx:onnx:UnsupportedAttributeValue",...
            string(coordinateTransformMode),"coordinate_transformation_mode"));
        
end
end

function issue = iValidateMode(mode, node)
issue = nnet.internal.cnn.onnx.NodeTranslationIssue.empty;
supportedModes = ["nearest", "linear"];
if ~ismember(string(mode), supportedModes)
    issue = nnet.internal.cnn.onnx.NodeTranslationError(node, ...
        message("nnet_cnn_onnx:onnx:UnsupportedAttributeValue", string(mode), "mode"));
end
end

function [nearestMode, issue] = iValidateAndReturnNearestMode(nearestMode, node)
nearestMode = char(nearestMode);
issue = nnet.internal.cnn.onnx.NodeTranslationIssue.empty;
switch nearestMode
    case 'round_prefer_ceil'
        nearestMode = 'round';
    case ''
        nearestMode = 'onnx-10';
    case 'floor'
        issue = nnet.internal.cnn.onnx.NodeTranslationWarning(node, ...
            message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyImport",...
            string(nearestMode),"nearest_mode","onnx-10"));
        nearestMode = 'onnx-10';
    case 'ceil'
        issue = nnet.internal.cnn.onnx.NodeTranslationWarning(node, ...
            message("nnet_cnn_onnx:onnx:UnsupportedResizePropertyImport",...
            string(nearestMode),"nearest_mode","onnx-10"));
        nearestMode = 'onnx-10';
    otherwise
        issue = nnet.internal.cnn.onnx.NodeTranslationError(node, ...
            message("nnet_cnn_onnx:onnx:UnsupportedAttributeValue",...
            string(nearestMode),"nearest_mode"));
end
end

function issues = iValidateInputs(node, graphProtoManager)
% Loop over inputs 2-end (skipping the first input, X)
inputs = node.input;
issues = nnet.internal.cnn.onnx.NodeTranslationIssue.empty;
for i=2:numel(inputs)
    inputName = inputs{i};
    if ~isTensorInitializer(graphProtoManager, inputName)
        issues = [issues, nnet.internal.cnn.onnx.NodeTranslationError(node, ...
            message("nnet_cnn_onnx:onnx:InputsMustBeInitializers"))];
    end
end
end
