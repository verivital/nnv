classdef TranslatorForScatterElements < nnet.internal.cnn.onnx.TranslatorForFullyUnsupportedLayer
    
    % Copyright 2021 The MathWorks, Inc.
    
end
