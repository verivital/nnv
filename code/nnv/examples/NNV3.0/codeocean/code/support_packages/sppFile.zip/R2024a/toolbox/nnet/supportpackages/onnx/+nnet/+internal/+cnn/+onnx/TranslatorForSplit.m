classdef TranslatorForSplit < nnet.internal.cnn.onnx.TranslatorForUnsupportedSIMOPassthroughOp
    
    % Copyright 2021 The MathWorks, Inc.
    
end
