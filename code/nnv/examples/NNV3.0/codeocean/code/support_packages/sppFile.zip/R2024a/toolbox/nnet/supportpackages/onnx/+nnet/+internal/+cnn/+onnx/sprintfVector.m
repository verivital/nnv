function str = sprintfVector(vec)
str = sprintf('[');
str = [str sprintf('%d ', vec)];
str = [str sprintf(']')];
end