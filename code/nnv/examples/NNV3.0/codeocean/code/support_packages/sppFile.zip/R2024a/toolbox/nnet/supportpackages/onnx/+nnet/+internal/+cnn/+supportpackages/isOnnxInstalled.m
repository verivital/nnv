function isOnnxInstalled()
% This is an empty bread-crumb function used to determine the location of
% the Onnx support package.
