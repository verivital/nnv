classdef ExpLayer < nnet.layer.Layer ...
    & nnet.internal.cnn.layer.Traceable
% ExpLayer   Exp layer
%
%   layer = ExpLayer(Name) creates a log unit layer with
%   name Name. This type of layer calculates Y = exp(X).

%   Copyright 2021 The MathWorks, Inc.
    methods
        function this = ExpLayer(Name)
            this.Name = Name;
            this.Description = getString(message('nnet_cnn_onnx:onnx:ExpDescription'));
            this.Type = getString(message('nnet_cnn_onnx:onnx:ExpType'));
        end
        
        function Z = predict(~, X)
            Z = exp(X);
        end
        
        function dLdX = backward( this, X, Z, dLdZ, memory )
            dLdX = dLdZ.*Z;
        end
    end
end

