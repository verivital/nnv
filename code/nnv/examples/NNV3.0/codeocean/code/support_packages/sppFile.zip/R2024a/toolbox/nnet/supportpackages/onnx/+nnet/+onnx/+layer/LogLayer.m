classdef LogLayer < nnet.layer.Layer ...
    & nnet.internal.cnn.layer.Traceable
% LogLayer   Log layer
%
%   layer = LogLayer(Name) creates a log unit layer with
%   name Name. This type of layer calculates Y = log(X).

%   Copyright 2021 The MathWorks, Inc.
    methods
        function this = LogLayer(Name)
            this.Name = Name;
            this.Description = getString(message('nnet_cnn_onnx:onnx:LogDescription'));
            this.Type = getString(message('nnet_cnn_onnx:onnx:LogType'));
        end
        
        function Z = predict(~, X)
            Z = log(X);
        end
        
        function dLdX = backward( this, X, Z, dLdZ, memory )
            dLdX = dLdZ./X;
        end
    end
end

