classdef VerifyBatchSizeLayer < nnet.layer.Layer & nnet.layer.Formattable ...
        & nnet.internal.cnn.layer.Traceable
    % VerifyBatchSizeLayer   Verify fixed batch size
    %
    %   layer = VerifyBatchSizeLayer(name, requiredBatchSize, batchDim,
    %   inputLayerName) creates a layer that verifies that dimension
    %   batchDim of its input has size requiredBatchSize.

    %   Copyright 2021 The MathWorks, Inc.
    properties
        RequiredBatchSize
        BatchDim
        InputLayerName
    end

    methods
        function this = VerifyBatchSizeLayer(name, requiredBatchSize, batchDim, inputLayerName)
            arguments
                name                (1,1) string
                requiredBatchSize   (1,1) double {mustBePositive}
                batchDim            (1,1) double {mustBePositive}
                inputLayerName      (1,1) string
            end
            this.Name = name;
            this.Description = getString(message('nnet_cnn_onnx:onnx:VerifyBatchSizeLayerDescription', requiredBatchSize));
            this.Type = getString(message('nnet_cnn_onnx:onnx:VerifyBatchSizeLayerType'));
            this.RequiredBatchSize = requiredBatchSize;
            this.BatchDim = batchDim;
            this.InputLayerName = inputLayerName;
        end

        function X = predict( this, X )
            if size(X, this.BatchDim) ~= this.RequiredBatchSize
                error(message('nnet_cnn_onnx:onnx:WrongFixedBatchSize', ...
                    this.InputLayerName, this.RequiredBatchSize, size(X, this.BatchDim)));
            end
        end
    end
end
