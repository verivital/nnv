% check if on codeocean, error out if not
try
    if ~is_codeocean() % test codeocean detection
        'ERROR: run_codeocean.m should only be executed on the codeocean platform'
        return;
    end
catch
    'ERROR: path likely not set, run install.m'
end

% default output path for path_results, ensure logs subdirectory there
mkdir('/results/logs/')

cd /code/nnv/examples/Submission/FORMATS2022/

% run_subset % run a subset of all FORMATS results, much faster
run_all_nnv % run the complete results of the FORMATS paper
